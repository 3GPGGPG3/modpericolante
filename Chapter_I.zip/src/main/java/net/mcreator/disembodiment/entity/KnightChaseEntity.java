
package net.mcreator.disembodiment.entity;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.projectile.ThrownPotion;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.MobType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.AnimationState;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;
import net.minecraft.nbt.CompoundTag;

import net.mcreator.disembodiment.procedures.KnightChasePlayerCollidesWithThisEntityProcedure;
import net.mcreator.disembodiment.procedures.KnightChasePlaybackConditionProcedure;
import net.mcreator.disembodiment.procedures.KnightChasePlaybackCondition2Procedure;
import net.mcreator.disembodiment.procedures.KnightChaseCanWalkProcedure;
import net.mcreator.disembodiment.init.DisembodimentModEntities;

public class KnightChaseEntity extends Monster {
	public static final EntityDataAccessor<Boolean> DATA_hit = SynchedEntityData.defineId(KnightChaseEntity.class, EntityDataSerializers.BOOLEAN);
	public final AnimationState animationState0 = new AnimationState();
	public final AnimationState animationState2 = new AnimationState();

	public KnightChaseEntity(PlayMessages.SpawnEntity packet, Level world) {
		this(DisembodimentModEntities.KNIGHT_CHASE.get(), world);
	}

	public KnightChaseEntity(EntityType<KnightChaseEntity> type, Level world) {
		super(type, world);
		setMaxUpStep(0.6f);
		xpReward = 0;
		setNoAi(false);
		setPersistenceRequired();
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	protected void defineSynchedData() {
		super.defineSynchedData();
		this.entityData.define(DATA_hit, false);
	}

	@Override
	protected void registerGoals() {
		super.registerGoals();
		this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.2, false) {
			@Override
			protected double getAttackReachSqr(LivingEntity entity) {
				return this.mob.getBbWidth() * this.mob.getBbWidth() + entity.getBbWidth();
			}
		});
		this.targetSelector.addGoal(2, new NearestAttackableTargetGoal(this, Player.class, false, false) {
			@Override
			public boolean canUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canUse() && KnightChaseCanWalkProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canContinueToUse() && KnightChaseCanWalkProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(3, new RandomStrollGoal(this, 1) {
			@Override
			public boolean canUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canUse() && KnightChaseCanWalkProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canContinueToUse() && KnightChaseCanWalkProcedure.execute(entity);
			}
		});
		this.targetSelector.addGoal(4, new HurtByTargetGoal(this));
		this.goalSelector.addGoal(5, new RandomLookAroundGoal(this) {
			@Override
			public boolean canUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canUse() && KnightChaseCanWalkProcedure.execute(entity);
			}

			@Override
			public boolean canContinueToUse() {
				double x = KnightChaseEntity.this.getX();
				double y = KnightChaseEntity.this.getY();
				double z = KnightChaseEntity.this.getZ();
				Entity entity = KnightChaseEntity.this;
				Level world = KnightChaseEntity.this.level();
				return super.canContinueToUse() && KnightChaseCanWalkProcedure.execute(entity);
			}
		});
		this.goalSelector.addGoal(6, new FloatGoal(this));
	}

	@Override
	public MobType getMobType() {
		return MobType.UNDEFINED;
	}

	@Override
	public boolean removeWhenFarAway(double distanceToClosestPlayer) {
		return false;
	}

	@Override
	public SoundEvent getHurtSound(DamageSource ds) {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.hurt"));
	}

	@Override
	public SoundEvent getDeathSound() {
		return ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.generic.death"));
	}

	@Override
	public boolean hurt(DamageSource damagesource, float amount) {
		if (damagesource.is(DamageTypes.IN_FIRE))
			return false;
		if (damagesource.getDirectEntity() instanceof AbstractArrow)
			return false;
		if (damagesource.getDirectEntity() instanceof Player)
			return false;
		if (damagesource.getDirectEntity() instanceof ThrownPotion || damagesource.getDirectEntity() instanceof AreaEffectCloud)
			return false;
		if (damagesource.is(DamageTypes.FALL))
			return false;
		if (damagesource.is(DamageTypes.CACTUS))
			return false;
		if (damagesource.is(DamageTypes.DROWN))
			return false;
		if (damagesource.is(DamageTypes.LIGHTNING_BOLT))
			return false;
		if (damagesource.is(DamageTypes.EXPLOSION) || damagesource.is(DamageTypes.PLAYER_EXPLOSION))
			return false;
		if (damagesource.is(DamageTypes.TRIDENT))
			return false;
		if (damagesource.is(DamageTypes.FALLING_ANVIL))
			return false;
		if (damagesource.is(DamageTypes.DRAGON_BREATH))
			return false;
		if (damagesource.is(DamageTypes.WITHER) || damagesource.is(DamageTypes.WITHER_SKULL))
			return false;
		return super.hurt(damagesource, amount);
	}

	@Override
	public boolean ignoreExplosion() {
		return true;
	}

	@Override
	public boolean fireImmune() {
		return true;
	}

	@Override
	public void addAdditionalSaveData(CompoundTag compound) {
		super.addAdditionalSaveData(compound);
		compound.putBoolean("Datahit", this.entityData.get(DATA_hit));
	}

	@Override
	public void readAdditionalSaveData(CompoundTag compound) {
		super.readAdditionalSaveData(compound);
		if (compound.contains("Datahit"))
			this.entityData.set(DATA_hit, compound.getBoolean("Datahit"));
	}

	@Override
	public void tick() {
		super.tick();
		if (this.level().isClientSide()) {
			this.animationState0.animateWhen(KnightChasePlaybackConditionProcedure.execute(this), this.tickCount);
			this.animationState2.animateWhen(KnightChasePlaybackCondition2Procedure.execute(this), this.tickCount);
		}
	}

	@Override
	public void playerTouch(Player sourceentity) {
		super.playerTouch(sourceentity);
		KnightChasePlayerCollidesWithThisEntityProcedure.execute(this.level(), this, sourceentity);
	}

	public static void init() {
	}

	public static AttributeSupplier.Builder createAttributes() {
		AttributeSupplier.Builder builder = Mob.createMobAttributes();
		builder = builder.add(Attributes.MOVEMENT_SPEED, 0.25);
		builder = builder.add(Attributes.MAX_HEALTH, 10);
		builder = builder.add(Attributes.ARMOR, 0);
		builder = builder.add(Attributes.ATTACK_DAMAGE, 0);
		builder = builder.add(Attributes.FOLLOW_RANGE, 100);
		return builder;
	}
}
