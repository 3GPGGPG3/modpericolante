package net.mcreator.disembodiment.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.disembodiment.entity.KnightChaseEntity;

public class KnightChasePlaybackConditionProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if (entity.getDeltaMovement().x() == 0 && entity.getDeltaMovement().z() == 0 && (entity instanceof KnightChaseEntity _datEntL2 && _datEntL2.getEntityData().get(KnightChaseEntity.DATA_hit)) == false) {
			return true;
		}
		return false;
	}
}
