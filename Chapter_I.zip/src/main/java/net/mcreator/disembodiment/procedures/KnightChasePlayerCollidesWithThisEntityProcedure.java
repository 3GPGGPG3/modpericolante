package net.mcreator.disembodiment.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.GameType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.InteractionHand;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.client.Minecraft;

import net.mcreator.disembodiment.entity.KnightChaseEntity;
import net.mcreator.disembodiment.DisembodimentMod;

import java.util.Map;

public class KnightChasePlayerCollidesWithThisEntityProcedure {
	public static void execute(LevelAccessor world, Entity entity, Entity sourceentity) {
		if (entity == null || sourceentity == null)
			return;
		if (!(new Object() {
			public boolean checkGamemode(Entity _ent) {
				if (_ent instanceof ServerPlayer _serverPlayer) {
					return _serverPlayer.gameMode.getGameModeForPlayer() == GameType.CREATIVE;
				} else if (_ent.level().isClientSide() && _ent instanceof Player _player) {
					return Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()) != null && Minecraft.getInstance().getConnection().getPlayerInfo(_player.getGameProfile().getId()).getGameMode() == GameType.CREATIVE;
				}
				return false;
			}
		}.checkGamemode(sourceentity)) && (entity instanceof KnightChaseEntity _datEntL1 && _datEntL1.getEntityData().get(KnightChaseEntity.DATA_hit)) == false) {
			if (entity instanceof KnightChaseEntity _datEntSetL)
				_datEntSetL.getEntityData().set(KnightChaseEntity.DATA_hit, true);
			{
				BlockPos _bp = new BlockPos(261, -60, -75);
				BlockState _bs = Blocks.REDSTONE_BLOCK.defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			if (sourceentity instanceof LivingEntity _entity)
				_entity.setHealth(1);
			if (sourceentity instanceof LivingEntity _entity)
				_entity.swing(InteractionHand.MAIN_HAND, true);
			DisembodimentMod.queueServerWork(20, () -> {
				if (sourceentity instanceof LivingEntity _entity)
					_entity.swing(InteractionHand.OFF_HAND, true);
				DisembodimentMod.queueServerWork(60, () -> {
					{
						BlockPos _bp = new BlockPos(261, -60, -75);
						BlockState _bs = Blocks.STONE.defaultBlockState();
						BlockState _bso = world.getBlockState(_bp);
						for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
							Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
							if (_property != null && _bs.getValue(_property) != null)
								try {
									_bs = _bs.setValue(_property, (Comparable) entry.getValue());
								} catch (Exception e) {
								}
						}
						world.setBlock(_bp, _bs, 3);
					}
					DisembodimentMod.queueServerWork(20, () -> {
						if (sourceentity instanceof Player _player)
							_player.getFoodData().setSaturation(20);
						if (sourceentity instanceof LivingEntity _entity)
							_entity.setHealth(20);
						if (entity instanceof KnightChaseEntity _datEntSetL)
							_datEntSetL.getEntityData().set(KnightChaseEntity.DATA_hit, false);
					});
				});
			});
		}
	}
}
