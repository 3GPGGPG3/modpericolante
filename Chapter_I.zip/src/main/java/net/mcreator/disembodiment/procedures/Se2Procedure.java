package net.mcreator.disembodiment.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.disembodiment.entity.ElevatorEntity;

public class Se2Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof ElevatorEntity _datEntI ? _datEntI.getEntityData().get(ElevatorEntity.DATA_ascensore) : 0) == 2) {
			return true;
		}
		return false;
	}
}
