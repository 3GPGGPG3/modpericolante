package net.mcreator.disembodiment.procedures;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.disembodiment.init.DisembodimentModMobEffects;

public class EffectC3DisplayOverlayIngameProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		return entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(DisembodimentModMobEffects.EYE_BLEEDING_4.get());
	}
}
