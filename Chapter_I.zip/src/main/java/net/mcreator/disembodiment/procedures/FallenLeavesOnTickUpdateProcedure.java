package net.mcreator.disembodiment.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.disembodiment.init.DisembodimentModBlocks;
import net.mcreator.disembodiment.DisembodimentMod;

public class FallenLeavesOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		DisembodimentMod.queueServerWork(2, () -> {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == Blocks.AIR) {
				world.setBlock(BlockPos.containing(x, y, z), DisembodimentModBlocks.FALLEN_LEAVES.get().defaultBlockState(), 3);
			}
		});
	}
}
