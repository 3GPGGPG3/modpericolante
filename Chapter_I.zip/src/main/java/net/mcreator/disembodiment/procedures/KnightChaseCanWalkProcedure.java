package net.mcreator.disembodiment.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.disembodiment.entity.KnightChaseEntity;

public class KnightChaseCanWalkProcedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity instanceof KnightChaseEntity _datEntL0 && _datEntL0.getEntityData().get(KnightChaseEntity.DATA_hit)) == false) {
			return true;
		}
		return false;
	}
}
