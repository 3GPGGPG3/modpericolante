package net.mcreator.disembodiment.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 5.0.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelcorpse2<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("disembodiment", "modelcorpse_2"), "main");
	public final ModelPart g_sx;
	public final ModelPart b_sx;
	public final ModelPart b_dx;
	public final ModelPart g_dx;
	public final ModelPart head;
	public final ModelPart goccia;
	public final ModelPart bb_main;

	public Modelcorpse2(ModelPart root) {
		this.g_sx = root.getChild("g_sx");
		this.b_sx = root.getChild("b_sx");
		this.b_dx = root.getChild("b_dx");
		this.g_dx = root.getChild("g_dx");
		this.head = root.getChild("head");
		this.goccia = root.getChild("goccia");
		this.bb_main = root.getChild("bb_main");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition g_sx = partdefinition.addOrReplaceChild("g_sx", CubeListBuilder.create(), PartPose.offset(2.2438F, 7.8305F, 7.9548F));
		PartDefinition cube_r1 = g_sx.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(0, 16).addBox(-2.1587F, 0.1708F, -3.5735F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9F, -6.1F, -1.6F, 3.1379F, 0.0263F, 3.014F));
		PartDefinition b_sx = partdefinition.addOrReplaceChild("b_sx", CubeListBuilder.create(), PartPose.offset(6.6479F, 7.9818F, -3.9229F));
		PartDefinition cube_r2 = b_sx.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(32, 48).addBox(-0.0515F, 0.1477F, -1.6543F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.1F, -6.1F, -0.3F, -0.0689F, -0.1946F, -0.0282F));
		PartDefinition b_dx = partdefinition.addOrReplaceChild("b_dx", CubeListBuilder.create(), PartPose.offset(-5.752F, 7.6913F, -4.38F));
		PartDefinition cube_r3 = b_dx.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(32, 48).addBox(-3.9692F, -0.0157F, -2.0011F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.2F, -5.9F, 0.2F, 0.0105F, -0.1329F, 0.0404F));
		PartDefinition g_dx = partdefinition.addOrReplaceChild("g_dx", CubeListBuilder.create(), PartPose.offset(-3.3152F, 8.0593F, 7.5315F));
		PartDefinition cube_r4 = g_dx.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(16, 48).addBox(-2.0823F, 0.2987F, -3.3039F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -6.3F, -1.2F, -3.126F, 0.184F, -3.0845F));
		PartDefinition head = partdefinition.addOrReplaceChild("head", CubeListBuilder.create(), PartPose.offset(0.9152F, 3.4297F, -5.8776F));
		PartDefinition cube_r5 = head.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(24, 60).addBox(-0.5743F, 0.8F, -0.414F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1122F, 7.283F, 2.8851F, -0.0151F, 0.075F, 0.1187F));
		PartDefinition cube_r6 = head.addOrReplaceChild("cube_r6", CubeListBuilder.create().texOffs(21, 37).addBox(-0.4406F, -0.9248F, -0.542F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1122F, 7.283F, 2.8851F, 0.0346F, 0.0034F, 2.0395F));
		PartDefinition cube_r7 = head.addOrReplaceChild("cube_r7", CubeListBuilder.create().texOffs(42, 2).addBox(0.0743F, -2.3F, -0.586F, 0.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1122F, 7.183F, 2.8851F, 0.0896F, 0.075F, 0.1187F));
		PartDefinition cube_r8 = head
				.addOrReplaceChild(
						"cube_r8", CubeListBuilder.create().texOffs(54, 0).addBox(-1.7309F, -9.0832F, 5.2536F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(54, 0)
								.addBox(-1.0552F, -8.5889F, 5.5685F, 3.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 0).addBox(-3.5323F, -8.7475F, -0.9353F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(-1.0F, 0.8F, 3.5F, 2.7258F, -0.1296F, 0.0538F));
		PartDefinition goccia = partdefinition.addOrReplaceChild("goccia", CubeListBuilder.create(), PartPose.offset(2.9F, 14.5F, -3.0F));
		PartDefinition bb_main = partdefinition.addOrReplaceChild("bb_main", CubeListBuilder.create().texOffs(0, 34).addBox(-0.6F, -29.0F, -0.5F, 1.0F, 29.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, 24.0F, 0.0F));
		PartDefinition cube_r9 = bb_main.addOrReplaceChild("cube_r9", CubeListBuilder.create().texOffs(16, 16).addBox(-3.5932F, -2.8812F, -0.0646F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0848F, -19.0703F, -3.0776F, 1.5985F, -0.0972F, 0.0117F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		g_sx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		b_sx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		b_dx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		g_dx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		head.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		goccia.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		bb_main.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
