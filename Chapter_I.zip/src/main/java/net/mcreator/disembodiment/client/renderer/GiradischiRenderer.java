
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.GiradischiEntity;
import net.mcreator.disembodiment.client.model.animations.giradischiAnimation;
import net.mcreator.disembodiment.client.model.Modelgiradischi;

public class GiradischiRenderer extends MobRenderer<GiradischiEntity, Modelgiradischi<GiradischiEntity>> {
	public GiradischiRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelgiradischi.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(GiradischiEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/giradischio.png");
	}

	private static final class AnimatedModel extends Modelgiradischi<GiradischiEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<GiradischiEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(GiradischiEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, giradischiAnimation.disco_girante, ageInTicks, 0.2f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(GiradischiEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
