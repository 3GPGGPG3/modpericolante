
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.EyesInTheDarkidleEntity;
import net.mcreator.disembodiment.client.model.animations.eyesinthedark_idleAnimation;
import net.mcreator.disembodiment.client.model.Modeleyesinthedark;

public class EyesInTheDarkidleRenderer extends MobRenderer<EyesInTheDarkidleEntity, Modeleyesinthedark<EyesInTheDarkidleEntity>> {
	public EyesInTheDarkidleRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modeleyesinthedark.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(EyesInTheDarkidleEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/eyesinthedark.png");
	}

	private static final class AnimatedModel extends Modeleyesinthedark<EyesInTheDarkidleEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<EyesInTheDarkidleEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(EyesInTheDarkidleEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, eyesinthedark_idleAnimation.idle, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(EyesInTheDarkidleEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
