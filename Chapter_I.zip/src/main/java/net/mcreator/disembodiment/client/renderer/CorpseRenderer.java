
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.CorpseEntity;
import net.mcreator.disembodiment.client.model.animations.corpseAnimation;
import net.mcreator.disembodiment.client.model.Modelcorpse;

public class CorpseRenderer extends MobRenderer<CorpseEntity, Modelcorpse<CorpseEntity>> {
	public CorpseRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelcorpse.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(CorpseEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/dead.png");
	}

	private static final class AnimatedModel extends Modelcorpse<CorpseEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<CorpseEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(CorpseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, corpseAnimation.gocciolare, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(CorpseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
