package net.mcreator.disembodiment.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 5.0.6
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelpsychologist_headless<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("disembodiment", "modelpsychologist_headless"), "main");
	public final ModelPart all;
	public final ModelPart blood2;
	public final ModelPart head;
	public final ModelPart corpo;
	public final ModelPart braccio_dx;
	public final ModelPart braccio_sx;
	public final ModelPart gamba_dx;
	public final ModelPart gamba_sx;
	public final ModelPart blood;

	public Modelpsychologist_headless(ModelPart root) {
		this.all = root.getChild("all");
		this.blood2 = this.all.getChild("blood2");
		this.head = this.all.getChild("head");
		this.corpo = this.all.getChild("corpo");
		this.braccio_dx = this.corpo.getChild("braccio_dx");
		this.braccio_sx = this.corpo.getChild("braccio_sx");
		this.gamba_dx = this.corpo.getChild("gamba_dx");
		this.gamba_sx = this.corpo.getChild("gamba_sx");
		this.blood = this.corpo.getChild("blood");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition all = partdefinition.addOrReplaceChild("all", CubeListBuilder.create(), PartPose.offset(0.0F, 24.0F, 0.0F));
		PartDefinition blood2 = all.addOrReplaceChild("blood2", CubeListBuilder.create(), PartPose.offset(12.4F, -0.1F, -4.0F));
		PartDefinition cube_r1 = blood2.addOrReplaceChild("cube_r1", CubeListBuilder.create().texOffs(35, 32).addBox(-4.0F, 0.0F, -4.0F, 11.0F, 0.0F, 8.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.6545F, 0.0F));
		PartDefinition head = all.addOrReplaceChild("head", CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -24.0F, 0.0F));
		PartDefinition cube_r2 = head.addOrReplaceChild("cube_r2", CubeListBuilder.create().texOffs(34, 35).addBox(2.0F, 0.0F, -1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0F, -1.2F, 0.0F, 0.7156F, 0.0F, 0.0F));
		PartDefinition corpo = all.addOrReplaceChild("corpo", CubeListBuilder.create().texOffs(16, 16).addBox(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(0.0F, -24.0F, 0.0F));
		PartDefinition cube_r3 = corpo.addOrReplaceChild("cube_r3", CubeListBuilder.create().texOffs(34, 35).addBox(2.0F, 0.0F, -1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(-3.0F, -0.3F, 0.5F, 0.7156F, 0.0F, 0.0F));
		PartDefinition cube_r4 = corpo.addOrReplaceChild("cube_r4", CubeListBuilder.create().texOffs(34, 35).addBox(2.0F, 0.0F, -1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, -0.3F, -0.4F, 0.7156F, 0.0F, 0.0F));
		PartDefinition braccio_dx = corpo.addOrReplaceChild("braccio_dx", CubeListBuilder.create().texOffs(36, 16).addBox(-4.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-4.0F, 0.0F, 0.0F));
		PartDefinition braccio_sx = corpo.addOrReplaceChild("braccio_sx", CubeListBuilder.create().texOffs(32, 48).addBox(0.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(4.0F, 0.0F, 0.0F));
		PartDefinition gamba_dx = corpo.addOrReplaceChild("gamba_dx", CubeListBuilder.create().texOffs(0, 16).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(-2.0F, 12.0F, 0.0F));
		PartDefinition gamba_sx = corpo.addOrReplaceChild("gamba_sx", CubeListBuilder.create().texOffs(16, 48).addBox(-2.0F, 0.0F, -2.0F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(2.0F, 12.0F, 0.0F));
		PartDefinition blood = corpo.addOrReplaceChild("blood", CubeListBuilder.create(), PartPose.offset(0.7F, 0.3054F, 0.0507F));
		PartDefinition cube_r5 = blood.addOrReplaceChild("cube_r5", CubeListBuilder.create().texOffs(21, 16).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)), PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 1.5882F, 0.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		all.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
