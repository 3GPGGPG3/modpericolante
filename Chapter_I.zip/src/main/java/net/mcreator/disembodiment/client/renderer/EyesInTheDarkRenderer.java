
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.EyesInTheDarkEntity;
import net.mcreator.disembodiment.client.model.animations.eyesinthedarkAnimation;
import net.mcreator.disembodiment.client.model.Modeleyesinthedark;

public class EyesInTheDarkRenderer extends MobRenderer<EyesInTheDarkEntity, Modeleyesinthedark<EyesInTheDarkEntity>> {
	public EyesInTheDarkRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modeleyesinthedark.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(EyesInTheDarkEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/eyesinthedark.png");
	}

	private static final class AnimatedModel extends Modeleyesinthedark<EyesInTheDarkEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<EyesInTheDarkEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(EyesInTheDarkEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, eyesinthedarkAnimation.seek, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(EyesInTheDarkEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
