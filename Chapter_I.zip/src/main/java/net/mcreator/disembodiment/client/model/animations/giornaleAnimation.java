package net.mcreator.disembodiment.client.model.animations;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.AnimationChannel;

// Save this class in your mod and generate all required imports
/**
 * Made with Blockbench 5.0.5 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class giornaleAnimation {
	public static final AnimationDefinition sfoglia = AnimationDefinition.Builder.withLength(16.0F)
			.addAnimation("br_dx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.2083F, KeyframeAnimations.degreeVec(16.0374F, -4.9238F, -0.8704F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.5F, KeyframeAnimations.degreeVec(32.0106F, -33.295F, 11.4919F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.625F, KeyframeAnimations.degreeVec(24.9465F, -40.4932F, 10.1396F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.8333F, KeyframeAnimations.degreeVec(12.1334F, -43.1262F, 18.8477F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(9.0F, KeyframeAnimations.degreeVec(25.2419F, -30.3695F, 21.9892F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(9.4167F, KeyframeAnimations.degreeVec(10.3357F, -12.6906F, 2.4247F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.1667F, KeyframeAnimations.degreeVec(10.34F, -12.69F, 2.42F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.7917F, KeyframeAnimations.degreeVec(22.6253F, -12.5006F, 0.2202F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("br_dx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.5F, KeyframeAnimations.posVec(0.8F, 0.0F, 0.8F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.625F, KeyframeAnimations.posVec(-1.4F, 0.5F, 1.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.8333F, KeyframeAnimations.posVec(-3.4F, -0.1F, 1.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.0F, KeyframeAnimations.posVec(-2.3F, -0.1F, 0.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.4167F, KeyframeAnimations.posVec(-0.6F, -1.0F, -1.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.1667F, KeyframeAnimations.posVec(-0.6F, -1.0F, -1.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.7917F, KeyframeAnimations.posVec(-0.6F, -2.7F, -1.2F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("br_sx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.875F, KeyframeAnimations.degreeVec(7.3881F, -23.6215F, -33.2687F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.25F, KeyframeAnimations.degreeVec(5.5195F, -10.557F, -16.3736F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.1667F, KeyframeAnimations.degreeVec(5.52F, -10.56F, -16.37F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.7917F, KeyframeAnimations.degreeVec(12.6146F, -10.1067F, -17.9328F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("br_sx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.625F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.1667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.7917F, KeyframeAnimations.posVec(0.0F, -1.2F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("pagina", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(3.0417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 6.83F), AnimationChannel.Interpolations.LINEAR), new Keyframe(7.999F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 6.83F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(8.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -152.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("pagina",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(3.0417F, KeyframeAnimations.posVec(0.01F, 0.04F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(7.999F, KeyframeAnimations.posVec(0.01F, 0.04F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(8.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.0F, KeyframeAnimations.posVec(-0.3F, -0.8F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("pagina", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(0.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("all",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(12.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.7917F, KeyframeAnimations.degreeVec(-9.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("all", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(12.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.7917F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}
