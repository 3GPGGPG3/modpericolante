
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.procedures.KnightChaseIsWalkingProcedure;
import net.mcreator.disembodiment.entity.KnightChaseEntity;
import net.mcreator.disembodiment.client.model.animations.knight_chaseAnimation;
import net.mcreator.disembodiment.client.model.Modelknight_chase;

public class KnightChaseRenderer extends MobRenderer<KnightChaseEntity, Modelknight_chase<KnightChaseEntity>> {
	public KnightChaseRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelknight_chase.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(KnightChaseEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/knight_chase_texture.png");
	}

	private static final class AnimatedModel extends Modelknight_chase<KnightChaseEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<KnightChaseEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(KnightChaseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, knight_chaseAnimation.idle, ageInTicks, 1f);
				if (KnightChaseIsWalkingProcedure.execute(entity))
					this.animateWalk(knight_chaseAnimation.chase, limbSwing, limbSwingAmount, 1.5f, 1.5f);
				this.animate(entity.animationState2, knight_chaseAnimation.jumpscare, ageInTicks, 1.5f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(KnightChaseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
