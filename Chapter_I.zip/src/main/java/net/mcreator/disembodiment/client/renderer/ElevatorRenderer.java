
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.ElevatorEntity;
import net.mcreator.disembodiment.client.model.animations.ascensoreAnimation;
import net.mcreator.disembodiment.client.model.Modelascensore;

public class ElevatorRenderer extends MobRenderer<ElevatorEntity, Modelascensore<ElevatorEntity>> {
	public ElevatorRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelascensore.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(ElevatorEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/elevator.png");
	}

	private static final class AnimatedModel extends Modelascensore<ElevatorEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<ElevatorEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(ElevatorEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, ascensoreAnimation.keep_closed, ageInTicks, 1f);
				this.animate(entity.animationState1, ascensoreAnimation.keep_open, ageInTicks, 1f);
				this.animate(entity.animationState2, ascensoreAnimation.open, ageInTicks, 1f);
				this.animate(entity.animationState3, ascensoreAnimation.close, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(ElevatorEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
