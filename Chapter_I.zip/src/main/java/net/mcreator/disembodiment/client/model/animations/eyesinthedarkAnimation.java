package net.mcreator.disembodiment.client.model.animations;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.AnimationChannel;

// Save this class in your mod and generate all required imports
/**
 * Made with Blockbench 4.12.6 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class eyesinthedarkAnimation {
	public static final AnimationDefinition seek = AnimationDefinition.Builder.withLength(25.0F).addAnimation("corpo", new AnimationChannel(AnimationChannel.Targets.ROTATION,
			new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.0417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -5.0F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(6.2917F, KeyframeAnimations.degreeVec(0.0F, -10.0F, -5.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(7.375F, KeyframeAnimations.degreeVec(0.0F, -8.24F, -3.75F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(8.7917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(8.9583F, KeyframeAnimations.degreeVec(-0.3093F, -3.5308F, 5.2856F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(9.25F, KeyframeAnimations.degreeVec(0.0F, -12.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.9583F, KeyframeAnimations.degreeVec(0.0F, -12.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(10.5F, KeyframeAnimations.degreeVec(2.3281F, -22.2993F, -10.6514F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(10.9583F, KeyframeAnimations.degreeVec(-11.9327F, -50.3443F, -6.7626F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(12.25F, KeyframeAnimations.degreeVec(159.2039F, -69.8016F, -181.2619F), AnimationChannel.Interpolations.LINEAR),
			new Keyframe(12.2917F, KeyframeAnimations.degreeVec(153.1948F, -68.9812F, -175.8915F), AnimationChannel.Interpolations.LINEAR),
			new Keyframe(12.4573F, KeyframeAnimations.degreeVec(153.1948F, -68.9812F, -175.8915F), AnimationChannel.Interpolations.LINEAR),
			new Keyframe(12.4583F, KeyframeAnimations.degreeVec(-216.2908F, -58.8774F, 192.7255F), AnimationChannel.Interpolations.LINEAR),
			new Keyframe(12.499F, KeyframeAnimations.degreeVec(-216.2908F, -58.8774F, 192.7255F), AnimationChannel.Interpolations.LINEAR),
			new Keyframe(12.5F, KeyframeAnimations.degreeVec(-205.7136F, -33.9671F, 187.7711F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(15.875F, KeyframeAnimations.degreeVec(-203.4591F, -16.8558F, 183.955F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(16.4583F, KeyframeAnimations.degreeVec(-203.46F, -16.86F, 183.96F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(16.625F, KeyframeAnimations.degreeVec(-204.7556F, -14.8165F, 188.7038F), AnimationChannel.Interpolations.CATMULLROM),
			new Keyframe(20.0F, KeyframeAnimations.degreeVec(-203.46F, -16.86F, 183.96F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corpo", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(2.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.0417F, KeyframeAnimations.posVec(0.6F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.2917F, KeyframeAnimations.posVec(0.3F, -0.4F, -0.7F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(7.375F, KeyframeAnimations.posVec(0.43F, -0.43F, -0.65F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.7917F, KeyframeAnimations.posVec(0.9F, -0.4F, -0.3F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.9583F, KeyframeAnimations.posVec(0.3F, -0.1F, -0.51F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.25F, KeyframeAnimations.posVec(1.1F, -0.4F, -1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.9583F, KeyframeAnimations.posVec(1.1F, -0.4F, -1.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.5F, KeyframeAnimations.posVec(0.3F, 1.1F, -0.4F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(-1.2F, 0.0F, 0.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.25F, KeyframeAnimations.posVec(0.9F, 0.42F, 0.85F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5F, KeyframeAnimations.posVec(0.6F, 0.8F, 0.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(15.875F, KeyframeAnimations.posVec(0.6F, 0.2F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4583F, KeyframeAnimations.posVec(0.6F, 0.2F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(16.625F, KeyframeAnimations.posVec(0.2F, 0.2F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.0F, KeyframeAnimations.posVec(0.6F, 0.2F, -0.6F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corpo", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(5.5833F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(1.8333F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 7.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(4.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.0F, KeyframeAnimations.degreeVec(-0.1091F, -2.4976F, 2.5024F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.2917F, KeyframeAnimations.degreeVec(7.2151F, -12.5381F, 3.1896F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.7083F, KeyframeAnimations.degreeVec(4.22F, -9.31F, 1.94F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.9583F, KeyframeAnimations.degreeVec(-1.9984F, -8.6673F, 6.828F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.25F, KeyframeAnimations.degreeVec(-1.0432F, -23.3491F, 3.1267F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.9583F, KeyframeAnimations.degreeVec(-1.04F, -23.35F, 3.13F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.4583F, KeyframeAnimations.degreeVec(-1.2175F, -38.3471F, 3.4732F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.degreeVec(-4.1146F, -63.2831F, 6.843F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5833F, KeyframeAnimations.degreeVec(-17.2779F, -72.8822F, 14.5359F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4167F, KeyframeAnimations.degreeVec(14.1956F, -84.0354F, -17.7575F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.degreeVec(16.1956F, -84.0354F, -17.7575F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(19.9583F, KeyframeAnimations.degreeVec(14.1956F, -84.0354F, -17.7575F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(1.8333F, KeyframeAnimations.posVec(-1.5F, 0.2F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(4.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.0F, KeyframeAnimations.posVec(-0.6F, 0.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.2917F, KeyframeAnimations.posVec(-0.4F, -0.3F, -0.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.7083F, KeyframeAnimations.posVec(0.29F, -0.04F, -0.35F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.9583F, KeyframeAnimations.posVec(0.38F, 0.0F, -0.92F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.25F, KeyframeAnimations.posVec(2.24F, 0.03F, -2.19F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.9583F, KeyframeAnimations.posVec(2.24F, 0.03F, -2.19F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.4583F, KeyframeAnimations.posVec(1.04F, 1.03F, -2.79F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(1.64F, 1.03F, -1.39F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.2083F, KeyframeAnimations.posVec(9.94F, 1.03F, 0.01F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5833F, KeyframeAnimations.posVec(10.54F, 1.43F, 3.01F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4167F, KeyframeAnimations.posVec(10.74F, 1.43F, 4.61F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.posVec(10.74F, 0.93F, 4.21F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(19.9583F, KeyframeAnimations.posVec(10.74F, 1.43F, 4.61F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(0.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(4.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(5.5833F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(2.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 5.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(4.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.0F, KeyframeAnimations.degreeVec(5.0F, 0.0F, -5.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.25F, KeyframeAnimations.degreeVec(4.9811F, -0.4352F, -0.0189F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(7.375F, KeyframeAnimations.degreeVec(4.98F, -0.44F, -0.02F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.9583F, KeyframeAnimations.degreeVec(4.98F, -0.44F, -0.02F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.5F, KeyframeAnimations.degreeVec(29.9988F, -35.5725F, -22.4097F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.degreeVec(32.0767F, -68.5269F, -25.8464F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.1667F, KeyframeAnimations.degreeVec(-3.2786F, -75.5882F, -3.1734F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.375F, KeyframeAnimations.degreeVec(183.4217F, -63.2749F, -179.4637F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(15.875F, KeyframeAnimations.degreeVec(173.1556F, -9.3237F, -180.5896F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4167F, KeyframeAnimations.degreeVec(173.16F, -9.32F, -180.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.degreeVec(177.7251F, -8.3634F, -178.1315F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.0F, KeyframeAnimations.degreeVec(173.16F, -9.32F, -180.59F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(2.0F, KeyframeAnimations.posVec(-1.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(4.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.0F, KeyframeAnimations.posVec(0.6F, 0.0F, 1.4F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.25F, KeyframeAnimations.posVec(-0.1F, -0.4F, 1.4F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(7.375F, KeyframeAnimations.posVec(0.11F, -0.43F, 1.19F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.9583F, KeyframeAnimations.posVec(0.61F, -0.73F, 1.19F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.5F, KeyframeAnimations.posVec(-0.39F, 3.07F, 7.69F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(-6.29F, 0.97F, 10.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.2917F, KeyframeAnimations.posVec(-11.08F, 1.1F, 13.02F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.4167F, KeyframeAnimations.posVec(-10.58F, 1.14F, 10.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(15.875F, KeyframeAnimations.posVec(-14.79F, 0.47F, 4.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4167F, KeyframeAnimations.posVec(-14.79F, 0.47F, 4.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.posVec(-14.99F, 0.97F, 3.79F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.0F, KeyframeAnimations.posVec(-14.79F, 0.47F, 4.59F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(0.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(4.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(5.5833F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.9583F, KeyframeAnimations.degreeVec(0.0F, -2.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(8.7083F, KeyframeAnimations.degreeVec(0.0F, -2.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.0F, KeyframeAnimations.degreeVec(0.0F, -25.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.25F, KeyframeAnimations.degreeVec(0.0F, -27.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0417F, KeyframeAnimations.degreeVec(0.0F, -27.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.4167F, KeyframeAnimations.degreeVec(10.0F, -43.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.degreeVec(4.062F, -63.4697F, -1.914F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.25F, KeyframeAnimations.degreeVec(168.5047F, -82.3402F, -172.5907F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5F, KeyframeAnimations.degreeVec(178.9271F, -15.0423F, -180.8986F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.9583F, KeyframeAnimations.posVec(0.61F, 0.0F, -0.19F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(8.7083F, KeyframeAnimations.posVec(0.61F, 0.0F, -0.19F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.0F, KeyframeAnimations.posVec(-0.39F, 1.0F, 0.81F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(9.25F, KeyframeAnimations.posVec(-0.19F, 0.0F, 1.01F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0417F, KeyframeAnimations.posVec(-0.19F, 0.0F, 1.01F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.4167F, KeyframeAnimations.posVec(-2.99F, 0.4F, 2.51F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(-2.99F, -0.1F, 3.61F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5F, KeyframeAnimations.posVec(-5.69F, -0.1F, -0.59F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(5.5833F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(6.0F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(6.0823F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(6.0833F, KeyframeAnimations.degreeVec(0.0F, 10.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(6.2917F, KeyframeAnimations.degreeVec(3.6622F, 14.9416F, -5.1754F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(-0.0185F, 11.7379F, -0.026F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.5F, KeyframeAnimations.degreeVec(-0.0216F, -33.2621F, -0.0103F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.9583F, KeyframeAnimations.degreeVec(-0.0402F, -63.2621F, 0.0137F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.0833F, KeyframeAnimations.degreeVec(-35.2043F, -81.8758F, 35.4248F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.25F, KeyframeAnimations.degreeVec(-152.3298F, -84.3489F, 153.7795F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.5F, KeyframeAnimations.degreeVec(-179.9747F, -44.2379F, 179.9602F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(15.9167F, KeyframeAnimations.degreeVec(-179.9811F, -16.7379F, 179.9724F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(6.0F, KeyframeAnimations.posVec(1.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(6.0823F, KeyframeAnimations.posVec(1.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(6.0833F, KeyframeAnimations.posVec(1.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.2917F, KeyframeAnimations.posVec(2.0F, 0.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0F, KeyframeAnimations.posVec(1.3F, 0.0F, 0.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.5F, KeyframeAnimations.posVec(0.3F, 2.0F, 2.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(-2.7F, 0.0F, 3.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.5F, KeyframeAnimations.posVec(-5.7F, 1.0F, 2.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(15.9167F, KeyframeAnimations.posVec(-5.7F, 0.0F, -0.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(5.5833F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("testa", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(1.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(1.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -10.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(5.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(5.5823F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(5.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.9583F, KeyframeAnimations.degreeVec(-7.4355F, 6.6346F, -10.9484F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(6.2917F, KeyframeAnimations.degreeVec(-1.8127F, -3.5773F, -12.184F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(7.0407F, KeyframeAnimations.degreeVec(-1.8127F, -3.5773F, -12.184F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(7.0417F, KeyframeAnimations.degreeVec(-1.81F, -3.58F, -12.18F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.875F, KeyframeAnimations.degreeVec(-19.95F, -14.13F, -41.16F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.5F, KeyframeAnimations.degreeVec(-19.5807F, -13.7536F, -46.774F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.degreeVec(79.2891F, -52.4785F, -135.2104F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.5F, KeyframeAnimations.degreeVec(109.6628F, -15.4391F, -138.8094F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(15.875F, KeyframeAnimations.degreeVec(115.9044F, -7.7479F, -149.3175F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.4583F, KeyframeAnimations.degreeVec(115.9044F, -7.7479F, -149.3175F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.degreeVec(116.2718F, 2.4695F, -136.0397F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.0F, KeyframeAnimations.degreeVec(115.9044F, -7.7479F, -149.3175F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(25.0F, KeyframeAnimations.degreeVec(115.5052F, -9.0493F, -146.5851F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("testa", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(1.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(1.625F, KeyframeAnimations.posVec(-0.4F, 0.2F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(5.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(5.5823F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(5.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(5.9583F, KeyframeAnimations.posVec(-0.5F, 1.0F, 1.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(6.2917F, KeyframeAnimations.posVec(0.0F, 0.4F, -0.1F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(7.0407F, KeyframeAnimations.posVec(0.0F, 0.4F, -0.1F), AnimationChannel.Interpolations.LINEAR), new Keyframe(7.0417F, KeyframeAnimations.posVec(0.0F, 0.4F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(9.875F, KeyframeAnimations.posVec(0.78F, 2.35F, -0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.5F, KeyframeAnimations.posVec(-2.22F, 4.45F, 2.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.9583F, KeyframeAnimations.posVec(-2.22F, 4.75F, 7.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.5F, KeyframeAnimations.posVec(-3.22F, 4.75F, 9.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(15.875F, KeyframeAnimations.posVec(-4.42F, 4.75F, 7.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(16.4583F, KeyframeAnimations.posVec(-4.42F, 4.75F, 7.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.625F, KeyframeAnimations.posVec(-4.42F, 4.75F, 7.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(20.0F, KeyframeAnimations.posVec(-4.42F, 4.75F, 7.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(25.0F, KeyframeAnimations.posVec(-4.22F, 4.75F, 7.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("testa",
					new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(1.5F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(5.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("main_eye", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(8.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(12.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("main_eye", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(8.625F, KeyframeAnimations.posVec(-2.4F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.2083F, KeyframeAnimations.posVec(-2.4F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(12.375F, KeyframeAnimations.posVec(0.1F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(16.3333F, KeyframeAnimations.posVec(-1.2F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(16.5833F, KeyframeAnimations.posVec(-0.2F, 0.0F, -0.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(16.875F, KeyframeAnimations.posVec(-0.2F, -1.0F, 1.4F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(17.9167F, KeyframeAnimations.posVec(-1.2F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(19.9583F, KeyframeAnimations.posVec(-1.9F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(24.9583F, KeyframeAnimations.posVec(-2.2F, -0.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corna",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.2083F, KeyframeAnimations.degreeVec(51.3109F, 9.5026F, 11.6255F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(15.875F, KeyframeAnimations.degreeVec(79.8201F, 38.542F, 73.9008F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(25.0F, KeyframeAnimations.degreeVec(70.8201F, 38.542F, 73.9008F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corna", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.2083F, KeyframeAnimations.posVec(-0.8F, -3.4F, 2.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(15.875F, KeyframeAnimations.posVec(-4.9F, -1.1F, 4.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(25.0F, KeyframeAnimations.posVec(-5.2F, -0.9F, 3.7F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corna", new AnimationChannel(AnimationChannel.Targets.SCALE, new Keyframe(10.2083F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corno_esposto",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.7917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(16.2083F, KeyframeAnimations.degreeVec(33.2307F, -13.3598F, -74.9787F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(19.9583F, KeyframeAnimations.degreeVec(21.8004F, -28.7739F, -44.1328F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(25.0F, KeyframeAnimations.degreeVec(13.9743F, -38.1734F, -28.8641F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corno_esposto", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.7917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.125F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(16.2083F, KeyframeAnimations.posVec(1.5F, 2.6F, 1.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(19.9583F, KeyframeAnimations.posVec(1.3F, 1.3F, 1.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(25.0F, KeyframeAnimations.posVec(1.3F, 1.0F, 1.4F), AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}
