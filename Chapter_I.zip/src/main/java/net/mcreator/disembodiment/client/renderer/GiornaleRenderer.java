
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.GiornaleEntity;
import net.mcreator.disembodiment.client.model.animations.giornaleAnimation;
import net.mcreator.disembodiment.client.model.Modelgiornale;

public class GiornaleRenderer extends MobRenderer<GiornaleEntity, Modelgiornale<GiornaleEntity>> {
	public GiornaleRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelgiornale.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(GiornaleEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/giornale.png");
	}

	private static final class AnimatedModel extends Modelgiornale<GiornaleEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<GiornaleEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(GiornaleEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, giornaleAnimation.sfoglia, ageInTicks, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(GiornaleEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
