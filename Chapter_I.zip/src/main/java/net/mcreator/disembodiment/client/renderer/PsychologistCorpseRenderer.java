
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.PsychologistCorpseEntity;
import net.mcreator.disembodiment.client.model.animations.psychologist_headlessAnimation;
import net.mcreator.disembodiment.client.model.Modelpsychologist_headless;

public class PsychologistCorpseRenderer extends MobRenderer<PsychologistCorpseEntity, Modelpsychologist_headless<PsychologistCorpseEntity>> {
	public PsychologistCorpseRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelpsychologist_headless.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(PsychologistCorpseEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/psychologist_headless.png");
	}

	private static final class AnimatedModel extends Modelpsychologist_headless<PsychologistCorpseEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<PsychologistCorpseEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(PsychologistCorpseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, psychologist_headlessAnimation.dead, ageInTicks, 0.5f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(PsychologistCorpseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
