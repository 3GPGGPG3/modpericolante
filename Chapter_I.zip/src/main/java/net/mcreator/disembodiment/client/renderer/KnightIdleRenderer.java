
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.disembodiment.entity.KnightIdleEntity;
import net.mcreator.disembodiment.client.model.Modelknight;

public class KnightIdleRenderer extends MobRenderer<KnightIdleEntity, Modelknight<KnightIdleEntity>> {
	public KnightIdleRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelknight<KnightIdleEntity>(context.bakeLayer(Modelknight.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(KnightIdleEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/knight.png");
	}
}
