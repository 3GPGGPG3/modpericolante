package net.mcreator.disembodiment.client.model.animations;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.animation.Keyframe;
import net.minecraft.client.animation.AnimationDefinition;
import net.minecraft.client.animation.AnimationChannel;

// Save this class in your mod and generate all required imports
/**
 * Made with Blockbench 4.12.6 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class knightAnimation {
	public static final AnimationDefinition knight_seek = AnimationDefinition.Builder.withLength(50.5417F)
			.addAnimation("corpo", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(36.0833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(36.624F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(36.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.875F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 7.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(40.375F, KeyframeAnimations.degreeVec(22.5F, 0.0F, 7.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4583F, KeyframeAnimations.degreeVec(72.6187F, 7.1388F, -2.0672F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.5833F, KeyframeAnimations.degreeVec(82.6187F, 7.1388F, -2.0672F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(50.0F, KeyframeAnimations.degreeVec(88.6187F, 7.1388F, -2.0672F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corpo", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(36.0833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(36.624F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(36.625F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.875F, KeyframeAnimations.posVec(0.0F, -0.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(40.375F, KeyframeAnimations.posVec(0.0F, 1.4F, 1.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4583F, KeyframeAnimations.posVec(0.0F, 7.0F, -1.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.5833F, KeyframeAnimations.posVec(0.0F, 7.0F, -3.8F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(50.0F, KeyframeAnimations.posVec(0.0F, 7.0F, -4.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("knife",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(17.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(19.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(20.4167F, KeyframeAnimations.degreeVec(135.6872F, 17.607F, -81.8128F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.8333F, KeyframeAnimations.degreeVec(188.839F, 16.1988F, -116.3717F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(21.375F, KeyframeAnimations.degreeVec(235.8951F, 29.4496F, -166.6438F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(22.2083F, KeyframeAnimations.degreeVec(269.0482F, 90.2299F, -104.4886F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(37.7917F, KeyframeAnimations.degreeVec(269.05F, 90.23F, -104.49F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("knife", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(17.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(18.0F, KeyframeAnimations.posVec(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(19.9583F, KeyframeAnimations.posVec(0.0F, 1.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(20.1667F, KeyframeAnimations.posVec(0.25F, 4.14F, -0.12F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(20.4167F, KeyframeAnimations.posVec(3.2F, 7.9F, -1.8F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.75F, KeyframeAnimations.posVec(5.5F, 9.47F, -4.36F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(20.8333F, KeyframeAnimations.posVec(5.5F, 9.47F, -4.56F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(21.375F, KeyframeAnimations.posVec(10.1F, 8.67F, -6.86F), AnimationChannel.Interpolations.LINEAR), new Keyframe(22.2083F, KeyframeAnimations.posVec(24.2F, -2.13F, -5.56F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(37.7917F, KeyframeAnimations.posVec(24.2F, -2.13F, -5.56F), AnimationChannel.Interpolations.LINEAR), new Keyframe(38.3323F, KeyframeAnimations.posVec(24.2F, -2.13F, -5.56F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(38.3333F, KeyframeAnimations.posVec(16.2F, -47.13F, -34.56F), AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("head", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(2.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(2.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 5.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(3.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 7.5F), AnimationChannel.Interpolations.LINEAR), new Keyframe(3.6667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 35.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(4.0F, KeyframeAnimations.degreeVec(2.5024F, 2.4976F, 47.6091F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(21.9167F, KeyframeAnimations.degreeVec(2.5F, 2.5F, 47.61F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(23.6667F, KeyframeAnimations.degreeVec(2.5F, 2.5F, 47.61F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(26.0F, KeyframeAnimations.degreeVec(-1.0658F, 3.3707F, -14.9759F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(26.9167F, KeyframeAnimations.degreeVec(-1.4948F, 0.7035F, -22.4211F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(36.625F, KeyframeAnimations.degreeVec(-1.4948F, 0.7035F, -22.4211F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.875F, KeyframeAnimations.degreeVec(-1.35F, 0.9524F, -12.4232F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.375F, KeyframeAnimations.degreeVec(31.0052F, 0.7035F, -22.4211F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4583F, KeyframeAnimations.degreeVec(86.0052F, 0.7035F, -22.4211F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(89.0052F, 0.7035F, -22.4211F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("head", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(2.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(23.6667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(26.9167F, KeyframeAnimations.posVec(0.8F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(36.625F, KeyframeAnimations.posVec(0.8F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.875F, KeyframeAnimations.posVec(0.8F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(40.375F, KeyframeAnimations.posVec(0.8F, 8.0F, -0.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4583F, KeyframeAnimations.posVec(0.4F, 21.2F, -12.9F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.5833F, KeyframeAnimations.posVec(0.4F, 21.6F, -16.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(0.4F, 22.0F, -16.8F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("arto_s_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(31.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(38.875F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(38.999F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(39.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(40.375F, KeyframeAnimations.degreeVec(12.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(14.8774F, -1.936F, 7.2472F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("arto_s_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(31.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(38.875F, KeyframeAnimations.posVec(0.0F, 0.25F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(38.999F, KeyframeAnimations.posVec(0.0F, 0.25F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(39.0F, KeyframeAnimations.posVec(0.0F, 0.25F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(40.375F, KeyframeAnimations.posVec(0.0F, 0.95F, 0.7F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(42.4583F, KeyframeAnimations.posVec(-1.0F, 7.95F, -5.3F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.posVec(-1.0F, 7.95F, -7.8F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.posVec(-2.3F, 6.65F, -8.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("arto_s_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.7083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.25F, KeyframeAnimations.degreeVec(-2.5588F, -17.4721F, -41.1898F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(19.7917F, KeyframeAnimations.degreeVec(-2.56F, -17.48F, -41.2F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.0F, KeyframeAnimations.degreeVec(-2.56F, -17.47F, -41.19F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.5F, KeyframeAnimations.degreeVec(18.9825F, -15.5173F, -20.4208F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.8333F, KeyframeAnimations.degreeVec(21.02F, -15.05F, -20.29F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(21.375F, KeyframeAnimations.degreeVec(18.98F, -15.52F, -20.42F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(22.1667F, KeyframeAnimations.degreeVec(8.5882F, -22.856F, 10.4507F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(35.875F, KeyframeAnimations.degreeVec(8.58F, -22.87F, 10.49F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(36.625F, KeyframeAnimations.degreeVec(8.59F, -22.86F, 10.45F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.875F, KeyframeAnimations.degreeVec(8.59F, -22.86F, 10.45F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(0.9082F, -24.3234F, 29.4941F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(42.4583F, KeyframeAnimations.degreeVec(86.6853F, -1.983F, -1.9632F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.degreeVec(86.1058F, 7.4213F, 27.4735F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.degreeVec(86.135F, 2.4328F, 27.813F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("arto_s_sx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(11.25F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(11.7083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.25F, KeyframeAnimations.posVec(1.5F, 1.5F, -2.3F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(19.7917F, KeyframeAnimations.posVec(1.5F, 1.5F, -2.3F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.0F, KeyframeAnimations.posVec(1.5F, 1.5F, -2.3F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(20.8333F, KeyframeAnimations.posVec(1.5F, 1.72F, -2.57F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(21.375F, KeyframeAnimations.posVec(1.5F, 1.5F, -2.3F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(22.1667F, KeyframeAnimations.posVec(1.5F, -1.5F, 1.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(35.875F, KeyframeAnimations.posVec(1.5F, -1.5F, 1.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(36.625F, KeyframeAnimations.posVec(1.5F, -1.5F, 1.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.875F, KeyframeAnimations.posVec(2.1F, -1.8F, 1.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(40.375F, KeyframeAnimations.posVec(0.0F, 0.1F, 2.7F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4583F, KeyframeAnimations.posVec(0.6F, 10.7F, -2.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.5833F, KeyframeAnimations.posVec(-0.6F, 9.4F, -5.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(-0.6F, 9.4F, -5.4F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx1",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.7917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.625F, KeyframeAnimations.degreeVec(-21.4243F, -3.0632F, -15.5007F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.25F, KeyframeAnimations.degreeVec(-13.029F, -0.9849F, -57.2759F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.625F, KeyframeAnimations.degreeVec(-14.7161F, -21.9754F, -48.9551F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(18.0F, KeyframeAnimations.degreeVec(-14.72F, -22.01F, -48.95F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(18.2917F, KeyframeAnimations.degreeVec(-14.72F, -21.98F, -48.96F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.8333F, KeyframeAnimations.degreeVec(-15.62F, -21.98F, -48.96F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(21.375F, KeyframeAnimations.degreeVec(-14.72F, -21.98F, -48.96F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(22.2083F, KeyframeAnimations.degreeVec(0.28F, -21.98F, -48.96F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(39.75F, KeyframeAnimations.degreeVec(0.28F, -21.98F, -48.96F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(3.8511F, -20.8684F, -40.8978F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx1", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.7917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(11.625F, KeyframeAnimations.posVec(0.0F, 2.2F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.625F, KeyframeAnimations.posVec(0.0F, 3.0F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(18.0F, KeyframeAnimations.posVec(0.0F, 3.0F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(18.2917F, KeyframeAnimations.posVec(0.0F, 3.0F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(18.875F, KeyframeAnimations.posVec(0.5F, 3.5F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.8333F, KeyframeAnimations.posVec(0.51F, 3.59F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(21.375F, KeyframeAnimations.posVec(0.5F, 3.5F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(22.2083F, KeyframeAnimations.posVec(0.5F, 2.3F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(39.75F, KeyframeAnimations.posVec(0.5F, 2.3F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.375F, KeyframeAnimations.posVec(0.5F, 1.7F, 0.4F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.25F, KeyframeAnimations.degreeVec(-40.0F, 0.0F, -42.5F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.9167F, KeyframeAnimations.degreeVec(-125.2282F, -45.7952F, -84.1851F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.4583F, KeyframeAnimations.degreeVec(-125.0199F, -53.1905F, -77.4459F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(17.5F, KeyframeAnimations.degreeVec(-125.02F, -53.19F, -77.45F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(18.0F, KeyframeAnimations.degreeVec(-124.8345F, -46.4654F, -70.042F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(19.0833F, KeyframeAnimations.degreeVec(-125.02F, -53.176F, -77.4346F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(19.9583F, KeyframeAnimations.degreeVec(-125.02F, -53.18F, -77.43F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.0833F, KeyframeAnimations.degreeVec(-125.0549F, -51.4975F, -75.5805F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.125F, KeyframeAnimations.degreeVec(-125.02F, -53.18F, -77.43F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.4167F, KeyframeAnimations.degreeVec(-122.8798F, -36.5587F, -58.5688F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(20.8333F, KeyframeAnimations.degreeVec(-98.51F, -24.1F, -39.6F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(22.2083F, KeyframeAnimations.degreeVec(8.1563F, 24.676F, 37.0765F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(39.75F, KeyframeAnimations.degreeVec(8.16F, 24.68F, 37.08F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(-62.3226F, -5.3876F, -38.8894F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciosx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(11.2917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.25F, KeyframeAnimations.posVec(-1.3F, 1.2F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.9167F, KeyframeAnimations.posVec(-4.3F, 2.6F, 2.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(13.4583F, KeyframeAnimations.posVec(-3.4F, 2.6F, 2.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(17.5F, KeyframeAnimations.posVec(-3.4F, 2.6F, 2.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(18.0F, KeyframeAnimations.posVec(-3.4F, 3.0F, 2.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(19.0833F, KeyframeAnimations.posVec(-3.1F, 3.0F, 1.7F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(19.9583F, KeyframeAnimations.posVec(-3.1F, 3.0F, 1.7F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(20.4167F, KeyframeAnimations.posVec(-2.1F, 3.0F, 1.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(20.8333F, KeyframeAnimations.posVec(-1.94F, 2.17F, 0.99F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(22.2083F, KeyframeAnimations.posVec(-1.6F, -1.5F, -1.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(39.75F, KeyframeAnimations.posVec(-1.6F, -1.5F, -1.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.375F, KeyframeAnimations.posVec(-1.3F, 1.4F, -0.6F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("manosx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.8333F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.0F, KeyframeAnimations.degreeVec(7.5F, 0.0F, -7.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(13.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.4583F, KeyframeAnimations.degreeVec(6.7959F, -4.6525F, -24.7778F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("manosx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.8333F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.125F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(13.4583F, KeyframeAnimations.posVec(0.0F, 0.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.6667F, KeyframeAnimations.degreeVec(14.87F, 5.9923F, 13.6567F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(14.0F, KeyframeAnimations.degreeVec(-24.1248F, -13.097F, -2.2653F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.1667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(14.0F, KeyframeAnimations.degreeVec(-4.227F, -6.0478F, -5.9822F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx3",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.7083F, KeyframeAnimations.degreeVec(-15.6264F, -10.5825F, -10.809F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_sx3",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.875F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.7083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.2F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.5F, KeyframeAnimations.degreeVec(-10.0F, 0.0F, -32.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.75F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.5F, KeyframeAnimations.posVec(0.0F, 0.2F, 0.1F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(12.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(14.5833F, KeyframeAnimations.degreeVec(-15.418F, 1.2024F, -21.0222F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx2",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(12.9583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.2917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx3",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(12.8333F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.3333F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(14.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -32.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_sx3",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(12.8333F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.3333F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -15.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.5417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.75F, KeyframeAnimations.degreeVec(2.613F, 9.6559F, -9.7793F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.375F, KeyframeAnimations.posVec(-0.6F, 0.3F, 0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.5417F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.2917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(13.75F, KeyframeAnimations.posVec(-1.0F, 0.0F, 0.2F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.3333F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.0833F, KeyframeAnimations.degreeVec(-17.829F, -9.7233F, -15.138F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.4167F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(13.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.4167F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -37.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx2",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.3333F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.4167F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx3",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.7083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -27.5F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.7917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_sx3", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.7083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.375F, KeyframeAnimations.posVec(-0.1F, 0.4F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.7917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0833F, KeyframeAnimations.degreeVec(-9.592F, -3.5634F, -16.613F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(11.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(11.625F, KeyframeAnimations.degreeVec(-12.5F, 0.0F, -20.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.0417F, KeyframeAnimations.degreeVec(2.6243F, 5.1562F, -11.428F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0833F, KeyframeAnimations.posVec(0.0F, 0.2F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(11.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0833F, KeyframeAnimations.degreeVec(-10.1716F, -5.5772F, -12.1351F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(11.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(11.875F, KeyframeAnimations.degreeVec(-13.2359F, -6.2909F, -3.3488F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.0F, KeyframeAnimations.degreeVec(-18.9969F, -10.328F, -9.9055F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx2",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0833F, KeyframeAnimations.posVec(0.0F, 0.2F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(11.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx3",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0833F, KeyframeAnimations.degreeVec(-7.1625F, -7.7979F, -10.1795F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.25F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.375F, KeyframeAnimations.degreeVec(25.0944F, 7.4733F, 24.3603F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_sx3", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(10.0833F, KeyframeAnimations.posVec(-0.1F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(10.25F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.375F, KeyframeAnimations.posVec(-0.1F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_sx1",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(11.5417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.4167F, KeyframeAnimations.degreeVec(15.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_sx1",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.6667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_sx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(11.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.375F, KeyframeAnimations.degreeVec(25.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.6667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(13.5F, KeyframeAnimations.degreeVec(9.201F, -18.1064F, 38.1042F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_sx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(11.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(12.375F, KeyframeAnimations.posVec(0.0F, 0.5F, -0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(12.6667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(13.5F, KeyframeAnimations.posVec(0.0F, -0.4F, 0.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("spalladx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(30.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(37.0F, KeyframeAnimations.degreeVec(0.0F, -10.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.7083F, KeyframeAnimations.degreeVec(-0.7745F, -10.5291F, 2.5632F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(42.3333F, KeyframeAnimations.degreeVec(-30.7745F, -10.5291F, 2.5632F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.degreeVec(-42.1682F, -25.6115F, 24.0865F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("spalladx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(30.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(34.2917F, KeyframeAnimations.posVec(-0.4F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(42.3333F, KeyframeAnimations.posVec(-0.4F, -0.9F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.5833F, KeyframeAnimations.posVec(-0.4F, 0.9F, -0.9F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx1",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(30.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(34.2917F, KeyframeAnimations.degreeVec(0.0F, -12.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(37.0F, KeyframeAnimations.degreeVec(-10.0F, -12.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.7083F, KeyframeAnimations.degreeVec(-35.106F, -22.6561F, -32.2961F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(-23.618F, -12.4386F, -34.9653F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(42.3333F, KeyframeAnimations.degreeVec(-22.1172F, -50.7777F, -96.5948F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.degreeVec(-6.3416F, -40.222F, -130.8953F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx1", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(30.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(34.2917F, KeyframeAnimations.posVec(0.3F, 0.0F, -0.4F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(37.0F, KeyframeAnimations.posVec(0.3F, 0.5F, -0.4F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.7083F, KeyframeAnimations.posVec(0.3F, 2.8F, -0.9F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(40.375F, KeyframeAnimations.posVec(0.3F, 2.4F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.3333F, KeyframeAnimations.posVec(-1.0F, 1.8F, 0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.5833F, KeyframeAnimations.posVec(1.7F, 3.2F, -2.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(30.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(32.7917F, KeyframeAnimations.degreeVec(40.0F, 0.0F, 57.5F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(35.3333F, KeyframeAnimations.degreeVec(75.4529F, -39.7336F, 56.4596F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(37.1667F, KeyframeAnimations.degreeVec(250.521F, -57.1197F, -68.897F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(37.4573F, KeyframeAnimations.degreeVec(250.521F, -57.1197F, -68.897F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(37.4583F, KeyframeAnimations.degreeVec(250.521F, -57.1197F, -68.897F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.6667F, KeyframeAnimations.degreeVec(278.8748F, 15.5277F, -56.264F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(38.7907F, KeyframeAnimations.degreeVec(278.8748F, 15.5277F, -56.264F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(38.7917F, KeyframeAnimations.degreeVec(278.8748F, 15.5277F, -56.264F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(261.1604F, -9.1893F, -60.051F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(46.8333F, KeyframeAnimations.degreeVec(243.6604F, -9.1893F, -60.051F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("bracciodx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(30.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(32.7917F, KeyframeAnimations.posVec(1.0F, 6.1F, 1.4F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(35.3333F, KeyframeAnimations.posVec(2.6F, 7.7F, -1.8F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(37.1667F, KeyframeAnimations.posVec(4.9F, 1.3F, -6.3F), AnimationChannel.Interpolations.LINEAR), new Keyframe(37.4573F, KeyframeAnimations.posVec(4.9F, 1.3F, -6.3F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(37.4583F, KeyframeAnimations.posVec(4.9F, 1.3F, -6.3F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(38.6667F, KeyframeAnimations.posVec(3.22F, -3.31F, -0.81F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(38.7907F, KeyframeAnimations.posVec(3.22F, -3.31F, -0.81F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(38.7917F, KeyframeAnimations.posVec(3.22F, -3.31F, -0.81F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.375F, KeyframeAnimations.posVec(3.22F, -2.51F, -2.81F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.8333F, KeyframeAnimations.posVec(2.82F, -2.51F, -2.81F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("manodx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(31.6667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(35.0417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -25.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.6667F, KeyframeAnimations.degreeVec(7.096F, -18.7472F, -93.6728F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.375F, KeyframeAnimations.degreeVec(8.1049F, -13.1305F, -98.1348F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(42.9583F, KeyframeAnimations.degreeVec(8.1F, -13.13F, -98.13F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.875F, KeyframeAnimations.degreeVec(-26.2375F, -27.8698F, -44.9823F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(46.8333F, KeyframeAnimations.degreeVec(-62.2852F, -18.8484F, -22.5108F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("manodx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(31.6667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(35.0417F, KeyframeAnimations.posVec(0.1F, -0.7F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(38.6667F, KeyframeAnimations.posVec(1.7F, -1.6F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(39.5833F, KeyframeAnimations.posVec(1.29F, -1.38F, -0.63F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.375F, KeyframeAnimations.posVec(1.7F, -1.1F, -0.6F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(42.9583F, KeyframeAnimations.posVec(1.7F, -1.1F, -0.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.875F, KeyframeAnimations.posVec(0.9F, -1.1F, -1.3F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(46.8333F, KeyframeAnimations.posVec(0.9F, -0.4F, -1.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(41.2083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.9167F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -42.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -42.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -42.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 22.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_dx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(41.2083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.9167F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.posVec(-0.1F, -0.5F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(-0.1F, -0.5F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(-0.1F, -0.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(-0.1F, -0.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(0.3F, 0.1F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_dx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(36.5417F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(39.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -82.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -86.39F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4167F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -85.97F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -35.97F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -35.97F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -35.97F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(17.3164F, -23.3665F, 32.2847F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(1.3465F, -20.5782F, 64.2162F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("a_dx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(36.5417F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(39.125F, KeyframeAnimations.posVec(0.0F, -1.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(42.0F, KeyframeAnimations.posVec(0.0F, -1.36F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.4167F, KeyframeAnimations.posVec(0.0F, -1.35F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.posVec(-0.1F, -0.55F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(-0.1F, -0.55F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(-0.1F, -0.55F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(0.4F, 0.35F, -0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(1.0F, 0.35F, -0.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(41.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -32.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -32.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -32.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(-1.4319F, -14.7272F, 32.7845F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_dx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(41.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.posVec(0.1F, 0.0F, -0.2F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(0.1F, 0.0F, -0.2F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.1F, 0.0F, -0.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(-0.1F, 0.0F, -0.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(0.4F, 0.2F, -0.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(34.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 17.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(41.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 17.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(42.0F, KeyframeAnimations.degreeVec(16.1031F, 5.7997F, -62.585F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.375F, KeyframeAnimations.degreeVec(16.1F, 5.8F, -62.59F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4573F, KeyframeAnimations.degreeVec(16.1F, 5.8F, -62.59F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.degreeVec(16.1F, 5.8F, -62.59F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(10.0105F, 1.6243F, -19.87F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(-4.8479F, 2.6781F, 23.2209F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_dx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(34.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.125F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(42.0F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.2F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.2F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.2F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, -1.0F, 0.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(46.375F, KeyframeAnimations.posVec(-0.2F, -0.3F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(0.1F, -0.1F, -0.1F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_dx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(34.5F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(37.5833F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.75F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -90.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -90.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -12.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 25.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(4.2696F, -0.8345F, 55.0826F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("mi_dx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(34.5F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(37.5833F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(38.75F, KeyframeAnimations.posVec(0.9F, -1.5F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(41.125F, KeyframeAnimations.posVec(0.9F, -1.5F, -0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(41.9583F, KeyframeAnimations.posVec(0.5F, -0.4F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(44.375F, KeyframeAnimations.posVec(0.5F, -0.4F, -0.1F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4573F, KeyframeAnimations.posVec(0.5F, -0.4F, -0.1F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4583F, KeyframeAnimations.posVec(0.5F, -0.4F, -0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(46.375F, KeyframeAnimations.posVec(0.2F, 0.4F, -0.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(0.7F, 1.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("spallasx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(43.1667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.degreeVec(0.0F, -22.5F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("spallasx",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(43.1667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(44.5833F, KeyframeAnimations.posVec(-1.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx1", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(35.875F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(36.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(39.125F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 12.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.3333F, KeyframeAnimations.degreeVec(-9.2104F, -3.7717F, 11.7701F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(43.1667F, KeyframeAnimations.degreeVec(-19.2104F, -3.7717F, 11.7701F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(-19.0377F, -4.5908F, 9.4018F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx1", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(35.875F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(36.625F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(39.125F, KeyframeAnimations.posVec(0.2F, 0.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.3333F, KeyframeAnimations.posVec(0.2F, 0.5F, 1.4F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(43.1667F, KeyframeAnimations.posVec(0.2F, 2.4F, 3.1F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(0.2F, 2.4F, 2.8F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(37.7083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.1667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(41.0417F, KeyframeAnimations.degreeVec(18.7296F, -9.2253F, 16.7244F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(43.1667F, KeyframeAnimations.degreeVec(48.3012F, -16.8902F, 13.6438F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.degreeVec(49.1581F, -11.901F, 10.2016F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambadx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(37.7083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.1667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(41.0417F, KeyframeAnimations.posVec(-0.7F, -1.5F, 0.5F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(43.1667F, KeyframeAnimations.posVec(-0.7F, -3.5F, 1.5F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("piededx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(39.2917F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.5F, KeyframeAnimations.degreeVec(14.6599F, 3.2113F, -12.0868F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(43.1667F, KeyframeAnimations.degreeVec(32.1599F, 3.2113F, -12.0868F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.degreeVec(25.1599F, 3.2113F, -12.0868F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("piededx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(39.2917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.5F, KeyframeAnimations.posVec(0.0F, -0.3F, -0.8F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(43.1667F, KeyframeAnimations.posVec(-0.8F, 0.4F, -1.7F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(-0.3F, 0.4F, -1.7F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx1",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(35.875F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(36.625F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(39.125F, KeyframeAnimations.degreeVec(-1.6877F, -1.6987F, -9.7603F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(40.3333F, KeyframeAnimations.degreeVec(-0.297F, 0.0155F, -4.1389F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.degreeVec(-5.27F, -2.7007F, -2.8649F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx1", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(35.875F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(36.625F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(39.125F, KeyframeAnimations.posVec(-0.3F, -0.3F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(40.3333F, KeyframeAnimations.posVec(-0.3F, -0.3F, 0.4F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(43.1667F, KeyframeAnimations.posVec(1.8F, -0.3F, 2.6F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.posVec(1.4F, -0.3F, 2.6F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx2",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(37.7083F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(38.1667F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(41.0417F, KeyframeAnimations.degreeVec(37.5186F, 0.7118F, 14.9832F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(43.1667F, KeyframeAnimations.degreeVec(37.6334F, 1.1731F, 24.9733F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.degreeVec(31.5991F, 0.7245F, 22.0068F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gambasx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(37.7083F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(38.1667F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(41.0417F, KeyframeAnimations.posVec(-0.9F, -1.7F, 3.8F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(43.1667F, KeyframeAnimations.posVec(-2.1F, -1.7F, 3.8F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(-2.1F, -1.7F, 3.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("piedesx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(38.9583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(39.875F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(41.6667F, KeyframeAnimations.degreeVec(-17.5F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(43.125F, KeyframeAnimations.degreeVec(10.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("piedesx",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(38.9583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(39.875F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(14.8085F, -4.5344F, 6.5533F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(42.3085F, -4.5344F, 6.5533F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_dx", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.1F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(0.0F, 0.5F, 0.1F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_dx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(24.7219F, -12.1608F, -2.8221F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(50.3603F, 8.0815F, -12.7177F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("p_dx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(-0.1F, 0.3F, -0.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(-0.1F, 0.3F, -0.6F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_dx", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(-5.7559F, -9.3542F, 21.5159F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(-4.0718F, -30.1141F, 37.4357F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
							new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(49.9583F, KeyframeAnimations.posVec(0.4F, 0.5F, -0.3F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_dx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(18.1945F, -32.4851F, 36.932F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(4.4279F, -40.5258F, 59.8187F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("i_dx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(0.4F, 0.3F, -0.5F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(0.7F, 0.4F, -0.6F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_dx2", new AnimationChannel(AnimationChannel.Targets.ROTATION, new Keyframe(44.375F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.degreeVec(18.2803F, -19.7415F, 22.6426F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(49.9583F, KeyframeAnimations.degreeVec(10.157F, -28.7828F, 51.7144F), AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("m_dx2", new AnimationChannel(AnimationChannel.Targets.POSITION, new Keyframe(44.375F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR),
					new Keyframe(44.4573F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.LINEAR), new Keyframe(44.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F), AnimationChannel.Interpolations.CATMULLROM),
					new Keyframe(46.375F, KeyframeAnimations.posVec(0.5F, 0.1F, -0.2F), AnimationChannel.Interpolations.CATMULLROM), new Keyframe(49.9583F, KeyframeAnimations.posVec(0.9F, 0.4F, -0.2F), AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}
