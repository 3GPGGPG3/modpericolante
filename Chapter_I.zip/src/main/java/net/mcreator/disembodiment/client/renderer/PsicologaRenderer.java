
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import net.mcreator.disembodiment.entity.PsicologaEntity;

public class PsicologaRenderer extends HumanoidMobRenderer<PsicologaEntity, HumanoidModel<PsicologaEntity>> {
	public PsicologaRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<PsicologaEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(PsicologaEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/psychologista.png");
	}
}
