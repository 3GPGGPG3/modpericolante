
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.procedures.EyesInTheDarkChasePlaybackCondition2Procedure;
import net.mcreator.disembodiment.entity.EyesInTheDarkChaseEntity;
import net.mcreator.disembodiment.client.model.animations.eyesinthedark_chaseAnimation;
import net.mcreator.disembodiment.client.model.animations.eyesinthedark_chase2Animation;
import net.mcreator.disembodiment.client.model.Modeleyesinthedark_chase;

public class EyesInTheDarkChaseRenderer extends MobRenderer<EyesInTheDarkChaseEntity, Modeleyesinthedark_chase<EyesInTheDarkChaseEntity>> {
	public EyesInTheDarkChaseRenderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modeleyesinthedark_chase.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(EyesInTheDarkChaseEntity entity) {
		return new ResourceLocation("disembodiment:textures/entities/eyesinthedark.png");
	}

	private static final class AnimatedModel extends Modeleyesinthedark_chase<EyesInTheDarkChaseEntity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<EyesInTheDarkChaseEntity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(EyesInTheDarkChaseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, eyesinthedark_chaseAnimation.idle_chase, ageInTicks, 1f);
				if (EyesInTheDarkChasePlaybackCondition2Procedure.execute(entity))
					this.animateWalk(eyesinthedark_chase2Animation.chase_walk, limbSwing, limbSwingAmount, 1f, 1f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(EyesInTheDarkChaseEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
