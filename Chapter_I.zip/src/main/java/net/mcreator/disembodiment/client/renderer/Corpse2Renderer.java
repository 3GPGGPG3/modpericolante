
package net.mcreator.disembodiment.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.HierarchicalModel;

import net.mcreator.disembodiment.entity.Corpse2Entity;
import net.mcreator.disembodiment.client.model.animations.corpse2Animation;
import net.mcreator.disembodiment.client.model.Modelcorpse2;

public class Corpse2Renderer extends MobRenderer<Corpse2Entity, Modelcorpse2<Corpse2Entity>> {
	public Corpse2Renderer(EntityRendererProvider.Context context) {
		super(context, new AnimatedModel(context.bakeLayer(Modelcorpse2.LAYER_LOCATION)), 0f);
	}

	@Override
	public ResourceLocation getTextureLocation(Corpse2Entity entity) {
		return new ResourceLocation("disembodiment:textures/entities/dead.png");
	}

	private static final class AnimatedModel extends Modelcorpse2<Corpse2Entity> {
		private final ModelPart root;
		private final HierarchicalModel animator = new HierarchicalModel<Corpse2Entity>() {
			@Override
			public ModelPart root() {
				return root;
			}

			@Override
			public void setupAnim(Corpse2Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
				this.root().getAllParts().forEach(ModelPart::resetPose);
				this.animate(entity.animationState0, corpse2Animation.hang, ageInTicks, 0.5f);
			}
		};

		public AnimatedModel(ModelPart root) {
			super(root);
			this.root = root;
		}

		@Override
		public void setupAnim(Corpse2Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
			animator.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
			super.setupAnim(entity, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
		}
	}
}
