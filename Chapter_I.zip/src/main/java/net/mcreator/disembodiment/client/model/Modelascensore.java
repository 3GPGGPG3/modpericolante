package net.mcreator.disembodiment.client.model;

import net.minecraft.world.entity.Entity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.EntityModel;

import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.PoseStack;

// Made with Blockbench 5.0.7
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports
public class Modelascensore<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(new ResourceLocation("disembodiment", "modelascensore"), "main");
	public final ModelPart sx;
	public final ModelPart sx2;
	public final ModelPart dx;
	public final ModelPart dx2;

	public Modelascensore(ModelPart root) {
		this.sx = root.getChild("sx");
		this.sx2 = this.sx.getChild("sx2");
		this.dx = root.getChild("dx");
		this.dx2 = this.dx.getChild("dx2");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();
		PartDefinition sx = partdefinition.addOrReplaceChild("sx",
				CubeListBuilder.create().texOffs(0, 0).addBox(7.0F, -16.0F, -2.0F, 8.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(0, 20).addBox(7.0F, -32.0F, -2.0F, 8.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-15.0F, 24.0F, 16.0F));
		PartDefinition sx2 = sx.addOrReplaceChild("sx2",
				CubeListBuilder.create().texOffs(0, 40).addBox(9.0F, -16.0F, -1.0F, 8.0F, 16.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(20, 40).addBox(9.0F, 0.0F, -1.0F, 8.0F, 16.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(6.0F, -16.0F, 0.0F));
		PartDefinition dx = partdefinition.addOrReplaceChild("dx",
				CubeListBuilder.create().texOffs(24, 0).addBox(1.0F, -16.0F, -2.0F, 8.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(24, 20).addBox(1.0F, -32.0F, -2.0F, 8.0F, 16.0F, 4.0F, new CubeDeformation(0.0F)),
				PartPose.offset(15.0F, 24.0F, 16.0F));
		PartDefinition dx2 = dx.addOrReplaceChild("dx2",
				CubeListBuilder.create().texOffs(40, 40).addBox(-1.0F, -16.0F, -1.0F, 8.0F, 16.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 0).addBox(-1.0F, 0.0F, -1.0F, 8.0F, 16.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-6.0F, -16.0F, 0.0F));
		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(T entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay, float red, float green, float blue, float alpha) {
		sx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
		dx.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}
