
package net.mcreator.disembodiment.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.disembodiment.init.DisembodimentModItems;
import net.mcreator.disembodiment.init.DisembodimentModFluids;
import net.mcreator.disembodiment.init.DisembodimentModFluidTypes;
import net.mcreator.disembodiment.init.DisembodimentModBlocks;

public abstract class GreenFluidFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> DisembodimentModFluidTypes.GREEN_FLUID_TYPE.get(), () -> DisembodimentModFluids.GREEN_FLUID.get(),
			() -> DisembodimentModFluids.FLOWING_GREEN_FLUID.get()).explosionResistance(100f).tickRate(7).bucket(() -> DisembodimentModItems.GREEN_FLUID_BUCKET.get()).block(() -> (LiquidBlock) DisembodimentModBlocks.GREEN_FLUID.get());

	private GreenFluidFluid() {
		super(PROPERTIES);
	}

	public static class Source extends GreenFluidFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends GreenFluidFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
