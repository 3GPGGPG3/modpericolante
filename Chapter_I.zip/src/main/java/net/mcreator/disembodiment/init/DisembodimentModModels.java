
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.disembodiment.client.model.Modelpsychologist_headless;
import net.mcreator.disembodiment.client.model.Modelknight_chase;
import net.mcreator.disembodiment.client.model.Modelknight;
import net.mcreator.disembodiment.client.model.Modelgiradischi;
import net.mcreator.disembodiment.client.model.Modelgiornale;
import net.mcreator.disembodiment.client.model.Modeleyesinthedark_chase;
import net.mcreator.disembodiment.client.model.Modeleyesinthedark;
import net.mcreator.disembodiment.client.model.Modelcorpse2;
import net.mcreator.disembodiment.client.model.Modelcorpse;
import net.mcreator.disembodiment.client.model.Modelascensore;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class DisembodimentModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(Modeleyesinthedark_chase.LAYER_LOCATION, Modeleyesinthedark_chase::createBodyLayer);
		event.registerLayerDefinition(Modeleyesinthedark.LAYER_LOCATION, Modeleyesinthedark::createBodyLayer);
		event.registerLayerDefinition(Modelknight.LAYER_LOCATION, Modelknight::createBodyLayer);
		event.registerLayerDefinition(Modelcorpse.LAYER_LOCATION, Modelcorpse::createBodyLayer);
		event.registerLayerDefinition(Modelcorpse2.LAYER_LOCATION, Modelcorpse2::createBodyLayer);
		event.registerLayerDefinition(Modelpsychologist_headless.LAYER_LOCATION, Modelpsychologist_headless::createBodyLayer);
		event.registerLayerDefinition(Modelgiradischi.LAYER_LOCATION, Modelgiradischi::createBodyLayer);
		event.registerLayerDefinition(Modelknight_chase.LAYER_LOCATION, Modelknight_chase::createBodyLayer);
		event.registerLayerDefinition(Modelgiornale.LAYER_LOCATION, Modelgiornale::createBodyLayer);
		event.registerLayerDefinition(Modelascensore.LAYER_LOCATION, Modelascensore::createBodyLayer);
	}
}
