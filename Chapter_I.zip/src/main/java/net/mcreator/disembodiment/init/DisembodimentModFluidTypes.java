
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fluids.FluidType;

import net.mcreator.disembodiment.fluid.types.GreenFluidFluidType;
import net.mcreator.disembodiment.DisembodimentMod;

public class DisembodimentModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, DisembodimentMod.MODID);
	public static final RegistryObject<FluidType> GREEN_FLUID_TYPE = REGISTRY.register("green_fluid", () -> new GreenFluidFluidType());
}
