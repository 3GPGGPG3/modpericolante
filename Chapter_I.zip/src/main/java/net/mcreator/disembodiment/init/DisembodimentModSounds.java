
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.disembodiment.DisembodimentMod;

public class DisembodimentModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, DisembodimentMod.MODID);
	public static final RegistryObject<SoundEvent> JUMPSCARE_1 = REGISTRY.register("jumpscare_1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "jumpscare_1")));
	public static final RegistryObject<SoundEvent> EFFECT_AUDIO_1 = REGISTRY.register("effect_audio_1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "effect_audio_1")));
	public static final RegistryObject<SoundEvent> GAME_OVER_AUDIO = REGISTRY.register("game_over_audio", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "game_over_audio")));
	public static final RegistryObject<SoundEvent> EFFECT_C_1 = REGISTRY.register("effect_c_1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "effect_c_1")));
	public static final RegistryObject<SoundEvent> EFFECT_C_2 = REGISTRY.register("effect_c_2", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "effect_c_2")));
	public static final RegistryObject<SoundEvent> CUTSCENE1 = REGISTRY.register("cutscene1", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "cutscene1")));
	public static final RegistryObject<SoundEvent> CUTSCENE_SEEK_EYES_IN_THE_DARK = REGISTRY.register("cutscene_seek_eyes_in_the_dark",
			() -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "cutscene_seek_eyes_in_the_dark")));
	public static final RegistryObject<SoundEvent> STEP_SEEK = REGISTRY.register("step_seek", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "step_seek")));
	public static final RegistryObject<SoundEvent> NIGHT_CAVALLETTE = REGISTRY.register("night_cavallette", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "night_cavallette")));
	public static final RegistryObject<SoundEvent> CUTSCENE_KNIGHT = REGISTRY.register("cutscene_knight", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "cutscene_knight")));
	public static final RegistryObject<SoundEvent> DEEP_IN_OUR_MINDS = REGISTRY.register("deep_in_our_minds", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "deep_in_our_minds")));
	public static final RegistryObject<SoundEvent> INTERTEINMENT_MUSIC = REGISTRY.register("interteinment_music", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "interteinment_music")));
	public static final RegistryObject<SoundEvent> TWIN_TEARS = REGISTRY.register("twin_tears", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "twin_tears")));
	public static final RegistryObject<SoundEvent> ALARM = REGISTRY.register("alarm", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "alarm")));
	public static final RegistryObject<SoundEvent> NO_WAY_BACK_HOME = REGISTRY.register("no_way_back_home", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "no_way_back_home")));
	public static final RegistryObject<SoundEvent> LIFELESS_GRAY_LANDSCAPES = REGISTRY.register("lifeless_gray_landscapes", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "lifeless_gray_landscapes")));
	public static final RegistryObject<SoundEvent> URLO_SOUND = REGISTRY.register("urlo_sound", () -> SoundEvent.createVariableRangeEvent(new ResourceLocation("disembodiment", "urlo_sound")));
}
