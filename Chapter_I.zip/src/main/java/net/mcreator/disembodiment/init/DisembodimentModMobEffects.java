
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.disembodiment.potion.EyeOpeningEffectMobEffect;
import net.mcreator.disembodiment.potion.EyeBleedingMobEffect;
import net.mcreator.disembodiment.potion.EyeBleeding4MobEffect;
import net.mcreator.disembodiment.potion.EyeBleeding3MobEffect;
import net.mcreator.disembodiment.potion.EyeBleeding2MobEffect;
import net.mcreator.disembodiment.DisembodimentMod;

public class DisembodimentModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, DisembodimentMod.MODID);
	public static final RegistryObject<MobEffect> EYE_BLEEDING = REGISTRY.register("eye_bleeding", () -> new EyeBleedingMobEffect());
	public static final RegistryObject<MobEffect> EYE_BLEEDING_2 = REGISTRY.register("eye_bleeding_2", () -> new EyeBleeding2MobEffect());
	public static final RegistryObject<MobEffect> EYE_BLEEDING_3 = REGISTRY.register("eye_bleeding_3", () -> new EyeBleeding3MobEffect());
	public static final RegistryObject<MobEffect> EYE_BLEEDING_4 = REGISTRY.register("eye_bleeding_4", () -> new EyeBleeding4MobEffect());
	public static final RegistryObject<MobEffect> EYE_OPENING_EFFECT = REGISTRY.register("eye_opening_effect", () -> new EyeOpeningEffectMobEffect());
}
