
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.entity.decoration.PaintingVariant;

import net.mcreator.disembodiment.DisembodimentMod;

public class DisembodimentModPaintings {
	public static final DeferredRegister<PaintingVariant> REGISTRY = DeferredRegister.create(ForgeRegistries.PAINTING_VARIANTS, DisembodimentMod.MODID);
	public static final RegistryObject<PaintingVariant> QUADRO_ANTICO_1 = REGISTRY.register("quadro_antico_1", () -> new PaintingVariant(16, 16));
}
