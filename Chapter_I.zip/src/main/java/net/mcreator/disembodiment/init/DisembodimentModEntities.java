
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;

import net.mcreator.disembodiment.entity.PsychologistCorpseEntity;
import net.mcreator.disembodiment.entity.PsicologaEntity;
import net.mcreator.disembodiment.entity.MomEntity;
import net.mcreator.disembodiment.entity.LiamEntity;
import net.mcreator.disembodiment.entity.KnightSeekEntity;
import net.mcreator.disembodiment.entity.KnightIdleEntity;
import net.mcreator.disembodiment.entity.KnightChaseEntity;
import net.mcreator.disembodiment.entity.GiradischiEntity;
import net.mcreator.disembodiment.entity.GiornaleEntity;
import net.mcreator.disembodiment.entity.EyesInTheDarkidleEntity;
import net.mcreator.disembodiment.entity.EyesInTheDarkEntity;
import net.mcreator.disembodiment.entity.EyesInTheDarkChaseEntity;
import net.mcreator.disembodiment.entity.ElevatorEntity;
import net.mcreator.disembodiment.entity.DeathEntity;
import net.mcreator.disembodiment.entity.DaveEntity;
import net.mcreator.disembodiment.entity.CorpseEntity;
import net.mcreator.disembodiment.entity.Corpse2Entity;
import net.mcreator.disembodiment.entity.BrotherEntity;
import net.mcreator.disembodiment.DisembodimentMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class DisembodimentModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, DisembodimentMod.MODID);
	public static final RegistryObject<EntityType<BrotherEntity>> BROTHER = register("brother",
			EntityType.Builder.<BrotherEntity>of(BrotherEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(BrotherEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<LiamEntity>> LIAM = register("liam",
			EntityType.Builder.<LiamEntity>of(LiamEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(LiamEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DeathEntity>> DEATH = register("death",
			EntityType.Builder.<DeathEntity>of(DeathEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DeathEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<DaveEntity>> DAVE = register("dave",
			EntityType.Builder.<DaveEntity>of(DaveEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(DaveEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<MomEntity>> MOM = register("mom",
			EntityType.Builder.<MomEntity>of(MomEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(MomEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EyesInTheDarkEntity>> EYES_IN_THE_DARK = register("eyes_in_the_dark", EntityType.Builder.<EyesInTheDarkEntity>of(EyesInTheDarkEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EyesInTheDarkEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EyesInTheDarkidleEntity>> EYES_IN_THE_DARKIDLE = register("eyes_in_the_darkidle", EntityType.Builder.<EyesInTheDarkidleEntity>of(EyesInTheDarkidleEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(EyesInTheDarkidleEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<EyesInTheDarkChaseEntity>> EYES_IN_THE_DARK_CHASE = register("eyes_in_the_dark_chase", EntityType.Builder.<EyesInTheDarkChaseEntity>of(EyesInTheDarkChaseEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(200).setUpdateInterval(3).setCustomClientFactory(EyesInTheDarkChaseEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<KnightSeekEntity>> KNIGHT_SEEK = register("knight_seek", EntityType.Builder.<KnightSeekEntity>of(KnightSeekEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(KnightSeekEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<KnightIdleEntity>> KNIGHT_IDLE = register("knight_idle", EntityType.Builder.<KnightIdleEntity>of(KnightIdleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(KnightIdleEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<CorpseEntity>> CORPSE = register("corpse",
			EntityType.Builder.<CorpseEntity>of(CorpseEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(CorpseEntity::new).fireImmune().sized(0.8f, 1.8f));
	public static final RegistryObject<EntityType<Corpse2Entity>> CORPSE_2 = register("corpse_2",
			EntityType.Builder.<Corpse2Entity>of(Corpse2Entity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(Corpse2Entity::new).fireImmune().sized(0.8f, 1.2f));
	public static final RegistryObject<EntityType<KnightChaseEntity>> KNIGHT_CHASE = register("knight_chase", EntityType.Builder.<KnightChaseEntity>of(KnightChaseEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true)
			.setTrackingRange(200).setUpdateInterval(3).setCustomClientFactory(KnightChaseEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<GiradischiEntity>> GIRADISCHI = register("giradischi", EntityType.Builder.<GiradischiEntity>of(GiradischiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(GiradischiEntity::new).fireImmune().sized(0.8f, 1.8f));
	public static final RegistryObject<EntityType<GiornaleEntity>> GIORNALE = register("giornale",
			EntityType.Builder.<GiornaleEntity>of(GiornaleEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(GiornaleEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PsicologaEntity>> PSICOLOGA = register("psicologa", EntityType.Builder.<PsicologaEntity>of(PsicologaEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64)
			.setUpdateInterval(3).setCustomClientFactory(PsicologaEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<PsychologistCorpseEntity>> PSYCHOLOGIST_CORPSE = register("psychologist_corpse", EntityType.Builder.<PsychologistCorpseEntity>of(PsychologistCorpseEntity::new, MobCategory.MONSTER)
			.setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(PsychologistCorpseEntity::new).fireImmune().sized(0.6f, 1.8f));
	public static final RegistryObject<EntityType<ElevatorEntity>> ELEVATOR = register("elevator",
			EntityType.Builder.<ElevatorEntity>of(ElevatorEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3).setCustomClientFactory(ElevatorEntity::new).fireImmune().sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> RegistryObject<EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			BrotherEntity.init();
			LiamEntity.init();
			DeathEntity.init();
			DaveEntity.init();
			MomEntity.init();
			EyesInTheDarkEntity.init();
			EyesInTheDarkidleEntity.init();
			EyesInTheDarkChaseEntity.init();
			KnightSeekEntity.init();
			KnightIdleEntity.init();
			CorpseEntity.init();
			Corpse2Entity.init();
			KnightChaseEntity.init();
			GiradischiEntity.init();
			GiornaleEntity.init();
			PsicologaEntity.init();
			PsychologistCorpseEntity.init();
			ElevatorEntity.init();
		});
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BROTHER.get(), BrotherEntity.createAttributes().build());
		event.put(LIAM.get(), LiamEntity.createAttributes().build());
		event.put(DEATH.get(), DeathEntity.createAttributes().build());
		event.put(DAVE.get(), DaveEntity.createAttributes().build());
		event.put(MOM.get(), MomEntity.createAttributes().build());
		event.put(EYES_IN_THE_DARK.get(), EyesInTheDarkEntity.createAttributes().build());
		event.put(EYES_IN_THE_DARKIDLE.get(), EyesInTheDarkidleEntity.createAttributes().build());
		event.put(EYES_IN_THE_DARK_CHASE.get(), EyesInTheDarkChaseEntity.createAttributes().build());
		event.put(KNIGHT_SEEK.get(), KnightSeekEntity.createAttributes().build());
		event.put(KNIGHT_IDLE.get(), KnightIdleEntity.createAttributes().build());
		event.put(CORPSE.get(), CorpseEntity.createAttributes().build());
		event.put(CORPSE_2.get(), Corpse2Entity.createAttributes().build());
		event.put(KNIGHT_CHASE.get(), KnightChaseEntity.createAttributes().build());
		event.put(GIRADISCHI.get(), GiradischiEntity.createAttributes().build());
		event.put(GIORNALE.get(), GiornaleEntity.createAttributes().build());
		event.put(PSICOLOGA.get(), PsicologaEntity.createAttributes().build());
		event.put(PSYCHOLOGIST_CORPSE.get(), PsychologistCorpseEntity.createAttributes().build());
		event.put(ELEVATOR.get(), ElevatorEntity.createAttributes().build());
	}
}
