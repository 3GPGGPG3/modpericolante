
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.disembodiment.client.particle.FogliaParticle;
import net.mcreator.disembodiment.client.particle.BloodParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class DisembodimentModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(DisembodimentModParticleTypes.BLOOD.get(), BloodParticle::provider);
		event.registerSpriteSet(DisembodimentModParticleTypes.FOGLIA.get(), FogliaParticle::provider);
	}
}
