
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.disembodiment.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.disembodiment.client.renderer.PsychologistCorpseRenderer;
import net.mcreator.disembodiment.client.renderer.PsicologaRenderer;
import net.mcreator.disembodiment.client.renderer.MomRenderer;
import net.mcreator.disembodiment.client.renderer.LiamRenderer;
import net.mcreator.disembodiment.client.renderer.KnightSeekRenderer;
import net.mcreator.disembodiment.client.renderer.KnightIdleRenderer;
import net.mcreator.disembodiment.client.renderer.KnightChaseRenderer;
import net.mcreator.disembodiment.client.renderer.GiradischiRenderer;
import net.mcreator.disembodiment.client.renderer.GiornaleRenderer;
import net.mcreator.disembodiment.client.renderer.EyesInTheDarkidleRenderer;
import net.mcreator.disembodiment.client.renderer.EyesInTheDarkRenderer;
import net.mcreator.disembodiment.client.renderer.EyesInTheDarkChaseRenderer;
import net.mcreator.disembodiment.client.renderer.ElevatorRenderer;
import net.mcreator.disembodiment.client.renderer.DeathRenderer;
import net.mcreator.disembodiment.client.renderer.DaveRenderer;
import net.mcreator.disembodiment.client.renderer.CorpseRenderer;
import net.mcreator.disembodiment.client.renderer.Corpse2Renderer;
import net.mcreator.disembodiment.client.renderer.BrotherRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class DisembodimentModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(DisembodimentModEntities.BROTHER.get(), BrotherRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.LIAM.get(), LiamRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.DEATH.get(), DeathRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.DAVE.get(), DaveRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.MOM.get(), MomRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.EYES_IN_THE_DARK.get(), EyesInTheDarkRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.EYES_IN_THE_DARKIDLE.get(), EyesInTheDarkidleRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.EYES_IN_THE_DARK_CHASE.get(), EyesInTheDarkChaseRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.KNIGHT_SEEK.get(), KnightSeekRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.KNIGHT_IDLE.get(), KnightIdleRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.CORPSE.get(), CorpseRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.CORPSE_2.get(), Corpse2Renderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.KNIGHT_CHASE.get(), KnightChaseRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.GIRADISCHI.get(), GiradischiRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.GIORNALE.get(), GiornaleRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.PSICOLOGA.get(), PsicologaRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.PSYCHOLOGIST_CORPSE.get(), PsychologistCorpseRenderer::new);
		event.registerEntityRenderer(DisembodimentModEntities.ELEVATOR.get(), ElevatorRenderer::new);
	}
}
