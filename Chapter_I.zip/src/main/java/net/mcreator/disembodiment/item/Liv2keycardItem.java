
package net.mcreator.disembodiment.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class Liv2keycardItem extends Item {
	public Liv2keycardItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
