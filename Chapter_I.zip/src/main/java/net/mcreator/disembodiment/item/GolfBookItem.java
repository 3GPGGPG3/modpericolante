
package net.mcreator.disembodiment.item;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.network.chat.Component;

import java.util.List;

public class GolfBookItem extends Item {
	public GolfBookItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}

	@Override
	public void appendHoverText(ItemStack itemstack, Level level, List<Component> list, TooltipFlag flag) {
		super.appendHoverText(itemstack, level, list, flag);
		list.add(Component.translatable("item.disembodiment.golf_book.description_0"));
		list.add(Component.translatable("item.disembodiment.golf_book.description_1"));
		list.add(Component.translatable("item.disembodiment.golf_book.description_2"));
	}
}
