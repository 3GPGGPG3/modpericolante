
package net.mcreator.disembodiment.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SforzoItem extends Item {
	public SforzoItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
