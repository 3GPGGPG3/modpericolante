
package net.mcreator.disembodiment.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class GrataSxBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public GrataSxBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(8f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(7, 0, 0, 9, 19, 2), box(7.5, 3, 11, 8.5, 15, 12), box(7.5, 3, 7.5, 8.5, 15, 8.5), box(7.5, 3, 4, 8.5, 15, 5), box(7.5, 3, 15, 8.5, 15, 16), box(7.5, 2, 2, 8.5, 3, 16), box(7.5, 15, 2, 8.5, 16, 16));
			case NORTH -> Shapes.or(box(7, 0, 14, 9, 19, 16), box(7.5, 3, 4, 8.5, 15, 5), box(7.5, 3, 7.5, 8.5, 15, 8.5), box(7.5, 3, 11, 8.5, 15, 12), box(7.5, 3, 0, 8.5, 15, 1), box(7.5, 2, 0, 8.5, 3, 14), box(7.5, 15, 0, 8.5, 16, 14));
			case EAST -> Shapes.or(box(0, 0, 7, 2, 19, 9), box(11, 3, 7.5, 12, 15, 8.5), box(7.5, 3, 7.5, 8.5, 15, 8.5), box(4, 3, 7.5, 5, 15, 8.5), box(15, 3, 7.5, 16, 15, 8.5), box(2, 2, 7.5, 16, 3, 8.5), box(2, 15, 7.5, 16, 16, 8.5));
			case WEST -> Shapes.or(box(14, 0, 7, 16, 19, 9), box(4, 3, 7.5, 5, 15, 8.5), box(7.5, 3, 7.5, 8.5, 15, 8.5), box(11, 3, 7.5, 12, 15, 8.5), box(0, 3, 7.5, 1, 15, 8.5), box(0, 2, 7.5, 14, 3, 8.5), box(0, 15, 7.5, 14, 16, 8.5));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
