
package net.mcreator.disembodiment.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class DivanoneBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public DivanoneBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.WOOL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 7;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(18, 0, 13, 20, 2, 15), box(-4, 0, 13, -2, 2, 15), box(-4, 0, 2, -2, 2, 4), box(18, 0, 2, 20, 2, 4), box(5, 2, 1, 21, 6, 16), box(-5, 2, 1, 5, 6, 16), box(-8, 6, 1, -5, 10, 16), box(21, 6, 1, 24, 10, 16),
					box(6, 5, 0, 21, 15, 4), box(-5, 5, 0, 6, 15, 4));
			case NORTH -> Shapes.or(box(-4, 0, 1, -2, 2, 3), box(18, 0, 1, 20, 2, 3), box(18, 0, 12, 20, 2, 14), box(-4, 0, 12, -2, 2, 14), box(-5, 2, 0, 11, 6, 15), box(11, 2, 0, 21, 6, 15), box(21, 6, 0, 24, 10, 15), box(-8, 6, 0, -5, 10, 15),
					box(-5, 5, 12, 10, 15, 16), box(10, 5, 12, 21, 15, 16));
			case EAST -> Shapes.or(box(13, 0, -4, 15, 2, -2), box(13, 0, 18, 15, 2, 20), box(2, 0, 18, 4, 2, 20), box(2, 0, -4, 4, 2, -2), box(1, 2, -5, 16, 6, 11), box(1, 2, 11, 16, 6, 21), box(1, 6, 21, 16, 10, 24), box(1, 6, -8, 16, 10, -5),
					box(0, 5, -5, 4, 15, 10), box(0, 5, 10, 4, 15, 21));
			case WEST -> Shapes.or(box(1, 0, 18, 3, 2, 20), box(1, 0, -4, 3, 2, -2), box(12, 0, -4, 14, 2, -2), box(12, 0, 18, 14, 2, 20), box(0, 2, 5, 15, 6, 21), box(0, 2, -5, 15, 6, 5), box(0, 6, -8, 15, 10, -5), box(0, 6, 21, 15, 10, 24),
					box(12, 5, 6, 16, 15, 21), box(12, 5, -5, 16, 15, 6));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
