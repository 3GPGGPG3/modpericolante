
package net.mcreator.disembodiment.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class BottoneElevatorBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public BottoneElevatorBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(3, 2, 0, 13, 13, 2), box(5, 9, 1.5, 7, 11, 2.5), box(9, 9, 1.5, 11, 11, 2.5), box(9, 3, 1.5, 11, 5, 2.5), box(5, 3, 1.5, 7, 5, 2.5), box(5, 6, 1.5, 7, 8, 2.5), box(9, 6, 1.5, 11, 8, 2.5));
			case NORTH -> Shapes.or(box(3, 2, 14, 13, 13, 16), box(9, 9, 13.5, 11, 11, 14.5), box(5, 9, 13.5, 7, 11, 14.5), box(5, 3, 13.5, 7, 5, 14.5), box(9, 3, 13.5, 11, 5, 14.5), box(9, 6, 13.5, 11, 8, 14.5), box(5, 6, 13.5, 7, 8, 14.5));
			case EAST -> Shapes.or(box(0, 2, 3, 2, 13, 13), box(1.5, 9, 9, 2.5, 11, 11), box(1.5, 9, 5, 2.5, 11, 7), box(1.5, 3, 5, 2.5, 5, 7), box(1.5, 3, 9, 2.5, 5, 11), box(1.5, 6, 9, 2.5, 8, 11), box(1.5, 6, 5, 2.5, 8, 7));
			case WEST -> Shapes.or(box(14, 2, 3, 16, 13, 13), box(13.5, 9, 5, 14.5, 11, 7), box(13.5, 9, 9, 14.5, 11, 11), box(13.5, 3, 9, 14.5, 5, 11), box(13.5, 3, 5, 14.5, 5, 7), box(13.5, 6, 5, 14.5, 8, 7), box(13.5, 6, 9, 14.5, 8, 11));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
