
package net.mcreator.disembodiment.block;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.DirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class TuboBlock extends Block {
	public static final DirectionProperty FACING = DirectionalBlock.FACING;

	public TuboBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(1f, 10f).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(0, 5.5, 0.5, 16, 10.5, 2.5), box(0, 5.5, 9.5, 16, 10.5, 11.5), box(0, 11.5, 3.5, 16, 13.5, 8.5), box(0, 10.5, 8.5, 16, 11.5, 10.5), box(0, 10.5, 1.5, 16, 11.5, 3.5), box(0, 11.5, 8.5, 16, 12.5, 9.5),
					box(0, 11.5, 2.5, 16, 12.5, 3.5), box(0, 4.5, 8.5, 16, 5.5, 10.5), box(0, 3.5, 8.5, 16, 4.5, 9.5), box(0, 2.5, 3.5, 16, 4.5, 8.5), box(0, 4.5, 1.5, 16, 5.5, 3.5), box(0, 3.5, 2.5, 16, 4.5, 3.5));
			case NORTH -> Shapes.or(box(0, 5.5, 13.5, 16, 10.5, 15.5), box(0, 5.5, 4.5, 16, 10.5, 6.5), box(0, 11.5, 7.5, 16, 13.5, 12.5), box(0, 10.5, 5.5, 16, 11.5, 7.5), box(0, 10.5, 12.5, 16, 11.5, 14.5), box(0, 11.5, 6.5, 16, 12.5, 7.5),
					box(0, 11.5, 12.5, 16, 12.5, 13.5), box(0, 4.5, 5.5, 16, 5.5, 7.5), box(0, 3.5, 6.5, 16, 4.5, 7.5), box(0, 2.5, 7.5, 16, 4.5, 12.5), box(0, 4.5, 12.5, 16, 5.5, 14.5), box(0, 3.5, 12.5, 16, 4.5, 13.5));
			case EAST -> Shapes.or(box(0.5, 5.5, 0, 2.5, 10.5, 16), box(9.5, 5.5, 0, 11.5, 10.5, 16), box(3.5, 11.5, 0, 8.5, 13.5, 16), box(8.5, 10.5, 0, 10.5, 11.5, 16), box(1.5, 10.5, 0, 3.5, 11.5, 16), box(8.5, 11.5, 0, 9.5, 12.5, 16),
					box(2.5, 11.5, 0, 3.5, 12.5, 16), box(8.5, 4.5, 0, 10.5, 5.5, 16), box(8.5, 3.5, 0, 9.5, 4.5, 16), box(3.5, 2.5, 0, 8.5, 4.5, 16), box(1.5, 4.5, 0, 3.5, 5.5, 16), box(2.5, 3.5, 0, 3.5, 4.5, 16));
			case WEST -> Shapes.or(box(13.5, 5.5, 0, 15.5, 10.5, 16), box(4.5, 5.5, 0, 6.5, 10.5, 16), box(7.5, 11.5, 0, 12.5, 13.5, 16), box(5.5, 10.5, 0, 7.5, 11.5, 16), box(12.5, 10.5, 0, 14.5, 11.5, 16), box(6.5, 11.5, 0, 7.5, 12.5, 16),
					box(12.5, 11.5, 0, 13.5, 12.5, 16), box(5.5, 4.5, 0, 7.5, 5.5, 16), box(6.5, 3.5, 0, 7.5, 4.5, 16), box(7.5, 2.5, 0, 12.5, 4.5, 16), box(12.5, 4.5, 0, 14.5, 5.5, 16), box(12.5, 3.5, 0, 13.5, 4.5, 16));
			case UP -> Shapes.or(box(0, 0.5, 5.5, 16, 2.5, 10.5), box(0, 9.5, 5.5, 16, 11.5, 10.5), box(0, 3.5, 11.5, 16, 8.5, 13.5), box(0, 8.5, 10.5, 16, 10.5, 11.5), box(0, 1.5, 10.5, 16, 3.5, 11.5), box(0, 8.5, 11.5, 16, 9.5, 12.5),
					box(0, 2.5, 11.5, 16, 3.5, 12.5), box(0, 8.5, 4.5, 16, 10.5, 5.5), box(0, 8.5, 3.5, 16, 9.5, 4.5), box(0, 3.5, 2.5, 16, 8.5, 4.5), box(0, 1.5, 4.5, 16, 3.5, 5.5), box(0, 2.5, 3.5, 16, 3.5, 4.5));
			case DOWN -> Shapes.or(box(0, 13.5, 5.5, 16, 15.5, 10.5), box(0, 4.5, 5.5, 16, 6.5, 10.5), box(0, 7.5, 2.5, 16, 12.5, 4.5), box(0, 5.5, 4.5, 16, 7.5, 5.5), box(0, 12.5, 4.5, 16, 14.5, 5.5), box(0, 6.5, 3.5, 16, 7.5, 4.5),
					box(0, 12.5, 3.5, 16, 13.5, 4.5), box(0, 5.5, 10.5, 16, 7.5, 11.5), box(0, 6.5, 11.5, 16, 7.5, 12.5), box(0, 7.5, 11.5, 16, 12.5, 13.5), box(0, 12.5, 10.5, 16, 14.5, 11.5), box(0, 12.5, 11.5, 16, 13.5, 12.5));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getNearestLookingDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
