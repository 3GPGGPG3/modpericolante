
package net.mcreator.disembodiment.block;

import org.checkerframework.checker.units.qual.s;

import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.core.Direction;
import net.minecraft.core.BlockPos;

public class LampadaDBlock extends Block {
	public static final DirectionProperty FACING = HorizontalDirectionalBlock.FACING;

	public LampadaDBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.METAL).strength(1f, 10f).lightLevel(s -> 10).noOcclusion().isRedstoneConductor((bs, br, bp) -> false));
		this.registerDefaultState(this.stateDefinition.any().setValue(FACING, Direction.NORTH));
	}

	@Override
	public boolean propagatesSkylightDown(BlockState state, BlockGetter reader, BlockPos pos) {
		return true;
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 0;
	}

	@Override
	public VoxelShape getVisualShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return Shapes.empty();
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter world, BlockPos pos, CollisionContext context) {
		return switch (state.getValue(FACING)) {
			default -> Shapes.or(box(2, 0.1, 2, 8, 1.1, 8), box(3, 0.8, 3, 7, 1.8, 7), box(4.5, 12.5, 4.5, 5.5, 28.2, 5.5), box(4.5, 1.8, 4.5, 5.5, 12.5, 5.5), box(7, 24, 2, 8, 29, 8), box(8, 19, 1, 9, 24, 9), box(2, 24, 2, 3, 29, 8),
					box(3, 28, 3, 7, 29, 7), box(3, 24, 7, 7, 29, 8), box(3, 24, 2, 7, 29, 3), box(1, 19, 1, 2, 24, 9), box(2, 19, 8, 8, 24, 9), box(2, 19, 1, 8, 24, 2));
			case NORTH -> Shapes.or(box(8, 0.1, 8, 14, 1.1, 14), box(9, 0.8, 9, 13, 1.8, 13), box(10.5, 12.5, 10.5, 11.5, 28.2, 11.5), box(10.5, 1.8, 10.5, 11.5, 12.5, 11.5), box(8, 24, 8, 9, 29, 14), box(7, 19, 7, 8, 24, 15),
					box(13, 24, 8, 14, 29, 14), box(9, 28, 9, 13, 29, 13), box(9, 24, 8, 13, 29, 9), box(9, 24, 13, 13, 29, 14), box(14, 19, 7, 15, 24, 15), box(8, 19, 7, 14, 24, 8), box(8, 19, 14, 14, 24, 15));
			case EAST -> Shapes.or(box(2, 0.1, 8, 8, 1.1, 14), box(3, 0.8, 9, 7, 1.8, 13), box(4.5, 12.5, 10.5, 5.5, 28.2, 11.5), box(4.5, 1.8, 10.5, 5.5, 12.5, 11.5), box(2, 24, 8, 8, 29, 9), box(1, 19, 7, 9, 24, 8), box(2, 24, 13, 8, 29, 14),
					box(3, 28, 9, 7, 29, 13), box(7, 24, 9, 8, 29, 13), box(2, 24, 9, 3, 29, 13), box(1, 19, 14, 9, 24, 15), box(8, 19, 8, 9, 24, 14), box(1, 19, 8, 2, 24, 14));
			case WEST -> Shapes.or(box(8, 0.1, 2, 14, 1.1, 8), box(9, 0.8, 3, 13, 1.8, 7), box(10.5, 12.5, 4.5, 11.5, 28.2, 5.5), box(10.5, 1.8, 4.5, 11.5, 12.5, 5.5), box(8, 24, 7, 14, 29, 8), box(7, 19, 8, 15, 24, 9), box(8, 24, 2, 14, 29, 3),
					box(9, 28, 3, 13, 29, 7), box(8, 24, 3, 9, 29, 7), box(13, 24, 3, 14, 29, 7), box(7, 19, 1, 15, 24, 2), box(7, 19, 2, 8, 24, 8), box(14, 19, 2, 15, 24, 8));
		};
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		super.createBlockStateDefinition(builder);
		builder.add(FACING);
	}

	@Override
	public BlockState getStateForPlacement(BlockPlaceContext context) {
		return super.getStateForPlacement(context).setValue(FACING, context.getHorizontalDirection().getOpposite());
	}

	public BlockState rotate(BlockState state, Rotation rot) {
		return state.setValue(FACING, rot.rotate(state.getValue(FACING)));
	}

	public BlockState mirror(BlockState state, Mirror mirrorIn) {
		return state.rotate(mirrorIn.getRotation(state.getValue(FACING)));
	}
}
