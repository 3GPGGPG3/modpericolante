// Made with Blockbench 5.0.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelgiornale<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "giornale"), "main");
	private final ModelPart all;
	private final ModelPart pagina;
	private final ModelPart br_dx;
	private final ModelPart br_sx;

	public Modelgiornale(ModelPart root) {
		this.all = root.getChild("all");
		this.pagina = this.all.getChild("pagina");
		this.br_dx = this.all.getChild("br_dx");
		this.br_sx = this.all.getChild("br_sx");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition all = partdefinition.addOrReplaceChild("all",
				CubeListBuilder.create().texOffs(0, 13)
						.addBox(0.0F, -1.0F, -6.0F, 8.0F, 1.0F, 12.0F, new CubeDeformation(0.0F)).texOffs(0, 39)
						.addBox(-8.0F, -1.0F, -6.0F, 8.0F, 1.0F, 12.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition cube_r1 = all
				.addOrReplaceChild("cube_r1",
						CubeListBuilder.create().texOffs(40, 13).addBox(-7.9671F, -0.3728F, -6.0F, 8.0F, 1.0F, 12.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, -0.8F, 0.0F, 0.0F, 0.0F, 0.1047F));

		PartDefinition cube_r2 = all.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(0, 26).addBox(-0.0329F, -0.3728F, -6.0F, 8.0F, 1.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.8F, 0.0F, 0.0F, 0.0F, -0.1047F));

		PartDefinition cube_r3 = all
				.addOrReplaceChild("cube_r3",
						CubeListBuilder.create().texOffs(0, 0).addBox(-7.8462F, 0.3497F, -6.0F, 8.0F, 1.0F, 12.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.1F, -1.5F, 0.0F, 0.0F, 0.0F, 0.2269F));

		PartDefinition pagina = all.addOrReplaceChild("pagina", CubeListBuilder.create(),
				PartPose.offset(-0.1F, -1.5F, 0.0F));

		PartDefinition cube_r4 = pagina
				.addOrReplaceChild("cube_r4",
						CubeListBuilder.create().texOffs(40, 0).addBox(-0.1538F, 0.3497F, -6.0F, 8.0F, 1.0F, 12.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.2269F));

		PartDefinition br_dx = all.addOrReplaceChild("br_dx", CubeListBuilder.create(),
				PartPose.offset(6.0F, -9.5F, -10.4F));

		PartDefinition cube_r5 = br_dx.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(40, 26).addBox(-2.0F, -12.0F, -2.0F, 4.0F, 20.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -2.303F, -0.0194F, -0.3837F));

		PartDefinition br_sx = all.addOrReplaceChild("br_sx", CubeListBuilder.create(),
				PartPose.offset(-8.9F, -5.5F, -10.4F));

		PartDefinition cube_r6 = br_sx.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(40, 50).addBox(-2.0F, -12.0F, -2.0F, 4.0F, 20.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -1.5746F, 0.304F, 1.0561F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		all.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}