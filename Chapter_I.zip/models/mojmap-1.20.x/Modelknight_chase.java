// Made with Blockbench 5.0.4
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelknight_chase<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "knight_chase"), "main");
	private final ModelPart All;
	private final ModelPart corpo;
	private final ModelPart head;
	private final ModelPart riseable_helmet;
	private final ModelPart arto_s_dx;
	private final ModelPart spalladx;
	private final ModelPart bracciodx1;
	private final ModelPart bracciodx2;
	private final ModelPart manodx;
	private final ModelPart p_dx;
	private final ModelPart p_dx2;
	private final ModelPart a_dx;
	private final ModelPart a_dx2;
	private final ModelPart i_dx;
	private final ModelPart i_dx2;
	private final ModelPart m_dx;
	private final ModelPart m_dx2;
	private final ModelPart mi_dx;
	private final ModelPart mi_dx2;
	private final ModelPart arto_s_sx;
	private final ModelPart bracciosx1;
	private final ModelPart bracciosx2;
	private final ModelPart manosx;
	private final ModelPart mi_sx;
	private final ModelPart mi_sx2;
	private final ModelPart mi_sx3;
	private final ModelPart m_sx;
	private final ModelPart m_sx2;
	private final ModelPart m_sx3;
	private final ModelPart i_sx;
	private final ModelPart i_sx2;
	private final ModelPart i_sx3;
	private final ModelPart a_sx;
	private final ModelPart a_sx2;
	private final ModelPart a_sx3;
	private final ModelPart p_sx;
	private final ModelPart p_sx1;
	private final ModelPart p_sx2;
	private final ModelPart knife;
	private final ModelPart spallasx;
	private final ModelPart gambadx1;
	private final ModelPart gambadx2;
	private final ModelPart piededx;
	private final ModelPart gambasx1;
	private final ModelPart gambasx2;
	private final ModelPart piedesx;

	public Modelknight_chase(ModelPart root) {
		this.All = root.getChild("All");
		this.corpo = this.All.getChild("corpo");
		this.head = this.All.getChild("head");
		this.riseable_helmet = this.head.getChild("riseable_helmet");
		this.arto_s_dx = this.All.getChild("arto_s_dx");
		this.spalladx = this.arto_s_dx.getChild("spalladx");
		this.bracciodx1 = this.arto_s_dx.getChild("bracciodx1");
		this.bracciodx2 = this.bracciodx1.getChild("bracciodx2");
		this.manodx = this.bracciodx2.getChild("manodx");
		this.p_dx = this.manodx.getChild("p_dx");
		this.p_dx2 = this.p_dx.getChild("p_dx2");
		this.a_dx = this.manodx.getChild("a_dx");
		this.a_dx2 = this.a_dx.getChild("a_dx2");
		this.i_dx = this.manodx.getChild("i_dx");
		this.i_dx2 = this.i_dx.getChild("i_dx2");
		this.m_dx = this.manodx.getChild("m_dx");
		this.m_dx2 = this.m_dx.getChild("m_dx2");
		this.mi_dx = this.manodx.getChild("mi_dx");
		this.mi_dx2 = this.mi_dx.getChild("mi_dx2");
		this.arto_s_sx = this.All.getChild("arto_s_sx");
		this.bracciosx1 = this.arto_s_sx.getChild("bracciosx1");
		this.bracciosx2 = this.bracciosx1.getChild("bracciosx2");
		this.manosx = this.bracciosx2.getChild("manosx");
		this.mi_sx = this.manosx.getChild("mi_sx");
		this.mi_sx2 = this.mi_sx.getChild("mi_sx2");
		this.mi_sx3 = this.mi_sx2.getChild("mi_sx3");
		this.m_sx = this.manosx.getChild("m_sx");
		this.m_sx2 = this.m_sx.getChild("m_sx2");
		this.m_sx3 = this.m_sx2.getChild("m_sx3");
		this.i_sx = this.manosx.getChild("i_sx");
		this.i_sx2 = this.i_sx.getChild("i_sx2");
		this.i_sx3 = this.i_sx2.getChild("i_sx3");
		this.a_sx = this.manosx.getChild("a_sx");
		this.a_sx2 = this.a_sx.getChild("a_sx2");
		this.a_sx3 = this.a_sx2.getChild("a_sx3");
		this.p_sx = this.manosx.getChild("p_sx");
		this.p_sx1 = this.p_sx.getChild("p_sx1");
		this.p_sx2 = this.p_sx.getChild("p_sx2");
		this.knife = this.manosx.getChild("knife");
		this.spallasx = this.arto_s_sx.getChild("spallasx");
		this.gambadx1 = this.All.getChild("gambadx1");
		this.gambadx2 = this.gambadx1.getChild("gambadx2");
		this.piededx = this.gambadx2.getChild("piededx");
		this.gambasx1 = this.All.getChild("gambasx1");
		this.gambasx2 = this.gambasx1.getChild("gambasx2");
		this.piedesx = this.gambasx2.getChild("piedesx");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition All = partdefinition.addOrReplaceChild("All", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.6504F, -12.4171F, 5.1733F, 1.5708F, 0.0F, 0.0F));

		PartDefinition corpo = All.addOrReplaceChild("corpo", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.9114F, -0.6F, 2.3267F, 0.0F, 0.0F, -0.1309F));

		PartDefinition cube_r1 = corpo.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(66, 41).addBox(-0.5F, -2.0F, -14.5F, 1.0F, 4.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.577F, 0.6436F, -2.5F, 0.0F, 0.0F, 0.4363F));

		PartDefinition cube_r2 = corpo.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(66, 26).addBox(-0.5F, -2.0F, -14.5F, 1.0F, 4.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.1549F, -0.6564F, -2.5F, 0.0F, 0.0F, -0.1745F));

		PartDefinition cube_r3 = corpo.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(32, 45).addBox(-3.0F, -0.5F, -15.0F, 6.0F, 1.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0739F, -2.0347F, -2.0F, 0.0F, 0.0F, 0.3927F));

		PartDefinition cube_r4 = corpo.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(0, 85).addBox(-2.8134F, 1.3783F, -11.2998F, 6.0F, 1.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.2481F, -2.3347F, 5.5F, -0.2103F, 0.0207F, 0.3016F));

		PartDefinition cube_r5 = corpo.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(82, 70).addBox(-3.6247F, 1.2812F, -11.2998F, 6.0F, 1.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.7519F, -3.0347F, 5.5F, -0.1997F, -0.0695F, -0.1256F));

		PartDefinition cube_r6 = corpo.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(32, 33).addBox(-3.0F, -0.5F, -14.5F, 6.0F, 1.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.4518F, -2.6347F, -2.5F, 0.0F, 0.0F, -0.1745F));

		PartDefinition cube_r7 = corpo
				.addOrReplaceChild("cube_r7",
						CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -2.0F, -16.5F, 10.0F, 4.0F, 15.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1309F));

		PartDefinition head = All.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(64, 110)
						.addBox(-3.5F, -3.7618F, -2.8471F, 7.0F, 6.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(68, 17)
						.addBox(-3.5F, -3.7618F, -7.8471F, 7.0F, 6.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(55, 21)
						.addBox(-3.5F, -3.7618F, -4.8471F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(42, 112)
						.addBox(1.5F, -3.7618F, -4.8471F, 2.0F, 6.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(26, 21)
						.addBox(-1.5F, -2.7618F, -4.8471F, 3.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(90, 26)
						.addBox(3.5F, -0.0618F, -5.8471F, 1.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(30, 70)
						.addBox(-3.5F, 1.9382F, -6.8471F, 7.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(90, 35)
						.addBox(-3.5F, -3.0618F, -0.8471F, 7.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(92, 57)
						.addBox(-0.5F, -1.0618F, 0.1529F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(36, 90)
						.addBox(-1.5F, -2.0618F, 4.1529F, 3.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(22, 89)
						.addBox(-4.5F, -0.0618F, -5.8471F, 1.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-1.8371F, -1.0174F, 8.6738F));

		PartDefinition cube_r8 = head.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(54, 6).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -2.2618F, -3.7471F, 0.6044F, 0.3321F, -0.6105F));

		PartDefinition cube_r9 = head.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(45, 6).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.5F, -2.8618F, -2.5471F, -0.0326F, 0.3717F, -1.6329F));

		PartDefinition cube_r10 = head.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(44, 5).addBox(-0.5F, -0.5F, -1.0F, 1.0F, 1.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.2822F, -2.2989F, -4.5488F, 0.1321F, 0.0211F, -0.7047F));

		PartDefinition cube_r11 = head.addOrReplaceChild("cube_r11",
				CubeListBuilder.create().texOffs(45, 6).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.7F, -2.9618F, -4.7471F, 0.2388F, -0.2323F, -2.0177F));

		PartDefinition cube_r12 = head.addOrReplaceChild("cube_r12",
				CubeListBuilder.create().texOffs(45, 6).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.3F, -2.9618F, -4.7471F, -0.3316F, 0.0F, 0.3665F));

		PartDefinition riseable_helmet = head.addOrReplaceChild("riseable_helmet",
				CubeListBuilder.create().texOffs(60, 90)
						.addBox(-0.5F, -5.3943F, -5.3765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(72, 90)
						.addBox(3.5F, -3.1943F, -5.3765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(92, 20)
						.addBox(3.5F, -2.1943F, -4.3765F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(12, 91)
						.addBox(-4.5F, -2.1943F, -4.3765F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(50, 13)
						.addBox(-4.5F, -3.1943F, -5.3765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -0.8675F, -1.4706F));

		PartDefinition cube_r13 = riseable_helmet.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(68, 96)
						.addBox(-0.5F, 4.6622F, -8.8724F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(52, 98)
						.addBox(7.5F, 4.6622F, -8.8724F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-4.0F, -1.3943F, 9.1235F, -0.6109F, 0.0F, 0.0F));

		PartDefinition cube_r14 = riseable_helmet.addOrReplaceChild("cube_r14",
				CubeListBuilder.create().texOffs(76, 96)
						.addBox(-0.5F, 5.864F, -7.864F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(8, 97)
						.addBox(2.9F, 5.864F, -7.864F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7F, -2.8943F, 9.2235F, -0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r15 = riseable_helmet.addOrReplaceChild("cube_r15",
				CubeListBuilder.create().texOffs(16, 98)
						.addBox(-1.0F, -1.0F, -6.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(80, 11)
						.addBox(-1.0F, -1.0F, -7.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(100, 67)
						.addBox(0.0F, -1.0F, -5.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(48, 78)
						.addBox(-1.0F, -1.0F, -3.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.5F, -2.8943F, 1.6235F, 0.0F, 0.0F, -0.5672F));

		PartDefinition cube_r16 = riseable_helmet.addOrReplaceChild("cube_r16",
				CubeListBuilder.create().texOffs(34, 98)
						.addBox(0.0F, -1.0F, -6.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(24, 98)
						.addBox(-3.0F, -1.0F, -7.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 100)
						.addBox(-3.0F, -1.0F, -5.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(42, 98)
						.addBox(-3.0F, -1.0F, -3.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.5F, -2.8943F, 1.6235F, 0.0F, 0.0F, 0.5672F));

		PartDefinition arto_s_dx = All.addOrReplaceChild("arto_s_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-8.351F, 0.7171F, -1.1444F, -0.661F, -0.5049F, 0.3598F));

		PartDefinition spalladx = arto_s_dx.addOrReplaceChild("spalladx",
				CubeListBuilder.create().texOffs(88, 84).addBox(-2.1274F, -2.2164F, -2.9679F, 4.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.8993F, -0.6F, -0.1289F, 0.2017F, 0.1552F, -0.2317F));

		PartDefinition bracciodx1 = arto_s_dx.addOrReplaceChild("bracciodx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.8007F, -0.5F, -0.5711F, 1.0376F, -0.5282F, 0.7931F));

		PartDefinition cube_r17 = bracciodx1.addOrReplaceChild("cube_r17",
				CubeListBuilder.create().texOffs(80, 0).addBox(1.9442F, -2.0853F, -12.7438F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.6F, 0.0F, 5.0F, 0.1309F, 0.3927F, 0.0F));

		PartDefinition cube_r18 = bracciodx1.addOrReplaceChild("cube_r18",
				CubeListBuilder.create().texOffs(0, 74).addBox(1.9442F, -0.2753F, -12.7833F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.6F, 1.0F, 5.0F, -0.0873F, 0.3927F, 0.0F));

		PartDefinition bracciodx2 = bracciodx1.addOrReplaceChild("bracciodx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-3.3417F, 0.626F, -8.3326F, -0.6906F, -1.2938F, 0.9316F));

		PartDefinition cube_r19 = bracciodx2.addOrReplaceChild("cube_r19",
				CubeListBuilder.create().texOffs(68, 81).addBox(6.8633F, -2.7286F, -4.4609F, 3.0F, 2.0F, 7.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.4842F, 2.0892F, 8.7084F, -2.9671F, 1.3963F, -3.1416F));

		PartDefinition manodx = bracciodx2.addOrReplaceChild("manodx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-6.5842F, 1.6892F, 1.3084F, 0.0F, 0.0F, -0.1309F));

		PartDefinition cube_r20 = manodx.addOrReplaceChild("cube_r20",
				CubeListBuilder.create().texOffs(92, 16).addBox(0.5613F, -0.9318F, -10.8633F, 3.0F, 1.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7F, 0.0F, 9.8F, -0.0077F, 0.1744F, -0.0443F));

		PartDefinition p_dx = manodx.addOrReplaceChild("p_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.9972F, -0.8777F, 1.2432F, 0.4537F, -0.3829F, -0.0894F));

		PartDefinition cube_r21 = p_dx.addOrReplaceChild("cube_r21",
				CubeListBuilder.create().texOffs(102, 47).addBox(5.1453F, -4.8936F, -6.2985F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.2333F, 4.543F, 8.4943F, 0.0436F, 1.2654F, 0.0F));

		PartDefinition p_dx2 = p_dx.addOrReplaceChild("p_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.0361F, -0.0347F, 1.6375F, 0.6768F, -0.0278F, 0.2907F));

		PartDefinition cube_r22 = p_dx2.addOrReplaceChild("cube_r22",
				CubeListBuilder.create().texOffs(100, 98).addBox(1.6244F, -7.8393F, -6.2285F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(4.7463F, 7.5416F, 5.3661F, 0.0436F, 1.2654F, 0.0F));

		PartDefinition a_dx = manodx.addOrReplaceChild("a_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.7868F, -0.5F, 0.0076F, 0.0106F, -0.1568F, 1.1279F));

		PartDefinition cube_r23 = a_dx.addOrReplaceChild("cube_r23",
				CubeListBuilder.create().texOffs(102, 41).addBox(-0.8408F, -1.0942F, -9.9981F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.4848F, 1.3161F, 9.4579F, 0.0F, 0.1745F, 0.0F));

		PartDefinition a_dx2 = a_dx.addOrReplaceChild("a_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.102F, 0.4161F, 0.2655F, 0.0873F, -0.0435F, 0.8689F));

		PartDefinition cube_r24 = a_dx2.addOrReplaceChild("cube_r24",
				CubeListBuilder.create().texOffs(14, 102).addBox(-0.7999F, -0.7623F, -9.9946F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4835F, 0.5063F, 9.5175F, 0.0F, 0.1745F, 0.0F));

		PartDefinition i_dx = manodx.addOrReplaceChild("i_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.6913F, -0.7F, 2.0381F, 0.4363F, 0.0F, 0.7418F));

		PartDefinition cube_r25 = i_dx.addOrReplaceChild("cube_r25",
				CubeListBuilder.create().texOffs(26, 102).addBox(2.1215F, -4.8036F, -8.5359F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5151F, 4.4447F, 8.9943F, 0.0F, 0.3927F, 0.0F));

		PartDefinition i_dx2 = i_dx.addOrReplaceChild("i_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.7064F, -0.0553F, 0.8323F, 0.2094F, 0.0F, 0.6632F));

		PartDefinition cube_r26 = i_dx2.addOrReplaceChild("cube_r26",
				CubeListBuilder.create().texOffs(102, 20).addBox(-0.3487F, -5.6276F, -8.6916F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.5926F, 5.2926F, 8.1331F, 0.0F, 0.3927F, 0.0F));

		PartDefinition m_dx = manodx.addOrReplaceChild("m_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.8294F, -0.7F, 1.417F, 0.3442F, -0.0594F, 0.906F));

		PartDefinition cube_r27 = m_dx.addOrReplaceChild("cube_r27",
				CubeListBuilder.create().texOffs(32, 102).addBox(0.6726F, -4.0314F, -9.3074F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.3001F, 3.795F, 8.9066F, 0.0F, 0.2618F, 0.0F));

		PartDefinition m_dx2 = m_dx.addOrReplaceChild("m_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.9295F, -0.105F, 0.2237F, 0.1222F, -0.0346F, 0.9033F));

		PartDefinition cube_r28 = m_dx2.addOrReplaceChild("cube_r28",
				CubeListBuilder.create().texOffs(102, 24).addBox(-1.7995F, -3.465F, -9.6188F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.1456F, 3.4008F, 8.8268F, 0.0F, 0.2618F, 0.0F));

		PartDefinition mi_dx = manodx.addOrReplaceChild("mi_dx",
				CubeListBuilder.create().texOffs(102, 43).addBox(-2.0746F, -0.3764F, -0.505F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0274F, -0.5653F, -0.8635F, -0.1341F, -0.2011F, 1.0274F));

		PartDefinition mi_dx2 = mi_dx.addOrReplaceChild("mi_dx2",
				CubeListBuilder.create().texOffs(8, 101).addBox(-2.0336F, -0.072F, -0.4984F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.0767F, -0.2555F, 0.0344F, -0.0436F, 0.0F, 0.829F));

		PartDefinition arto_s_sx = All.addOrReplaceChild("arto_s_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(3.7503F, -0.7329F, -0.8944F, 0.0F, 0.3054F, 0.0F));

		PartDefinition bracciosx1 = arto_s_sx.addOrReplaceChild("bracciosx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(2.4699F, 0.0876F, -0.1422F, 0.1408F, -0.05F, 0.0467F));

		PartDefinition cube_r29 = bracciosx1.addOrReplaceChild("cube_r29",
				CubeListBuilder.create().texOffs(24, 78).addBox(-4.9147F, 0.8888F, -12.61F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.7259F, -0.7372F, 4.8327F, -0.0873F, -0.3927F, 0.0F));

		PartDefinition cube_r30 = bracciosx1.addOrReplaceChild("cube_r30",
				CubeListBuilder.create().texOffs(58, 70).addBox(-4.9147F, -0.9113F, -12.8266F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.7259F, -1.7372F, 4.8327F, 0.1309F, -0.3927F, 0.0F));

		PartDefinition bracciosx2 = bracciosx1.addOrReplaceChild("bracciosx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(3.127F, 0.0427F, -8.5307F, -1.0629F, 0.8939F, -1.3799F));

		PartDefinition cube_r31 = bracciosx2.addOrReplaceChild("cube_r31",
				CubeListBuilder.create().texOffs(48, 81).addBox(-1.3259F, -1.1101F, -6.9262F, 3.0F, 2.0F, 7.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.6282F, -0.187F, 0.2669F, -2.9671F, -1.3963F, 3.1416F));

		PartDefinition manosx = bracciosx2.addOrReplaceChild("manosx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(6.2962F, 0.9565F, 1.6523F, -0.2548F, -0.7555F, 0.2399F));

		PartDefinition cube_r32 = manosx.addOrReplaceChild("cube_r32",
				CubeListBuilder.create().texOffs(90, 53).addBox(1.9969F, 1.6962F, -9.2232F, 3.0F, 1.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.3168F, -2.2283F, 7.579F, 0.0278F, 0.5666F, 0.0954F));

		PartDefinition mi_sx = manosx.addOrReplaceChild("mi_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.4679F, 0.2696F, -2.7378F, -0.6795F, -0.1709F, -1.046F));

		PartDefinition cube_r33 = mi_sx.addOrReplaceChild("cube_r33",
				CubeListBuilder.create().texOffs(100, 96).addBox(3.5388F, 5.5529F, -8.3006F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.9715F, -6.1763F, 8.1997F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition mi_sx2 = mi_sx.addOrReplaceChild("mi_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(2.6657F, -6.7945F, 5.016F, -0.8862F, -0.4335F, -0.7046F));

		PartDefinition cube_r34 = mi_sx2.addOrReplaceChild("cube_r34",
				CubeListBuilder.create().texOffs(56, 102).addBox(-3.8624F, 5.654F, -7.1139F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4057F, 0.0182F, 3.1837F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition mi_sx3 = mi_sx2.addOrReplaceChild("mi_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.8F, -0.4F, -1.0F, -0.491F, -0.0806F, -0.5042F));

		PartDefinition cube_r35 = mi_sx3.addOrReplaceChild("cube_r35",
				CubeListBuilder.create().texOffs(64, 102).addBox(-6.3883F, 0.9019F, -7.4954F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4057F, 0.0182F, 3.1837F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition m_sx = manosx.addOrReplaceChild("m_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.4211F, 0.938F, -0.0286F, -0.8153F, -0.4389F, -1.4176F));

		PartDefinition cube_r36 = m_sx.addOrReplaceChild("cube_r36",
				CubeListBuilder.create().texOffs(0, 102).addBox(3.2848F, 2.0679F, -8.5457F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.1525F, -0.5317F, 8.6524F, 0.0F, 0.48F, 0.0436F));

		PartDefinition m_sx2 = m_sx.addOrReplaceChild("m_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(2.2525F, -0.8317F, 8.1524F, -0.2637F, -0.146F, -0.7867F));

		PartDefinition cube_r37 = m_sx2.addOrReplaceChild("cube_r37",
				CubeListBuilder.create().texOffs(102, 52).addBox(1.9789F, 3.7623F, -8.9645F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9F, 0.0F, 0.4F, 0.0F, 0.48F, 0.0436F));

		PartDefinition m_sx3 = m_sx2.addOrReplaceChild("m_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.794F, 3.8836F, -8.7527F, -0.4033F, -0.2511F, -0.8531F));

		PartDefinition cube_r38 = m_sx3.addOrReplaceChild("cube_r38",
				CubeListBuilder.create().texOffs(60, 102).addBox(-2.488F, 2.6794F, -8.8275F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.7419F, -2.9317F, 6.4687F, 0.0F, 0.48F, 0.0436F));

		PartDefinition i_sx = manosx.addOrReplaceChild("i_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(7.0269F, -0.6545F, 2.3331F, -1.1681F, 0.3807F, -1.2076F));

		PartDefinition cube_r39 = i_sx.addOrReplaceChild("cube_r39",
				CubeListBuilder.create().texOffs(102, 22).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.032F, 1.7797F, -4.091F, 0.4054F, 0.2389F, -0.3502F));

		PartDefinition i_sx2 = i_sx.addOrReplaceChild("i_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.505F, -0.0504F, -0.0503F, -0.0981F, -0.1906F, -1.0669F));

		PartDefinition cube_r40 = i_sx2.addOrReplaceChild("cube_r40",
				CubeListBuilder.create().texOffs(52, 102).addBox(1.2734F, 0.2815F, -8.9243F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.6701F, -0.1961F, 4.3986F, 0.0F, 0.3491F, 0.0436F));

		PartDefinition i_sx3 = i_sx2.addOrReplaceChild("i_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.8179F, 0.6317F, -4.4242F, -0.4099F, 0.2942F, 0.1127F));

		PartDefinition cube_r41 = i_sx3.addOrReplaceChild("cube_r41",
				CubeListBuilder.create().texOffs(102, 58).addBox(-1.0882F, -1.2623F, -9.4483F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0169F, -4.5568F, 7.7612F, -0.2801F, 0.3252F, -2.3477F));

		PartDefinition a_sx = manosx.addOrReplaceChild("a_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(2.0643F, 0.1596F, 2.006F, -0.7409F, -0.4413F, -1.3411F));

		PartDefinition cube_r42 = a_sx.addOrReplaceChild("cube_r42",
				CubeListBuilder.create().texOffs(100, 100).addBox(2.8214F, 4.7138F, -8.4418F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.3651F, -2.3889F, 5.5318F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition a_sx2 = a_sx.addOrReplaceChild("a_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.9055F, -2.7745F, 3.2195F, -0.3518F, -0.123F, -0.6531F));

		PartDefinition cube_r43 = a_sx2.addOrReplaceChild("cube_r43",
				CubeListBuilder.create().texOffs(102, 54).addBox(0.2478F, 5.6762F, -8.688F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.3405F, -0.0144F, 2.2123F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition a_sx3 = a_sx2.addOrReplaceChild("a_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.0F, -0.6F, -0.6F, -0.5217F, -0.2131F, -0.8754F));

		PartDefinition cube_r44 = a_sx3.addOrReplaceChild("cube_r44",
				CubeListBuilder.create().texOffs(102, 60).addBox(-4.4887F, 1.9776F, -8.8906F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.3405F, -0.0144F, 2.2123F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition p_sx = manosx.addOrReplaceChild("p_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.4331F, -3.1232F, 8.8473F, 0.0062F, -0.2172F, -0.0199F));

		PartDefinition p_sx1 = p_sx.addOrReplaceChild("p_sx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.8622F, 0.1623F, 0.2523F, 0.5661F, 0.5338F, 0.3127F));

		PartDefinition cube_r45 = p_sx1.addOrReplaceChild("cube_r45",
				CubeListBuilder.create().texOffs(20, 102).addBox(0.6463F, -2.8332F, -6.5387F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.2459F, 0.0326F, -2.1206F, 0.0436F, -0.5236F, 0.0436F));

		PartDefinition p_sx2 = p_sx.addOrReplaceChild("p_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.8622F, -0.1624F, -0.2523F, 0.2151F, 0.9163F, -0.5546F));

		PartDefinition cube_r46 = p_sx2.addOrReplaceChild("cube_r46",
				CubeListBuilder.create().texOffs(102, 45).addBox(3.7005F, 0.2841F, -6.5965F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.4785F, -0.0427F, -3.1161F, 0.0436F, -0.5236F, 0.0436F));

		PartDefinition knife = manosx.addOrReplaceChild("knife", CubeListBuilder.create(),
				PartPose.offsetAndRotation(4.4737F, -2.0618F, 4.64F, 0.9773F, 0.0162F, -1.6609F));

		PartDefinition cube_r47 = knife.addOrReplaceChild("cube_r47",
				CubeListBuilder.create().texOffs(100, 92).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 9.7046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r48 = knife.addOrReplaceChild("cube_r48",
				CubeListBuilder.create().texOffs(72, 100).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 4.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 8.3046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r49 = knife.addOrReplaceChild("cube_r49",
				CubeListBuilder.create().texOffs(76, 100).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 1.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -0.0954F, 2.7364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r50 = knife.addOrReplaceChild("cube_r50",
				CubeListBuilder.create().texOffs(102, 56).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 0.6046F, 3.4364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r51 = knife.addOrReplaceChild("cube_r51",
				CubeListBuilder.create().texOffs(92, 98).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 6.9046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r52 = knife.addOrReplaceChild("cube_r52",
				CubeListBuilder.create().texOffs(84, 99).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 5.5046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r53 = knife.addOrReplaceChild("cube_r53",
				CubeListBuilder.create().texOffs(96, 98).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 4.1046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r54 = knife.addOrReplaceChild("cube_r54",
				CubeListBuilder.create().texOffs(88, 99).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 2.7046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r55 = knife.addOrReplaceChild("cube_r55",
				CubeListBuilder.create().texOffs(68, 100).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, 1.3046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r56 = knife.addOrReplaceChild("cube_r56",
				CubeListBuilder.create().texOffs(48, 100).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -0.0954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r57 = knife.addOrReplaceChild("cube_r57",
				CubeListBuilder.create().texOffs(100, 63).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.8954F, -2.8636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r58 = knife.addOrReplaceChild("cube_r58",
				CubeListBuilder.create().texOffs(100, 102).addBox(-9.0F, -1.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.8954F, -1.4636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r59 = knife.addOrReplaceChild("cube_r59",
				CubeListBuilder.create().texOffs(42, 100).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.8954F, 5.5364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r60 = knife.addOrReplaceChild("cube_r60",
				CubeListBuilder.create().texOffs(84, 90).addBox(-9.0F, -1.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.8954F, 4.1364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r61 = knife.addOrReplaceChild("cube_r61",
				CubeListBuilder.create().texOffs(102, 49).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.1954F, -2.1636F, -0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r62 = knife.addOrReplaceChild("cube_r62",
				CubeListBuilder.create().texOffs(38, 102).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -4.2954F, 4.1364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r63 = knife.addOrReplaceChild("cube_r63",
				CubeListBuilder.create().texOffs(50, 90).addBox(-9.0F, -2.0F, -2.0F, 1.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -2.8954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r64 = knife.addOrReplaceChild("cube_r64",
				CubeListBuilder.create().texOffs(82, 76).addBox(-9.0F, -2.0F, 0.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -4.2954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r65 = knife.addOrReplaceChild("cube_r65",
				CubeListBuilder.create().texOffs(24, 74).addBox(-9.0F, -2.0F, 0.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -5.7954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r66 = knife.addOrReplaceChild("cube_r66",
				CubeListBuilder.create().texOffs(60, 96).addBox(-9.0F, -2.0F, -1.0F, 1.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(8.5F, -8.5954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition spallasx = arto_s_sx.addOrReplaceChild("spallasx",
				CubeListBuilder.create().texOffs(88, 76).addBox(1.6963F, -3.3921F, -10.087F, 4.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.8993F, 0.15F, 8.7211F, 0.1705F, 0.4232F, 0.0949F));

		PartDefinition gambadx1 = All.addOrReplaceChild("gambadx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-4.8685F, -1.8562F, -20.1956F, 0.1709F, -0.1321F, 0.2853F));

		PartDefinition cube_r67 = gambadx1.addOrReplaceChild("cube_r67",
				CubeListBuilder.create().texOffs(32, 57).addBox(-1.1618F, 2.9317F, -11.1316F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.052F, -0.1723F, 8.0893F, -0.3655F, 0.0989F, -0.4798F));

		PartDefinition cube_r68 = gambadx1.addOrReplaceChild("cube_r68",
				CubeListBuilder.create().texOffs(90, 41).addBox(-0.1618F, 1.0243F, -12.7183F, 3.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.052F, -0.1723F, 8.0893F, -0.3218F, 0.0989F, -0.4798F));

		PartDefinition cube_r69 = gambadx1.addOrReplaceChild("cube_r69",
				CubeListBuilder.create().texOffs(50, 0).addBox(-1.1618F, 0.9215F, -11.3915F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.052F, -0.1723F, 8.0893F, -0.2782F, 0.0989F, -0.4798F));

		PartDefinition gambadx2 = gambadx1.addOrReplaceChild("gambadx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.4147F, -1.7682F, -11.0238F, -0.0762F, 0.1506F, 0.2556F));

		PartDefinition cube_r70 = gambadx2.addOrReplaceChild("cube_r70",
				CubeListBuilder.create().texOffs(0, 33).addBox(-2.0F, -0.7492F, -5.9869F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.3372F, 0.6301F, 2.1956F, 0.0691F, 0.0008F, -0.7081F));

		PartDefinition cube_r71 = gambadx2.addOrReplaceChild("cube_r71",
				CubeListBuilder.create().texOffs(32, 19).addBox(-2.0F, -1.251F, -5.9912F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.3372F, 0.6301F, 2.1956F, 0.1564F, 0.0008F, -0.7081F));

		PartDefinition piededx = gambadx2.addOrReplaceChild("piededx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.6743F, -1.2601F, -3.8912F, -0.0432F, 0.0279F, 0.0768F));

		PartDefinition cube_r72 = piededx.addOrReplaceChild("cube_r72",
				CubeListBuilder.create().texOffs(0, 96).addBox(0.9341F, -3.9125F, -11.623F, 2.0F, 4.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0328F, 1.5604F, 10.623F, 0.0F, 0.0F, -0.8727F));

		PartDefinition cube_r73 = piededx.addOrReplaceChild("cube_r73",
				CubeListBuilder.create().texOffs(92, 11).addBox(-1.1233F, -0.3872F, -11.623F, 4.0F, 3.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0328F, 1.5604F, 10.623F, 0.0F, 0.0F, -0.6981F));

		PartDefinition cube_r74 = piededx.addOrReplaceChild("cube_r74",
				CubeListBuilder.create().texOffs(92, 63).addBox(-1.1209F, -4.9955F, -11.623F, 2.0F, 5.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.0328F, 1.5604F, 10.623F, 0.0F, 0.0F, -0.3927F));

		PartDefinition gambasx1 = All.addOrReplaceChild("gambasx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.0683F, -1.678F, -19.8508F, -0.126F, 0.0785F, -0.1576F));

		PartDefinition cube_r75 = gambasx1.addOrReplaceChild("cube_r75",
				CubeListBuilder.create().texOffs(62, 57).addBox(-0.8626F, -1.328F, -7.2157F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7976F, 0.5644F, 3.4124F, -0.0417F, -0.1269F, 0.3722F));

		PartDefinition cube_r76 = gambasx1.addOrReplaceChild("cube_r76",
				CubeListBuilder.create().texOffs(90, 47).addBox(-0.8626F, -3.0604F, -8.6204F, 3.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7976F, 0.5644F, 3.4124F, 0.0019F, -0.1269F, 0.3722F));

		PartDefinition cube_r77 = gambasx1.addOrReplaceChild("cube_r77",
				CubeListBuilder.create().texOffs(0, 61).addBox(-0.8626F, -2.9806F, -7.1193F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7976F, 0.5644F, 3.4124F, 0.0456F, -0.1269F, 0.3722F));

		PartDefinition gambasx2 = gambasx1.addOrReplaceChild("gambasx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.2019F, 1.0181F, -11.2163F, 0.4755F, -0.2174F, -0.0889F));

		PartDefinition cube_r78 = gambasx2.addOrReplaceChild("cube_r78",
				CubeListBuilder.create().texOffs(0, 19).addBox(-0.6105F, -5.7437F, -15.1728F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.06F, 6.7056F, 10.5412F, -0.1106F, 0.2278F, 0.3115F));

		PartDefinition cube_r79 = gambasx2.addOrReplaceChild("cube_r79",
				CubeListBuilder.create().texOffs(0, 47).addBox(-0.6105F, -4.4245F, -15.525F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.06F, 6.7056F, 10.5412F, -0.1978F, 0.2278F, 0.3115F));

		PartDefinition piedesx = gambasx2.addOrReplaceChild("piedesx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.1058F, -2.6175F, -3.6409F, 0.0223F, -0.0514F, -0.0113F));

		PartDefinition cube_r80 = piedesx.addOrReplaceChild("cube_r80",
				CubeListBuilder.create().texOffs(84, 92).addBox(2.4466F, -11.8373F, -14.5246F, 2.0F, 5.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9542F, 11.425F, 11.2766F, -0.2582F, 0.1909F, 0.0336F));

		PartDefinition cube_r81 = piedesx.addOrReplaceChild("cube_r81",
				CubeListBuilder.create().texOffs(92, 92).addBox(-3.1433F, -11.5169F, -14.5246F, 2.0F, 4.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9542F, 11.425F, 11.2766F, -0.1411F, 0.288F, 0.518F));

		PartDefinition cube_r82 = piedesx.addOrReplaceChild("cube_r82",
				CubeListBuilder.create().texOffs(0, 91).addBox(-1.7622F, -7.9124F, -14.5246F, 4.0F, 3.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9542F, 11.425F, 11.2766F, -0.1895F, 0.2592F, 0.3392F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		All.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}