// Made with Blockbench 4.12.6
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modeleyesinthedark_chase<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "eyesinthedark_chase"), "main");
	private final ModelPart all;
	private final ModelPart gambasx;
	private final ModelPart gambadx;
	private final ModelPart corpo;
	private final ModelPart bracciodx;
	private final ModelPart bracciosx;
	private final ModelPart testa;
	private final ModelPart corna;
	private final ModelPart corno_esposto;
	private final ModelPart eye2;
	private final ModelPart main_eye;

	public Modeleyesinthedark_chase(ModelPart root) {
		this.all = root.getChild("all");
		this.gambasx = this.all.getChild("gambasx");
		this.gambadx = this.all.getChild("gambadx");
		this.corpo = this.all.getChild("corpo");
		this.bracciodx = this.all.getChild("bracciodx");
		this.bracciosx = this.all.getChild("bracciosx");
		this.testa = this.all.getChild("testa");
		this.corna = this.testa.getChild("corna");
		this.corno_esposto = this.corna.getChild("corno_esposto");
		this.eye2 = this.corno_esposto.getChild("eye2");
		this.main_eye = this.testa.getChild("main_eye");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition all = partdefinition.addOrReplaceChild("all", CubeListBuilder.create(),
				PartPose.offset(0.0F, 24.0F, 0.0F));

		PartDefinition gambasx = all.addOrReplaceChild("gambasx", CubeListBuilder.create().texOffs(24, 16).addBox(-1.0F,
				-12.0F, -4.9F, 4.0F, 12.0F, 4.0F, new CubeDeformation(0.0F)), PartPose.offset(1.0F, 0.0F, 2.9F));

		PartDefinition gambadx = all.addOrReplaceChild("gambadx", CubeListBuilder.create(),
				PartPose.offset(1.0F, 0.0F, 2.9F));

		PartDefinition gambadx_r1 = gambadx.addOrReplaceChild("gambadx_r1",
				CubeListBuilder.create().texOffs(32, 0).addBox(-2.0F, -12.0F, -2.0F, 4.0F, 12.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-3.0F, 0.0F, -2.9F, 0.0F, 0.0087F, 0.0F));

		PartDefinition corpo = all.addOrReplaceChild("corpo", CubeListBuilder.create(),
				PartPose.offset(-2.2F, -12.0F, 3.0F));

		PartDefinition corpo_r1 = corpo.addOrReplaceChild("corpo_r1",
				CubeListBuilder.create().texOffs(0, 16).addBox(-3.0F, -12.0F, -2.0F, 8.0F, 12.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.25F, 0.0F, -3.0F, -0.0042F, -0.0042F, -0.0053F));

		PartDefinition bracciodx = all.addOrReplaceChild("bracciodx", CubeListBuilder.create(),
				PartPose.offset(-6.7F, -11.0F, -2.0F));

		PartDefinition bracciodx_r1 = bracciodx.addOrReplaceChild("bracciodx_r1",
				CubeListBuilder.create().texOffs(16, 32).addBox(-2.0F, -12.0F, -2.0F, 4.0F, 12.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.7F, -0.9F, 2.0F, 0.0008F, 0.0F, -0.0087F));

		PartDefinition bracciosx = all.addOrReplaceChild("bracciosx", CubeListBuilder.create(),
				PartPose.offset(6.0F, -11.6F, 0.0F));

		PartDefinition bracciosx_r1 = bracciosx.addOrReplaceChild("bracciosx_r1",
				CubeListBuilder.create().texOffs(0, 32).addBox(-2.0F, -12.0F, -2.0F, 4.0F, 12.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.2F, -0.4F, 0.1F, 0.0F, 0.0F, -0.0175F));

		PartDefinition testa = all.addOrReplaceChild("testa", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.0348F, -28.0379F, 0.2607F, -1.051F, 0.1109F, -0.5406F));

		PartDefinition testa_r1 = testa.addOrReplaceChild("testa_r1",
				CubeListBuilder.create().texOffs(0, 0).addBox(-4.0F, -7.0F, -4.0F, 8.0F, 8.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.5349F, 1.4379F, 2.1393F, 0.9503F, -0.5023F, 0.2251F));

		PartDefinition corna = testa.addOrReplaceChild("corna", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.017F, 0.7628F, -9.9639F, 0.0F, 0.3927F, 0.0F));

		PartDefinition corno1_r1 = corna.addOrReplaceChild("corno1_r1",
				CubeListBuilder.create().texOffs(32, 32).addBox(-4.0F, -7.0F, -4.0F, 2.0F, 7.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.0821F, -4.2249F, 5.1032F, 1.452F, -0.0365F, -0.2781F));

		PartDefinition corno3_r1 = corna.addOrReplaceChild("corno3_r1",
				CubeListBuilder.create().texOffs(38, 32).addBox(-4.0F, -5.0F, -4.0F, 2.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.0821F, -1.2249F, -5.8968F, -2.6417F, 0.2046F, -0.6956F));

		PartDefinition corno_esposto = corna.addOrReplaceChild("corno_esposto", CubeListBuilder.create(),
				PartPose.offset(3.2901F, 4.095F, -0.8727F));

		PartDefinition corno2_r1 = corno_esposto.addOrReplaceChild("corno2_r1",
				CubeListBuilder.create().texOffs(38, 38).addBox(-4.0F, -5.0F, -4.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.5921F, -4.72F, -1.3241F, 2.8423F, -0.332F, -0.3802F));

		PartDefinition eye2 = corno_esposto.addOrReplaceChild("eye2", CubeListBuilder.create(),
				PartPose.offset(-4.8079F, 18.5801F, 14.9759F));

		PartDefinition eye2_r1 = eye2.addOrReplaceChild("eye2_r1",
				CubeListBuilder.create().texOffs(40, 19).addBox(-4.0F, -5.0F, -4.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(9.6F, -21.9F, -14.2F, 2.6761F, -0.7021F, 0.0517F));

		PartDefinition main_eye = testa.addOrReplaceChild("main_eye", CubeListBuilder.create(),
				PartPose.offset(1.7301F, 2.9898F, -2.179F));

		PartDefinition main_eye_r1 = main_eye.addOrReplaceChild("main_eye_r1",
				CubeListBuilder.create().texOffs(40, 16).addBox(-4.0F, -1.0F, -3.0F, 2.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.135F, -1.5519F, 2.7183F, 0.9503F, -0.5023F, 0.2251F));

		return LayerDefinition.create(meshdefinition, 64, 64);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		all.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}