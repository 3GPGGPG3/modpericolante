// Made with Blockbench 4.12.6
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelknight<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "knight"), "main");
	private final ModelPart All;
	private final ModelPart corpo;
	private final ModelPart knife;
	private final ModelPart head;
	private final ModelPart riseable_helmet;
	private final ModelPart arto_s_dx;
	private final ModelPart spalladx;
	private final ModelPart bracciodx1;
	private final ModelPart bracciodx2;
	private final ModelPart manodx;
	private final ModelPart p_dx;
	private final ModelPart p_dx2;
	private final ModelPart a_dx;
	private final ModelPart a_dx2;
	private final ModelPart i_dx;
	private final ModelPart i_dx2;
	private final ModelPart m_dx;
	private final ModelPart m_dx2;
	private final ModelPart mi_dx;
	private final ModelPart mi_dx2;
	private final ModelPart arto_s_sx;
	private final ModelPart bracciosx1;
	private final ModelPart bracciosx2;
	private final ModelPart manosx;
	private final ModelPart mi_sx;
	private final ModelPart mi_sx2;
	private final ModelPart mi_sx3;
	private final ModelPart m_sx;
	private final ModelPart m_sx2;
	private final ModelPart m_sx3;
	private final ModelPart i_sx;
	private final ModelPart i_sx2;
	private final ModelPart i_sx3;
	private final ModelPart a_sx;
	private final ModelPart a_sx2;
	private final ModelPart a_sx3;
	private final ModelPart p_sx;
	private final ModelPart p_sx1;
	private final ModelPart p_sx2;
	private final ModelPart spallasx;
	private final ModelPart gambadx1;
	private final ModelPart gambadx2;
	private final ModelPart piededx;
	private final ModelPart gambasx1;
	private final ModelPart gambasx2;
	private final ModelPart piedesx;

	public Modelknight(ModelPart root) {
		this.All = root.getChild("All");
		this.corpo = this.All.getChild("corpo");
		this.knife = this.corpo.getChild("knife");
		this.head = this.All.getChild("head");
		this.riseable_helmet = this.head.getChild("riseable_helmet");
		this.arto_s_dx = this.All.getChild("arto_s_dx");
		this.spalladx = this.arto_s_dx.getChild("spalladx");
		this.bracciodx1 = this.arto_s_dx.getChild("bracciodx1");
		this.bracciodx2 = this.bracciodx1.getChild("bracciodx2");
		this.manodx = this.bracciodx2.getChild("manodx");
		this.p_dx = this.manodx.getChild("p_dx");
		this.p_dx2 = this.p_dx.getChild("p_dx2");
		this.a_dx = this.manodx.getChild("a_dx");
		this.a_dx2 = this.a_dx.getChild("a_dx2");
		this.i_dx = this.manodx.getChild("i_dx");
		this.i_dx2 = this.i_dx.getChild("i_dx2");
		this.m_dx = this.manodx.getChild("m_dx");
		this.m_dx2 = this.m_dx.getChild("m_dx2");
		this.mi_dx = this.manodx.getChild("mi_dx");
		this.mi_dx2 = this.mi_dx.getChild("mi_dx2");
		this.arto_s_sx = this.All.getChild("arto_s_sx");
		this.bracciosx1 = this.arto_s_sx.getChild("bracciosx1");
		this.bracciosx2 = this.bracciosx1.getChild("bracciosx2");
		this.manosx = this.bracciosx2.getChild("manosx");
		this.mi_sx = this.manosx.getChild("mi_sx");
		this.mi_sx2 = this.mi_sx.getChild("mi_sx2");
		this.mi_sx3 = this.mi_sx2.getChild("mi_sx3");
		this.m_sx = this.manosx.getChild("m_sx");
		this.m_sx2 = this.m_sx.getChild("m_sx2");
		this.m_sx3 = this.m_sx2.getChild("m_sx3");
		this.i_sx = this.manosx.getChild("i_sx");
		this.i_sx2 = this.i_sx.getChild("i_sx2");
		this.i_sx3 = this.i_sx2.getChild("i_sx3");
		this.a_sx = this.manosx.getChild("a_sx");
		this.a_sx2 = this.a_sx.getChild("a_sx2");
		this.a_sx3 = this.a_sx2.getChild("a_sx3");
		this.p_sx = this.manosx.getChild("p_sx");
		this.p_sx1 = this.p_sx.getChild("p_sx1");
		this.p_sx2 = this.p_sx.getChild("p_sx2");
		this.spallasx = this.arto_s_sx.getChild("spallasx");
		this.gambadx1 = this.All.getChild("gambadx1");
		this.gambadx2 = this.gambadx1.getChild("gambadx2");
		this.piededx = this.gambadx2.getChild("piededx");
		this.gambasx1 = this.All.getChild("gambasx1");
		this.gambasx2 = this.gambasx1.getChild("gambasx2");
		this.piedesx = this.gambasx2.getChild("piedesx");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition All = partdefinition.addOrReplaceChild("All", CubeListBuilder.create(),
				PartPose.offset(0.0F, 20.0F, 12.0F));

		PartDefinition corpo = All.addOrReplaceChild("corpo", CubeListBuilder.create(),
				PartPose.offset(-0.2611F, 1.9829F, -3.5F));

		PartDefinition cube_r1 = corpo.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(66, 41).addBox(-0.5F, -2.0F, -5.5F, 1.0F, 4.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.577F, 0.6436F, -2.5F, 0.0F, 0.0F, 0.4363F));

		PartDefinition cube_r2 = corpo.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(66, 26).addBox(-0.5F, -2.0F, -5.5F, 1.0F, 4.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-5.1549F, -0.6564F, -2.5F, 0.0F, 0.0F, -0.1745F));

		PartDefinition cube_r3 = corpo.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(32, 45).addBox(-3.0F, -0.5F, -6.0F, 6.0F, 1.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.0739F, -2.0347F, -2.0F, 0.0F, 0.0F, 0.3927F));

		PartDefinition cube_r4 = corpo.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(0, 85).addBox(-3.0F, -0.5F, -2.5F, 6.0F, 1.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(3.2481F, -2.3347F, 5.5F, -0.2103F, 0.0207F, 0.3016F));

		PartDefinition cube_r5 = corpo.addOrReplaceChild("cube_r5",
				CubeListBuilder.create().texOffs(82, 70).addBox(-3.0F, -0.5F, -2.5F, 6.0F, 1.0F, 5.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.7519F, -3.0347F, 5.5F, -0.1997F, -0.0695F, -0.1256F));

		PartDefinition cube_r6 = corpo.addOrReplaceChild("cube_r6",
				CubeListBuilder.create().texOffs(32, 33).addBox(-3.0F, -0.5F, -5.5F, 6.0F, 1.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.4518F, -2.6347F, -2.5F, 0.0F, 0.0F, -0.1745F));

		PartDefinition cube_r7 = corpo
				.addOrReplaceChild("cube_r7",
						CubeListBuilder.create().texOffs(0, 0).addBox(-5.0F, -2.0F, -7.5F, 10.0F, 4.0F, 15.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1309F));

		PartDefinition knife = corpo.addOrReplaceChild("knife", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.2611F, -3.0875F, -2.8364F, 0.0F, -1.5708F, 0.1309F));

		PartDefinition cube_r8 = knife.addOrReplaceChild("cube_r8",
				CubeListBuilder.create().texOffs(100, 92).addBox(0.0F, -2.0F, -1.0F, 1.0F, 3.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 9.7046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r9 = knife.addOrReplaceChild("cube_r9",
				CubeListBuilder.create().texOffs(72, 100).addBox(0.0F, -2.0F, -1.0F, 1.0F, 4.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 8.3046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r10 = knife.addOrReplaceChild("cube_r10",
				CubeListBuilder.create().texOffs(76, 100).addBox(0.0F, -2.0F, -2.0F, 1.0F, 1.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -0.0954F, 2.7364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r11 = knife.addOrReplaceChild("cube_r11",
				CubeListBuilder.create().texOffs(102, 56).addBox(0.0F, -2.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 0.6046F, 3.4364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r12 = knife.addOrReplaceChild("cube_r12",
				CubeListBuilder.create().texOffs(92, 98).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 6.9046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r13 = knife.addOrReplaceChild("cube_r13",
				CubeListBuilder.create().texOffs(84, 99).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 5.5046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r14 = knife.addOrReplaceChild("cube_r14",
				CubeListBuilder.create().texOffs(96, 98).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 4.1046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r15 = knife.addOrReplaceChild("cube_r15",
				CubeListBuilder.create().texOffs(88, 99).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 2.7046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r16 = knife.addOrReplaceChild("cube_r16",
				CubeListBuilder.create().texOffs(68, 100).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, 1.3046F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r17 = knife.addOrReplaceChild("cube_r17",
				CubeListBuilder.create().texOffs(48, 100).addBox(0.0F, -2.0F, -1.0F, 1.0F, 5.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -0.0954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r18 = knife.addOrReplaceChild("cube_r18",
				CubeListBuilder.create().texOffs(100, 63).addBox(0.0F, -2.0F, -2.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.8954F, -2.8636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r19 = knife.addOrReplaceChild("cube_r19",
				CubeListBuilder.create().texOffs(100, 102).addBox(0.0F, -1.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.8954F, -1.4636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r20 = knife.addOrReplaceChild("cube_r20",
				CubeListBuilder.create().texOffs(42, 100).addBox(0.0F, -2.0F, -2.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.8954F, 5.5364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r21 = knife.addOrReplaceChild("cube_r21",
				CubeListBuilder.create().texOffs(84, 90).addBox(0.0F, -1.0F, -2.0F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.8954F, 4.1364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r22 = knife.addOrReplaceChild("cube_r22",
				CubeListBuilder.create().texOffs(102, 49).addBox(0.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.1954F, -2.1636F, -0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r23 = knife.addOrReplaceChild("cube_r23",
				CubeListBuilder.create().texOffs(38, 102).addBox(0.0F, -2.0F, -2.0F, 1.0F, 2.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -4.2954F, 4.1364F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r24 = knife.addOrReplaceChild("cube_r24",
				CubeListBuilder.create().texOffs(50, 90).addBox(0.0F, -2.0F, -2.0F, 1.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -2.8954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r25 = knife.addOrReplaceChild("cube_r25",
				CubeListBuilder.create().texOffs(82, 76).addBox(0.0F, -2.0F, 0.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -4.2954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r26 = knife.addOrReplaceChild("cube_r26",
				CubeListBuilder.create().texOffs(24, 74).addBox(0.0F, -2.0F, 0.0F, 1.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -5.7954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r27 = knife.addOrReplaceChild("cube_r27",
				CubeListBuilder.create().texOffs(60, 96).addBox(0.0F, -2.0F, -1.0F, 1.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.5F, -8.5954F, -0.0636F, 0.7854F, 0.0F, 0.0F));

		PartDefinition head = All.addOrReplaceChild("head",
				CubeListBuilder.create().texOffs(64, 13)
						.addBox(-3.5F, -4.3143F, -7.0714F, 7.0F, 6.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(90, 26)
						.addBox(3.5F, -0.6143F, -5.0714F, 1.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(30, 70)
						.addBox(-3.5F, 1.3857F, -6.0714F, 7.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(90, 35)
						.addBox(-3.5F, -3.6143F, -0.0714F, 7.0F, 5.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(92, 57)
						.addBox(-0.5F, -1.6143F, 0.9286F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(36, 90)
						.addBox(-1.5F, -2.6143F, 4.9286F, 3.0F, 4.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(22, 89)
						.addBox(-4.5F, -0.6143F, -5.0714F, 1.0F, 3.0F, 6.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.7981F, 2.076F, 11.0714F, 0.0F, 0.0F, 0.3927F));

		PartDefinition riseable_helmet = head.addOrReplaceChild("riseable_helmet",
				CubeListBuilder.create().texOffs(60, 90)
						.addBox(-0.5F, -2.3943F, -3.2765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(72, 90)
						.addBox(3.5F, -0.1943F, -3.2765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)).texOffs(92, 20)
						.addBox(3.5F, 0.8057F, -2.2765F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(12, 91)
						.addBox(-4.5F, 0.8057F, -2.2765F, 1.0F, 2.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(50, 13)
						.addBox(-4.5F, -0.1943F, -3.2765F, 1.0F, 1.0F, 5.0F, new CubeDeformation(0.0F)),
				PartPose.offset(0.0F, -4.42F, -2.795F));

		PartDefinition cube_r28 = riseable_helmet.addOrReplaceChild("cube_r28",
				CubeListBuilder.create().texOffs(68, 96)
						.addBox(-0.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(52, 98)
						.addBox(7.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-4.0F, 1.6057F, 2.2235F, -0.6109F, 0.0F, 0.0F));

		PartDefinition cube_r29 = riseable_helmet.addOrReplaceChild("cube_r29",
				CubeListBuilder.create().texOffs(76, 96)
						.addBox(-0.5F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(8, 97)
						.addBox(2.9F, -0.5F, -1.5F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.7F, 0.1057F, 2.3235F, -0.7854F, 0.0F, 0.0F));

		PartDefinition cube_r30 = riseable_helmet.addOrReplaceChild("cube_r30",
				CubeListBuilder.create().texOffs(16, 98)
						.addBox(-1.0F, -1.0F, 3.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(80, 11)
						.addBox(-1.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(100, 67)
						.addBox(0.0F, -1.0F, 4.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(48, 78)
						.addBox(-1.0F, -1.0F, 6.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.5F, 0.1057F, -5.2765F, 0.0F, 0.0F, -0.5672F));

		PartDefinition cube_r31 = riseable_helmet.addOrReplaceChild("cube_r31",
				CubeListBuilder.create().texOffs(34, 98)
						.addBox(0.0F, -1.0F, 3.0F, 1.0F, 1.0F, 3.0F, new CubeDeformation(0.0F)).texOffs(24, 98)
						.addBox(-3.0F, -1.0F, 2.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(24, 100)
						.addBox(-3.0F, -1.0F, 4.0F, 3.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(42, 98)
						.addBox(-3.0F, -1.0F, 6.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.5F, 0.1057F, -5.2765F, 0.0F, 0.0F, 0.5672F));

		PartDefinition arto_s_dx = All.addOrReplaceChild("arto_s_dx", CubeListBuilder.create(),
				PartPose.offset(0.0F, 4.0F, -12.0F));

		PartDefinition spalladx = arto_s_dx.addOrReplaceChild("spalladx",
				CubeListBuilder.create().texOffs(88, 84).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-6.5F, -3.1F, 14.0F, 0.22F, -0.1278F, -0.1594F));

		PartDefinition bracciodx1 = arto_s_dx.addOrReplaceChild("bracciodx1", CubeListBuilder.create(),
				PartPose.offset(-10.1013F, -1.3F, 10.2578F));

		PartDefinition cube_r32 = bracciodx1.addOrReplaceChild("cube_r32",
				CubeListBuilder.create().texOffs(80, 0).addBox(-1.5F, -1.0F, -4.5F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -1.0F, 0.0F, 0.1309F, 0.3927F, 0.0F));

		PartDefinition cube_r33 = bracciodx1.addOrReplaceChild("cube_r33",
				CubeListBuilder.create().texOffs(0, 74).addBox(-1.5F, -1.0F, -4.5F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.0873F, 0.3927F, 0.0F));

		PartDefinition bracciodx2 = bracciodx1.addOrReplaceChild("bracciodx2", CubeListBuilder.create(),
				PartPose.offset(-6.6417F, 1.926F, -4.2326F));

		PartDefinition cube_r34 = bracciodx2.addOrReplaceChild("cube_r34",
				CubeListBuilder.create().texOffs(68, 81).addBox(-2.0F, -3.0F, -6.0F, 3.0F, 2.0F, 7.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(5.0861F, -0.2108F, -1.5804F, -2.9671F, 1.3963F, -3.1416F));

		PartDefinition manodx = bracciodx2.addOrReplaceChild("manodx", CubeListBuilder.create(),
				PartPose.offset(-2.7139F, -0.6108F, 0.8196F));

		PartDefinition cube_r35 = manodx.addOrReplaceChild("cube_r35",
				CubeListBuilder.create().texOffs(92, 16).addBox(-1.0F, -1.0F, -2.0F, 3.0F, 1.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.0077F, 0.1744F, -0.0443F));

		PartDefinition p_dx = manodx.addOrReplaceChild("p_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.7028F, -0.8777F, 1.4432F, 0.4537F, -0.3829F, -0.0894F));

		PartDefinition cube_r36 = p_dx.addOrReplaceChild("cube_r36",
				CubeListBuilder.create().texOffs(102, 47).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4972F, 0.4777F, 0.1568F, 0.0436F, 1.2654F, 0.0F));

		PartDefinition p_dx2 = p_dx.addOrReplaceChild("p_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.5F, -0.8F, 1.9F, 0.6768F, -0.0278F, 0.2907F));

		PartDefinition cube_r37 = p_dx2.addOrReplaceChild("cube_r37",
				CubeListBuilder.create().texOffs(100, 98).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4972F, 0.4777F, 0.1568F, 0.0436F, 1.2654F, 0.0F));

		PartDefinition a_dx = manodx.addOrReplaceChild("a_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.0868F, -1.5F, -0.7924F, 0.0106F, -0.1568F, 1.1279F));

		PartDefinition cube_r38 = a_dx.addOrReplaceChild("cube_r38",
				CubeListBuilder.create().texOffs(102, 41).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0868F, 0.5F, 0.4924F, 0.0F, 0.1745F, 0.0F));

		PartDefinition a_dx2 = a_dx.addOrReplaceChild("a_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.9F, -0.9F, 0.3F, 0.0873F, -0.0435F, 0.8689F));

		PartDefinition cube_r39 = a_dx2.addOrReplaceChild("cube_r39",
				CubeListBuilder.create().texOffs(14, 102).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0868F, 0.5F, 0.4924F, 0.0F, 0.1745F, 0.0F));

		PartDefinition i_dx = manodx.addOrReplaceChild("i_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.4913F, -1.2F, 1.6381F, 0.4363F, 0.0F, 0.7418F));

		PartDefinition cube_r40 = i_dx.addOrReplaceChild("cube_r40",
				CubeListBuilder.create().texOffs(26, 102).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1913F, 0.5F, 0.4619F, 0.0F, 0.3927F, 0.0F));

		PartDefinition i_dx2 = i_dx.addOrReplaceChild("i_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.8F, -0.7F, 0.8F, 0.2094F, 0.0F, 0.6632F));

		PartDefinition cube_r41 = i_dx2.addOrReplaceChild("cube_r41",
				CubeListBuilder.create().texOffs(102, 20).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1913F, 0.5F, 0.4619F, 0.0F, 0.3927F, 0.0F));

		PartDefinition m_dx = manodx.addOrReplaceChild("m_dx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.9294F, -1.3F, 0.617F, 0.3442F, -0.0594F, 0.906F));

		PartDefinition cube_r42 = m_dx.addOrReplaceChild("cube_r42",
				CubeListBuilder.create().texOffs(32, 102).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1294F, 0.5F, 0.483F, 0.0F, 0.2618F, 0.0F));

		PartDefinition m_dx2 = m_dx.addOrReplaceChild("m_dx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.9F, -0.9F, 0.5F, 0.1222F, -0.0346F, 0.9033F));

		PartDefinition cube_r43 = m_dx2.addOrReplaceChild("cube_r43",
				CubeListBuilder.create().texOffs(102, 24).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.1294F, 0.5F, 0.483F, 0.0F, 0.2618F, 0.0F));

		PartDefinition mi_dx = manodx.addOrReplaceChild("mi_dx",
				CubeListBuilder.create().texOffs(102, 43).addBox(-1.0F, -0.5F, -0.5F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.9738F, -1.4F, -1.8993F, -0.1341F, -0.2011F, 1.0274F));

		PartDefinition mi_dx2 = mi_dx.addOrReplaceChild("mi_dx2",
				CubeListBuilder.create().texOffs(8, 101).addBox(-1.0F, -1.0F, -1.0F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.4F, -0.5F, 0.5F, -0.0436F, 0.0F, 0.829F));

		PartDefinition arto_s_sx = All.addOrReplaceChild("arto_s_sx", CubeListBuilder.create(),
				PartPose.offset(9.0F, 3.0F, -1.0F));

		PartDefinition bracciosx1 = arto_s_sx.addOrReplaceChild("bracciosx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.5013F, -0.1F, -1.0422F, -0.1309F, 0.0F, 0.4363F));

		PartDefinition cube_r44 = bracciosx1.addOrReplaceChild("cube_r44",
				CubeListBuilder.create().texOffs(24, 78).addBox(-1.5F, -1.0F, -4.5F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.5F, 0.0F, -0.0873F, -0.3927F, 0.0F));

		PartDefinition cube_r45 = bracciosx1.addOrReplaceChild("cube_r45",
				CubeListBuilder.create().texOffs(58, 70).addBox(-1.5F, -1.0F, -4.5F, 3.0F, 2.0F, 9.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, -0.5F, 0.0F, 0.1309F, -0.3927F, 0.0F));

		PartDefinition bracciosx2 = bracciosx1.addOrReplaceChild("bracciosx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(4.0785F, -0.6355F, -6.8775F, -0.1267F, 0.8946F, -0.4935F));

		PartDefinition cube_r46 = bracciosx2.addOrReplaceChild("cube_r46",
				CubeListBuilder.create().texOffs(48, 81).addBox(-1.5F, -1.0F, -3.5F, 3.0F, 2.0F, 7.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.8F, 0.0F, 0.7F, -2.9671F, -1.3963F, 3.1416F));

		PartDefinition manosx = bracciosx2.addOrReplaceChild("manosx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(4.0036F, 0.8109F, 1.4168F, -0.2548F, -0.7555F, 0.2399F));

		PartDefinition cube_r47 = manosx.addOrReplaceChild("cube_r47",
				CubeListBuilder.create().texOffs(90, 53).addBox(-3.6444F, -0.4282F, -2.5402F, 3.0F, 1.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(2.3652F, 0.1251F, -0.2754F, 0.0278F, 0.5666F, 0.0954F));

		PartDefinition mi_sx = manosx.addOrReplaceChild("mi_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.8546F, -0.6413F, -2.4457F, -0.4551F, 0.0088F, -0.6781F));

		PartDefinition cube_r48 = mi_sx.addOrReplaceChild("cube_r48",
				CubeListBuilder.create().texOffs(100, 96).addBox(-0.6486F, -0.5005F, -3.1216F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.5106F, 0.0664F, 2.1703F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition mi_sx2 = mi_sx.addOrReplaceChild("mi_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.2049F, -0.5518F, -1.0134F, -0.8862F, -0.4335F, -0.7046F));

		PartDefinition cube_r49 = mi_sx2.addOrReplaceChild("cube_r49",
				CubeListBuilder.create().texOffs(56, 102).addBox(1.3514F, -0.5005F, -3.1216F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4057F, 0.0182F, 3.1836F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition mi_sx3 = mi_sx2.addOrReplaceChild("mi_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.8F, -0.4F, -1.0F, -0.491F, -0.0806F, -0.5042F));

		PartDefinition cube_r50 = mi_sx3.addOrReplaceChild("cube_r50",
				CubeListBuilder.create().texOffs(64, 102).addBox(1.3514F, -0.5005F, -3.1216F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.4057F, 0.0182F, 3.1837F, 0.0F, 0.7418F, 0.0436F));

		PartDefinition m_sx = manosx.addOrReplaceChild("m_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(2.4167F, -0.1906F, -0.7758F, 0.0F, 0.0F, -0.2618F));

		PartDefinition cube_r51 = m_sx.addOrReplaceChild("cube_r51",
				CubeListBuilder.create().texOffs(0, 102).addBox(-1.0784F, -0.5005F, -1.1049F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.3485F, 0.0157F, 0.5003F, 0.0F, 0.48F, 0.0436F));

		PartDefinition m_sx2 = m_sx.addOrReplaceChild("m_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.4485F, -0.2843F, 0.0003F, -0.2637F, -0.146F, -0.7867F));

		PartDefinition cube_r52 = m_sx2.addOrReplaceChild("cube_r52",
				CubeListBuilder.create().texOffs(102, 52).addBox(0.8863F, -0.5005F, -1.1137F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9F, 0.0F, 0.4F, 0.0F, 0.48F, 0.0436F));

		PartDefinition m_sx3 = m_sx2.addOrReplaceChild("m_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.0454F, -0.4592F, -1.1845F, -0.4033F, -0.2511F, -0.8531F));

		PartDefinition cube_r53 = m_sx3.addOrReplaceChild("cube_r53",
				CubeListBuilder.create().texOffs(60, 102).addBox(0.8863F, -0.5005F, -1.1137F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9454F, -0.0408F, 1.1845F, 0.0F, 0.48F, 0.0436F));

		PartDefinition i_sx = manosx.addOrReplaceChild("i_sx", CubeListBuilder.create(),
				PartPose.offset(4.2226F, -1.6899F, -0.4208F));

		PartDefinition cube_r54 = i_sx.addOrReplaceChild("cube_r54",
				CubeListBuilder.create().texOffs(102, 22).addBox(-1.0783F, -0.5005F, -0.0168F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.1574F, 1.315F, 0.1454F, -0.1665F, 0.3082F, -0.4623F));

		PartDefinition i_sx2 = i_sx.addOrReplaceChild("i_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-0.0153F, 0.2091F, 0.1905F, 0.0719F, -0.0544F, -1.4447F));

		PartDefinition cube_r55 = i_sx2.addOrReplaceChild("cube_r55",
				CubeListBuilder.create().texOffs(52, 102).addBox(0.8908F, -0.5005F, 0.0335F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.488F, -0.0645F, -0.0256F, 0.0F, 0.3491F, 0.0436F));

		PartDefinition i_sx3 = i_sx2.addOrReplaceChild("i_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.1F, -0.4F, -0.3F, -0.5043F, 0.3152F, -0.1526F));

		PartDefinition cube_r56 = i_sx3.addOrReplaceChild("cube_r56",
				CubeListBuilder.create().texOffs(102, 58).addBox(-0.5F, -0.5F, -0.5F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, -0.2801F, 0.3252F, -2.3477F));

		PartDefinition a_sx = manosx.addOrReplaceChild("a_sx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.7249F, -0.4121F, -1.6939F, -0.3235F, -0.0305F, -0.45F));

		PartDefinition cube_r57 = a_sx.addOrReplaceChild("cube_r57",
				CubeListBuilder.create().texOffs(100, 100).addBox(-0.9472F, -0.5005F, -2.1482F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.8402F, 0.0372F, 1.4185F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition a_sx2 = a_sx.addOrReplaceChild("a_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.3807F, -0.3485F, -0.8938F, -0.3518F, -0.123F, -0.6531F));

		PartDefinition cube_r58 = a_sx2.addOrReplaceChild("cube_r58",
				CubeListBuilder.create().texOffs(102, 54).addBox(0.976F, -0.5005F, -2.1827F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.3405F, -0.0144F, 2.2123F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition a_sx3 = a_sx2.addOrReplaceChild("a_sx3", CubeListBuilder.create(),
				PartPose.offsetAndRotation(1.0F, -0.6F, -0.6F, -0.5217F, -0.2131F, -0.8754F));

		PartDefinition cube_r59 = a_sx3.addOrReplaceChild("cube_r59",
				CubeListBuilder.create().texOffs(102, 60).addBox(0.976F, -0.5005F, -2.1827F, 1.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.3405F, -0.0144F, 2.2123F, 0.0F, 0.5672F, 0.0436F));

		PartDefinition p_sx = manosx.addOrReplaceChild("p_sx", CubeListBuilder.create(),
				PartPose.offset(-17.5834F, 0.9246F, -4.497F));

		PartDefinition p_sx1 = p_sx.addOrReplaceChild("p_sx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(18.7027F, -1.5321F, 6.3422F, 0.5661F, 0.5338F, 0.3127F));

		PartDefinition cube_r60 = p_sx1.addOrReplaceChild("cube_r60",
				CubeListBuilder.create().texOffs(20, 102).addBox(-1.0189F, -0.3709F, 1.9563F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(1.2459F, 0.0326F, -2.1206F, 0.0436F, -0.5236F, 0.0436F));

		PartDefinition p_sx2 = p_sx.addOrReplaceChild("p_sx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(20.4271F, -1.8568F, 5.8377F, 0.2151F, 0.9163F, -0.5546F));

		PartDefinition cube_r61 = p_sx2.addOrReplaceChild("cube_r61",
				CubeListBuilder.create().texOffs(102, 45).addBox(0.9736F, -0.371F, 1.9554F, 2.0F, 1.0F, 1.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.4785F, -0.0427F, -3.1161F, 0.0436F, -0.5236F, 0.0436F));

		PartDefinition spallasx = arto_s_sx.addOrReplaceChild("spallasx",
				CubeListBuilder.create().texOffs(88, 76).addBox(-2.0F, -2.0F, -2.0F, 4.0F, 4.0F, 4.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-2.7F, -1.0F, 3.0F, 0.1705F, 0.4232F, 0.0949F));

		PartDefinition gambadx1 = All.addOrReplaceChild("gambadx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.8333F, 2.1919F, -17.9453F, 0.0F, 0.0F, -0.3927F));

		PartDefinition cube_r62 = gambadx1.addOrReplaceChild("cube_r62",
				CubeListBuilder.create().texOffs(32, 57).addBox(-2.0507F, -0.269F, -2.7671F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.816F, -1.6229F, -0.7876F, -0.3655F, 0.0989F, -0.4798F));

		PartDefinition cube_r63 = gambadx1.addOrReplaceChild("cube_r63",
				CubeListBuilder.create().texOffs(90, 41).addBox(-1.0507F, -1.8084F, -4.2221F, 3.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.816F, -1.6229F, -0.7876F, -0.3218F, 0.0989F, -0.4798F));

		PartDefinition cube_r64 = gambadx1.addOrReplaceChild("cube_r64",
				CubeListBuilder.create().texOffs(50, 0).addBox(-2.0507F, -1.538F, -2.7798F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.816F, -1.6229F, -0.7876F, -0.2782F, 0.0989F, -0.4798F));

		PartDefinition gambadx2 = gambadx1.addOrReplaceChild("gambadx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-2.4798F, -1.3093F, -8.6678F, 0.1309F, 0.0F, 0.2182F));

		PartDefinition cube_r65 = gambadx2.addOrReplaceChild("cube_r65",
				CubeListBuilder.create().texOffs(0, 33).addBox(-2.2272F, 1.0146F, -3.3F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9596F, -1.4971F, -2.6869F, 0.0F, 0.0F, -0.6981F));

		PartDefinition cube_r66 = gambadx2.addOrReplaceChild("cube_r66",
				CubeListBuilder.create().texOffs(32, 19).addBox(-2.2272F, 0.7402F, -3.4683F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.9596F, -1.4971F, -2.6869F, 0.0873F, 0.0F, -0.6981F));

		PartDefinition piededx = gambadx2.addOrReplaceChild("piededx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.4596F, -0.8971F, -3.6869F, 0.0F, 0.0F, -0.5236F));

		PartDefinition cube_r67 = piededx
				.addOrReplaceChild("cube_r67",
						CubeListBuilder.create().texOffs(0, 96).addBox(-0.2228F, -3.7085F, -2.7F, 2.0F, 4.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.8727F));

		PartDefinition cube_r68 = piededx
				.addOrReplaceChild("cube_r68",
						CubeListBuilder.create().texOffs(92, 11).addBox(-2.2272F, 0.0146F, -2.7F, 4.0F, 3.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.6981F));

		PartDefinition cube_r69 = piededx
				.addOrReplaceChild("cube_r69",
						CubeListBuilder.create().texOffs(92, 63).addBox(-2.0528F, -4.2804F, -2.7F, 2.0F, 5.0F, 2.0F,
								new CubeDeformation(0.0F)),
						PartPose.offsetAndRotation(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -0.3927F));

		PartDefinition gambasx1 = All.addOrReplaceChild("gambasx1", CubeListBuilder.create(),
				PartPose.offsetAndRotation(4.7946F, 2.2467F, -17.5864F, -0.3463F, 0.0447F, 1.083F));

		PartDefinition cube_r70 = gambasx1.addOrReplaceChild("cube_r70",
				CubeListBuilder.create().texOffs(62, 57).addBox(-1.2644F, -4.3798F, 1.2415F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.3759F, 3.7357F, -5.0977F, -0.0417F, -0.1269F, 0.3722F));

		PartDefinition cube_r71 = gambasx1.addOrReplaceChild("cube_r71",
				CubeListBuilder.create().texOffs(90, 47).addBox(-1.2644F, -5.7405F, -0.0381F, 3.0F, 3.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.3759F, 3.7357F, -5.0977F, 0.0019F, -0.1269F, 0.3722F));

		PartDefinition cube_r72 = gambasx1.addOrReplaceChild("cube_r72",
				CubeListBuilder.create().texOffs(0, 61).addBox(-1.2644F, -5.2838F, 1.5717F, 4.0F, 2.0F, 11.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.3759F, 3.7357F, -5.0977F, 0.0456F, -0.1269F, 0.3722F));

		PartDefinition gambasx2 = gambasx1.addOrReplaceChild("gambasx2", CubeListBuilder.create(),
				PartPose.offsetAndRotation(0.4812F, 3.5295F, -8.669F, 0.8689F, -0.005F, -0.1278F));

		PartDefinition cube_r73 = gambasx2.addOrReplaceChild("cube_r73",
				CubeListBuilder.create().texOffs(0, 19).addBox(-1.0088F, -2.3984F, -6.8271F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.1456F, 0.926F, 0.9098F, -0.1106F, 0.2278F, 0.3115F));

		PartDefinition cube_r74 = gambasx2.addOrReplaceChild("cube_r74",
				CubeListBuilder.create().texOffs(0, 47).addBox(-1.0088F, -1.8193F, -6.9196F, 4.0F, 2.0F, 12.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-1.1456F, 0.926F, 0.9098F, -0.1978F, 0.2278F, 0.3115F));

		PartDefinition piedesx = gambasx2.addOrReplaceChild("piedesx", CubeListBuilder.create(),
				PartPose.offsetAndRotation(-1.223F, -2.3434F, -6.5594F, 0.3491F, 0.0F, 0.0F));

		PartDefinition cube_r75 = piedesx.addOrReplaceChild("cube_r75",
				CubeListBuilder.create().texOffs(84, 92).addBox(1.6033F, -6.6671F, -7.2063F, 2.0F, 5.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0774F, 3.2694F, 6.5692F, -0.2582F, 0.1909F, 0.0336F));

		PartDefinition cube_r76 = piedesx.addOrReplaceChild("cube_r76",
				CubeListBuilder.create().texOffs(92, 92).addBox(-1.504F, -6.5414F, -7.2063F, 2.0F, 4.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0774F, 3.2694F, 6.5692F, -0.1411F, 0.288F, 0.518F));

		PartDefinition cube_r77 = piedesx.addOrReplaceChild("cube_r77",
				CubeListBuilder.create().texOffs(0, 91).addBox(-1.0118F, -2.7279F, -7.2063F, 4.0F, 3.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(0.0774F, 3.2694F, 6.5692F, -0.1895F, 0.2592F, 0.3392F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		All.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}