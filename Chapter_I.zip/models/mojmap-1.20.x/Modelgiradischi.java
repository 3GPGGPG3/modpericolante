// Made with Blockbench 5.0.5
// Exported for Minecraft version 1.17 or later with Mojang mappings
// Paste this class into your mod and generate all required imports

public class Modelgiradischi<T extends Entity> extends EntityModel<T> {
	// This layer location should be baked with EntityRendererProvider.Context in
	// the entity renderer and passed into this model's constructor
	public static final ModelLayerLocation LAYER_LOCATION = new ModelLayerLocation(
			new ResourceLocation("modid", "giradischi"), "main");
	private final ModelPart all;
	private final ModelPart disco;
	private final ModelPart asta;

	public Modelgiradischi(ModelPart root) {
		this.all = root.getChild("all");
		this.disco = this.all.getChild("disco");
		this.asta = this.all.getChild("asta");
	}

	public static LayerDefinition createBodyLayer() {
		MeshDefinition meshdefinition = new MeshDefinition();
		PartDefinition partdefinition = meshdefinition.getRoot();

		PartDefinition all = partdefinition.addOrReplaceChild("all",
				CubeListBuilder.create().texOffs(42, 59)
						.addBox(-1.0F, -9.0F, -13.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(50, 59)
						.addBox(-1.0F, -9.0F, -1.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(0, 65)
						.addBox(11.0F, -9.0F, -1.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(58, 59)
						.addBox(11.0F, -9.0F, -13.0F, 2.0F, 9.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(18, 56)
						.addBox(11.0F, -2.0F, -14.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(18, 67)
						.addBox(13.0F, -2.0F, -13.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(24, 67)
						.addBox(13.0F, -2.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(14, 70)
						.addBox(11.0F, -2.0F, 1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(68, 50)
						.addBox(13.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(32, 70)
						.addBox(11.0F, -10.0F, -14.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(36, 67)
						.addBox(13.0F, -10.0F, -13.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(26, 70)
						.addBox(11.0F, -10.0F, 1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(0, 0)
						.addBox(-1.0F, -2.0F, -13.0F, 14.0F, 1.0F, 14.0F, new CubeDeformation(0.0F)).texOffs(0, 15)
						.addBox(-1.0F, -10.0F, -13.0F, 14.0F, 1.0F, 14.0F, new CubeDeformation(0.0F)).texOffs(0, 30)
						.addBox(0.0F, -9.0F, -12.0F, 12.0F, 7.0F, 12.0F, new CubeDeformation(0.0F)).texOffs(8, 70)
						.addBox(-1.0F, -10.0F, 1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(66, 65)
						.addBox(-2.0F, -10.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(20, 70)
						.addBox(-1.0F, -10.0F, -14.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(30, 67)
						.addBox(-2.0F, -10.0F, -13.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(38, 70)
						.addBox(-1.0F, -2.0F, 1.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(68, 53)
						.addBox(-2.0F, -2.0F, -13.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(44, 70)
						.addBox(-1.0F, -2.0F, -14.0F, 2.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(66, 68)
						.addBox(-2.0F, -2.0F, -1.0F, 1.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(48, 40)
						.addBox(0.0F, -10.5F, -10.4F, 9.0F, 1.0F, 9.0F, new CubeDeformation(0.0F)).texOffs(48, 30)
						.addBox(3.4F, -10.1F, -8.5F, 9.0F, 1.0F, 9.0F, new CubeDeformation(0.0F)).texOffs(50, 70)
						.addBox(4.0F, -12.0F, -6.4F, 1.0F, 2.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(60, 50)
						.addBox(7.0F, -15.0F, -1.2F, 2.0F, 5.0F, 2.0F, new CubeDeformation(0.0F)),
				PartPose.offset(-6.0F, 24.0F, 6.0F));

		PartDefinition cube_r1 = all.addOrReplaceChild("cube_r1",
				CubeListBuilder.create().texOffs(62, 70)
						.addBox(-4.5F, -5.0F, 3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(58, 70)
						.addBox(3.5F, -5.0F, 3.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(70, 56)
						.addBox(3.5F, -5.0F, -4.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(54, 70)
						.addBox(-4.5F, -5.0F, -4.5F, 1.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(42, 50)
						.addBox(-5.5F, -5.0F, -3.5F, 2.0F, 2.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(0, 56)
						.addBox(3.5F, -5.0F, -3.5F, 2.0F, 2.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(56, 16)
						.addBox(-3.5F, -5.0F, -5.5F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(56, 20)
						.addBox(-3.5F, -5.0F, 3.5F, 7.0F, 2.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(56, 8)
						.addBox(1.5F, -4.0F, -3.5F, 2.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(66, 27)
						.addBox(-1.5F, -4.0F, 1.5F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(66, 24)
						.addBox(-1.5F, -4.0F, -3.5F, 3.0F, 1.0F, 2.0F, new CubeDeformation(0.0F)).texOffs(56, 0)
						.addBox(-3.5F, -4.0F, -3.5F, 2.0F, 1.0F, 7.0F, new CubeDeformation(0.0F)).texOffs(18, 58)
						.addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F, new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.2F, -22.7F, -2.8F, 1.0843F, 0.2219F, -0.0154F));

		PartDefinition cube_r2 = all.addOrReplaceChild("cube_r2",
				CubeListBuilder.create().texOffs(30, 58).addBox(-1.5F, -3.0F, -1.5F, 3.0F, 6.0F, 3.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(7.8F, -18.0F, -0.7F, 0.1244F, 0.2219F, -0.0154F));

		PartDefinition cube_r3 = all.addOrReplaceChild("cube_r3",
				CubeListBuilder.create().texOffs(66, 61).addBox(-1.0244F, -0.5609F, 0.3842F, 2.0F, 2.0F, 2.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(9.8801F, -11.4391F, -2.6139F, 0.0F, 0.6981F, 0.0F));

		PartDefinition disco = all.addOrReplaceChild("disco",
				CubeListBuilder.create().texOffs(0, 49)
						.addBox(-3.0F, -0.5F, -3.0F, 6.0F, 1.0F, 6.0F, new CubeDeformation(0.0F)).texOffs(8, 65)
						.addBox(-4.0F, -0.5F, -2.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(56, 24)
						.addBox(3.0F, -0.5F, -2.0F, 1.0F, 1.0F, 4.0F, new CubeDeformation(0.0F)).texOffs(60, 57)
						.addBox(-2.0F, -0.5F, -4.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)).texOffs(66, 59)
						.addBox(-2.0F, -0.5F, 3.0F, 4.0F, 1.0F, 1.0F, new CubeDeformation(0.0F)),
				PartPose.offset(4.5F, -10.4F, -6.1F));

		PartDefinition asta = all.addOrReplaceChild("asta", CubeListBuilder.create(),
				PartPose.offset(10.5917F, -12.5F, -1.7683F));

		PartDefinition cube_r4 = asta.addOrReplaceChild("cube_r4",
				CubeListBuilder.create().texOffs(24, 49).addBox(-0.4756F, -1.1502F, -5.7985F, 1.0F, 1.0F, 8.0F,
						new CubeDeformation(0.0F)),
				PartPose.offsetAndRotation(-0.7115F, 1.0609F, -0.8456F, 0.1571F, 0.6981F, 0.0F));

		return LayerDefinition.create(meshdefinition, 128, 128);
	}

	@Override
	public void setupAnim(Entity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw,
			float headPitch) {

	}

	@Override
	public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer, int packedLight, int packedOverlay,
			float red, float green, float blue, float alpha) {
		all.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
	}
}