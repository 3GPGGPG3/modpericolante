// Save this class in your mod and generate all required imports

/**
 * Made with Blockbench 5.0.6 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class psychologist_headlessAnimation {
	public static final AnimationDefinition dead = AnimationDefinition.Builder.withLength(2.0F).looping()
			.addAnimation("head",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(42.5F, 0.0F, 90.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("head",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(15.0F, -20.0F, -6.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gamba_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(-66.6908F, -13.6785F, -5.159F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gamba_sx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, -0.3F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gamba_dx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(-62.1271F, 28.9306F, 20.6174F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("gamba_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corpo",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(-16.3713F, -20.7295F, -3.4365F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("corpo",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, -9.8F, 5.3F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("braccio_dx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(17.4302F, -2.1163F, 4.5468F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("braccio_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("braccio_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(14.5723F, 23.6209F, 0.4548F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("braccio_sx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.2F, 0.0F, -0.4F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("blood",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("blood",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(0.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(1.0F, KeyframeAnimations.posVec(0.0F, 0.2F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(1.3333F, KeyframeAnimations.posVec(0.0F, -0.1F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(1.625F, KeyframeAnimations.posVec(0.0F, 0.1F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}