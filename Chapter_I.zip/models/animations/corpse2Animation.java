// Save this class in your mod and generate all required imports

/**
 * Made with Blockbench 5.0.4 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class corpse2Animation {
	public static final AnimationDefinition hang = AnimationDefinition.Builder.withLength(10.0F).looping()
			.addAnimation("g_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(5.2917F, KeyframeAnimations.degreeVec(3.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.0833F, KeyframeAnimations.degreeVec(2.4371F, -1.187F, 3.9141F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("g_sx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(5.2917F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.5F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.0833F, KeyframeAnimations.posVec(-0.3F, 0.0F, 0.5F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("b_sx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(4.7917F, KeyframeAnimations.degreeVec(0.0F, 3.0F, 2.5F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(9.0F, KeyframeAnimations.degreeVec(3.8411F, 8.9959F, -0.5207F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("b_sx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(4.7917F, KeyframeAnimations.posVec(-0.3F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(9.0F, KeyframeAnimations.posVec(0.1F, 0.0F, 0.6F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("b_dx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(3.9167F, KeyframeAnimations.degreeVec(0.0F, 0.0F, -4.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(7.625F, KeyframeAnimations.degreeVec(2.0F, 0.0F, 1.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("b_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(3.9167F, KeyframeAnimations.posVec(0.3F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(7.625F, KeyframeAnimations.posVec(-0.2F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("g_dx",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.4583F, KeyframeAnimations.degreeVec(4.9992F, -0.0872F, 0.9962F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(6.7917F, KeyframeAnimations.degreeVec(10.0047F, 1.8825F, 1.3436F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("g_dx",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.4583F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.5F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(6.7917F, KeyframeAnimations.posVec(0.1F, 0.0F, 1.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("head",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.0833F, KeyframeAnimations.degreeVec(4.0024F, 1.9951F, 0.1396F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(5.6667F, KeyframeAnimations.degreeVec(0.1871F, -2.8662F, 1.9226F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(7.5F, KeyframeAnimations.degreeVec(-3.169F, 0.8372F, 0.25F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.addAnimation("head",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(10.0F, KeyframeAnimations.posVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}