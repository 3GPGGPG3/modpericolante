// Save this class in your mod and generate all required imports

/**
 * Made with Blockbench 5.0.4 Exported for Minecraft version 1.19 or later with
 * Mojang mappings
 * 
 * @author Author
 */
public class corpseAnimation {
	public static final AnimationDefinition gocciolare = AnimationDefinition.Builder.withLength(13.0F).looping()
			.addAnimation("goccia",
					new AnimationChannel(AnimationChannel.Targets.ROTATION,
							new Keyframe(0.0F, KeyframeAnimations.degreeVec(0.0F, 0.0F, 0.0F),
									AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("goccia",
					new AnimationChannel(AnimationChannel.Targets.POSITION,
							new Keyframe(0.0F, KeyframeAnimations.posVec(0.0F, 0.2F, -0.5F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.0F, KeyframeAnimations.posVec(0.0F, -0.1F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.0417F, KeyframeAnimations.posVec(0.0F, -0.4F, 0.0F),
									AnimationChannel.Interpolations.LINEAR),
							new Keyframe(8.1657F, KeyframeAnimations.posVec(0.0F, -0.4F, 0.0F),
									AnimationChannel.Interpolations.LINEAR),
							new Keyframe(8.1667F, KeyframeAnimations.posVec(0.0F, -0.6F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(8.3333F, KeyframeAnimations.posVec(0.0F, -6.0F, 0.0F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(12.8333F, KeyframeAnimations.posVec(0.0F, -6.5F, 0.0F),
									AnimationChannel.Interpolations.LINEAR)))
			.addAnimation("goccia",
					new AnimationChannel(AnimationChannel.Targets.SCALE,
							new Keyframe(0.0F, KeyframeAnimations.scaleVec(0.1F, 0.8F, 0.2F),
									AnimationChannel.Interpolations.CATMULLROM),
							new Keyframe(2.0F, KeyframeAnimations.scaleVec(1.0F, 1.0F, 1.0F),
									AnimationChannel.Interpolations.CATMULLROM)))
			.build();
}